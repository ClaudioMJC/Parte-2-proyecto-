﻿using CapaEntidades;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;

namespace Capa03_AccesoDatos
{
    public class DAHistorial
    {
        private string _cadenaConexion;
        private string _mensaje;

        //propiedes

        public string Mensaje
        {
            get => _mensaje;
        }

        public DAHistorial(string cadenaConexion)
        {
            _cadenaConexion = cadenaConexion;
            _mensaje = string.Empty;
        }


        public int Insertar(EntidadHistorial_Medico historial)
        {
            int id = 0;
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            string sentencia = "INSERT INTO HISTORIAL_MEDICO (FECHA_CREACION, DESCRIPCION) " +
                "VALUES (@FECHA_CREACION, @DESCRIPCION) SELECT SCOPE_IDENTITY()";
            comando.Parameters.AddWithValue("@FECHA_CREACION", historial.Fecha_creacion);
            comando.Parameters.AddWithValue("@DESCRIPCION", historial.Descripcion);
            comando.CommandText = sentencia;
            try
            {
                conexion.Open();
                id = Convert.ToInt32(comando.ExecuteScalar());
                conexion.Close();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conexion.Dispose();
                comando.Dispose();
            }
            return id;
        }


        public List<EntidadHistorial_Medico> ListarHistoriales(string condicion = "")
        {
            List<EntidadHistorial_Medico> listaHistoriales = new List<EntidadHistorial_Medico>();
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            SqlDataReader dataReader;
            string sentencia = "SELECT ID_HISTORIAL_MEDICO, ID_DIAGNOSTICO, ID_PACIENTE, FECHA_CREACION, DESCRIPCION FROM HISTORIAL_MEDICO";
            if (!string.IsNullOrEmpty(condicion))
            {
                sentencia = string.Format("{0} WHERE {1}", sentencia, condicion);
            }
            comando.Connection = conexion;
            comando.CommandText = sentencia;
            try
            {
                conexion.Open();
                dataReader = comando.ExecuteReader();
                while (dataReader.Read())
                {
                    EntidadHistorial_Medico historial = new EntidadHistorial_Medico();
                    historial.Id_historial_medico = dataReader.GetInt32(0);
                    historial.Id_diagnostico = dataReader.GetInt32(1);
                    historial.Id_paciente = dataReader.GetInt32(2);
                    historial.Fecha_creacion = dataReader.GetDateTime(3);
                    historial.Descripcion = dataReader.IsDBNull(4) ? string.Empty : dataReader.GetString(4);//en caso de que contenga valores nulos
                    listaHistoriales.Add(historial);
                }
                conexion.Close();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conexion.Dispose();
                comando.Dispose();
            }
            return listaHistoriales;
        }

        public EntidadHistorial_Medico ObtenerHistorial(int id)
        {
            EntidadHistorial_Medico historial = null;
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            SqlDataReader dataReader;
            string sentencia = string.Format("SELECT ID_HISTORIAL_MEDICO, ID_DIAGNOSTICO, ID_PACIENTE, FECHA_CREACION, DESCRIPCION FROM HISTORIAL_MEDICO WHERE ID_HISTORIAL_MEDICO = @ID_HISTORIAL_MEDICO");
            comando.Parameters.AddWithValue("@ID_HISTORIAL_MEDICO", id);
            comando.Connection = conexion;
            comando.CommandText = sentencia;
            try
            {
                conexion.Open();
                dataReader = comando.ExecuteReader();
                if (dataReader.Read())
                {
                    historial = new EntidadHistorial_Medico();
                    historial.Id_historial_medico = dataReader.GetInt32(0);
                    historial.Id_diagnostico = dataReader.GetInt32(1);
                    historial.Id_paciente = dataReader.GetInt32(2);
                    historial.Fecha_creacion = dataReader.GetDateTime(3);
                    historial.Descripcion = dataReader.IsDBNull(4) ? string.Empty : dataReader.GetString(4);
                }
                conexion.Close();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conexion.Dispose();
                comando.Dispose();
            }
            return historial;
        }

        public int Modificar(EntidadHistorial_Medico historial)
        {
            bool exito = false;
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            string sentencia = "UPDATE HISTORIAL_MEDICO SET ID_DIAGNOSTICO = @ID_DIAGNOSTICO, ID_PACIENTE = @ID_PACIENTE, " +
                "FECHA_CREACION = @FECHA_CREACION, DESCRIPCION = @DESCRIPCION WHERE ID_HISTORIAL_MEDICO = @ID_HISTORIAL_MEDICO";
            comando.Parameters.AddWithValue("@ID_DIAGNOSTICO", historial.Id_diagnostico);
            comando.Parameters.AddWithValue("@ID_PACIENTE", historial.Id_paciente);
            comando.Parameters.AddWithValue("@FECHA_CREACION", historial.Fecha_creacion);
            comando.Parameters.AddWithValue("@DESCRIPCION", historial.Descripcion);
            comando.Parameters.AddWithValue("@ID_HISTORIAL_MEDICO", historial.Id_historial_medico);
            comando.CommandText = sentencia;
            try
            {
                conexion.Open();
                int filasAfectadas = comando.ExecuteNonQuery();
                exito = (filasAfectadas > 0);
                conexion.Close();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conexion.Dispose();
                comando.Dispose();
            }
            return exito;
        }

        public int EliminarHistorial(EntidadHistorial_Medico historial)
        {
            int afectado = 1;
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            string sentencia = "DELETE FROM HISTORIAL_MEDICO WHERE ID_HISTORIAL_MEDICO = @ID_HISTORIAL_MEDICO";
            comando.Parameters.AddWithValue("@ID_HISTORIAL_MEDICO", id);
            comando.CommandText = sentencia;
            try
            {
                conexion.Open();
                afectado = comando.ExecuteNonQuery();
                conexion.Close();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conexion.Dispose();
                comando.Dispose();
            }
            return afectado;
        }
    }
}

