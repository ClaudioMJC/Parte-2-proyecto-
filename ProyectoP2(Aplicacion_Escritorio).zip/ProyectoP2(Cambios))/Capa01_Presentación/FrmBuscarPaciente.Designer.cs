﻿namespace Capa01_Presentación
{
    partial class FrmBuscarPaciente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmBuscarPaciente));
            label2 = new System.Windows.Forms.Label();
            txtNombre = new System.Windows.Forms.TextBox();
            btnBuscar = new System.Windows.Forms.Button();
            btnAceptar = new System.Windows.Forms.Button();
            btnCancelar = new System.Windows.Forms.Button();
            grdListaPacientes = new System.Windows.Forms.DataGridView();
            ID_PACIENTE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            NOMBRE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            APELLIDO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            FECHA_NACIMIENTO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            DIRECCION = new System.Windows.Forms.DataGridViewTextBoxColumn();
            TELEFONO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)grdListaPacientes).BeginInit();
            SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(39, 51);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(78, 25);
            label2.TabIndex = 71;
            label2.Text = "Nombre";
            // 
            // txtNombre
            // 
            txtNombre.Location = new System.Drawing.Point(132, 51);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new System.Drawing.Size(460, 31);
            txtNombre.TabIndex = 70;
            // 
            // btnBuscar
            // 
            btnBuscar.Image = (System.Drawing.Image)resources.GetObject("btnBuscar.Image");
            btnBuscar.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            btnBuscar.Location = new System.Drawing.Point(627, 45);
            btnBuscar.Name = "btnBuscar";
            btnBuscar.Size = new System.Drawing.Size(136, 71);
            btnBuscar.TabIndex = 69;
            btnBuscar.Text = "&Buscar";
            btnBuscar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnBuscar.UseVisualStyleBackColor = true;
            btnBuscar.Click += btnBuscar_Click;
            // 
            // btnAceptar
            // 
            btnAceptar.Image = (System.Drawing.Image)resources.GetObject("btnAceptar.Image");
            btnAceptar.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            btnAceptar.Location = new System.Drawing.Point(444, 366);
            btnAceptar.Name = "btnAceptar";
            btnAceptar.Size = new System.Drawing.Size(148, 72);
            btnAceptar.TabIndex = 68;
            btnAceptar.Text = "&Aceptar";
            btnAceptar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnAceptar.UseVisualStyleBackColor = true;
            btnAceptar.Click += btnAceptar_Click;
            // 
            // btnCancelar
            // 
            btnCancelar.Image = (System.Drawing.Image)resources.GetObject("btnCancelar.Image");
            btnCancelar.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            btnCancelar.Location = new System.Drawing.Point(629, 366);
            btnCancelar.Name = "btnCancelar";
            btnCancelar.Size = new System.Drawing.Size(146, 72);
            btnCancelar.TabIndex = 67;
            btnCancelar.Text = "&Cancelar";
            btnCancelar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnCancelar.UseVisualStyleBackColor = true;
            btnCancelar.Click += btnCancelar_Click;
            // 
            // grdListaPacientes
            // 
            grdListaPacientes.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            grdListaPacientes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            grdListaPacientes.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] { ID_PACIENTE, NOMBRE, APELLIDO, FECHA_NACIMIENTO, DIRECCION, TELEFONO });
            grdListaPacientes.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            grdListaPacientes.GridColor = System.Drawing.SystemColors.Control;
            grdListaPacientes.Location = new System.Drawing.Point(5, 180);
            grdListaPacientes.Name = "grdListaPacientes";
            grdListaPacientes.RowHeadersWidth = 62;
            grdListaPacientes.RowTemplate.Height = 33;
            grdListaPacientes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            grdListaPacientes.Size = new System.Drawing.Size(770, 147);
            grdListaPacientes.TabIndex = 66;
            grdListaPacientes.DoubleClick += grdListaPacientes_DoubleClick;
            // 
            // ID_PACIENTE
            // 
            ID_PACIENTE.DataPropertyName = "ID_PACIENTE";
            ID_PACIENTE.HeaderText = "ID_PACIENTE";
            ID_PACIENTE.MinimumWidth = 8;
            ID_PACIENTE.Name = "ID_PACIENTE";
            ID_PACIENTE.Width = 150;
            // 
            // NOMBRE
            // 
            NOMBRE.DataPropertyName = "NOMBRE";
            NOMBRE.HeaderText = "NOMBRE";
            NOMBRE.MinimumWidth = 8;
            NOMBRE.Name = "NOMBRE";
            NOMBRE.Width = 150;
            // 
            // APELLIDO
            // 
            APELLIDO.DataPropertyName = "APELLIDO";
            APELLIDO.HeaderText = "APELLIDO";
            APELLIDO.MinimumWidth = 8;
            APELLIDO.Name = "APELLIDO";
            APELLIDO.Width = 150;
            // 
            // FECHA_NACIMIENTO
            // 
            FECHA_NACIMIENTO.DataPropertyName = "FECHA_NACIMIENTO";
            FECHA_NACIMIENTO.HeaderText = "FECHA_NACIMIENTO";
            FECHA_NACIMIENTO.MinimumWidth = 8;
            FECHA_NACIMIENTO.Name = "FECHA_NACIMIENTO";
            FECHA_NACIMIENTO.Visible = false;
            FECHA_NACIMIENTO.Width = 150;
            // 
            // DIRECCION
            // 
            DIRECCION.DataPropertyName = "DIRECCION";
            DIRECCION.HeaderText = "DIRECCIÓN";
            DIRECCION.MinimumWidth = 8;
            DIRECCION.Name = "DIRECCION";
            DIRECCION.Width = 150;
            // 
            // TELEFONO
            // 
            TELEFONO.DataPropertyName = "TELEFONO";
            TELEFONO.HeaderText = "TELÉFONO";
            TELEFONO.MinimumWidth = 8;
            TELEFONO.Name = "TELEFONO";
            TELEFONO.Width = 150;
            // 
            // FrmBuscarPaciente
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(800, 450);
            Controls.Add(label2);
            Controls.Add(txtNombre);
            Controls.Add(btnBuscar);
            Controls.Add(btnAceptar);
            Controls.Add(btnCancelar);
            Controls.Add(grdListaPacientes);
            MaximizeBox = false;
            Name = "FrmBuscarPaciente";
            Text = "FrmBuscarPaciente";
            Load += FrmBuscarPaciente_Load;
            ((System.ComponentModel.ISupportInitialize)grdListaPacientes).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Button btnBuscar;
        private System.Windows.Forms.Button btnAceptar;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.DataGridView grdListaPacientes;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_PACIENTE;
        private System.Windows.Forms.DataGridViewTextBoxColumn NOMBRE;
        private System.Windows.Forms.DataGridViewTextBoxColumn APELLIDO;
        private System.Windows.Forms.DataGridViewTextBoxColumn FECHA_NACIMIENTO;
        private System.Windows.Forms.DataGridViewTextBoxColumn DIRECCION;
        private System.Windows.Forms.DataGridViewTextBoxColumn TELEFONO;
    }
}