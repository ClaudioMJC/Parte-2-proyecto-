﻿using Capa02_LogicaNegocio;
using Capa03_AccesoDatos;
using CapaEntidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Capa01_Presentación
{
    public partial class FrmHistorialM : Form
    {
        EntidadHistorial_Medico historialRegistrado;
        FrmBuscarHISTORIALM formularioBuscar;

        public FrmHistorialM()
        {
            InitializeComponent();
        }
        public EntidadHistorial_Medico generaHistorialMedico()
        {
            EntidadHistorial_Medico historial;
            if (!string.IsNullOrEmpty(txtIdHistorial.Text))
            {
                historial = historialRegistrado;
            }
            else
            {
                historial = new EntidadHistorial_Medico();
            }

            //historial.Id_diagnostico = int.Parse(txtIdDiagnostico.Text);
            historial.Id_historial_medico= int.Parse(txtIdHistorial.Text);
            historial.Id_paciente = int.Parse(cboIDPacientes.Text);
            historial.Fecha_creacion = DateTime.Parse(dtCalendario.Text);
            historial.Descripcion = txtDescripcion.Text;

            return historial;
        }



        /*
        private void btnGuardar_Click(object sender, EventArgs e)
        {
            EntidadHistorial_Medico historial = new EntidadHistorial_Medico();
            BLHistorial logicaHistorialMedico = new BLHistorial(Configuracion.getConnectionString);

            int resultado;
            try
            {
                if (cboIDPacientes.SelectedItem != null && !string.IsNullOrEmpty(txtDescripcion.Text))
                {
                    historial.Id_paciente = Convert.ToInt32(cboIDPacientes.SelectedItem);
                    historial.Fecha_creacion = dtCalendario.Value;
                    historial.Descripcion = txtDescripcion.Text;

                    resultado = logicaHistorialMedico.LlamarMetodoInsertar(historial); // Insertar el historial médico

                    if (resultado > 0)
                    {
                        LimpiarCampos();
                        MessageBox.Show("La operación fue exitosa", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        CargarListaHistoriales(); // Cargar la lista de historiales médicos
                    }
                    else
                    {
                        MessageBox.Show("No se realizaron cambios", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("Los datos son obligatorios", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        */
        private void btnGuardar_Click(object sender, EventArgs e)
        {
            EntidadHistorial_Medico historial = new EntidadHistorial_Medico();
            BLHistorial logicaHistorialMedico = new BLHistorial(Configuracion.getConnectionString);

            int resultado;
            try
            {
                if (cboIDPacientes.SelectedItem != null && !string.IsNullOrEmpty(txtDescripcion.Text))
                {
                    historial.Id_paciente = Convert.ToInt32(cboIDPacientes.SelectedItem);
                    historial.Fecha_creacion = dtCalendario.Value;
                    historial.Descripcion = txtDescripcion.Text;

                    //bool existeHistorial = logicaHistorialMedico.ExisteHistorialMedico(historial.Id_historial_medico);

                    if (historial.Id_historial_medico != 0)
                    {
                        resultado = logicaHistorialMedico.Modificar(historial); // Actualizar el historial médico
                    }
                    else
                    {
                        resultado = logicaHistorialMedico.LlamarMetodoInsertar(historial); // Insertar el historial médico
                    }

                    if (resultado > 0)
                    {
                        LimpiarCampos();
                        MessageBox.Show("La operación fue exitosa", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        CargarListaHistoriales(); // Cargar la lista de historiales médicos
                    }
                    else
                    {
                        MessageBox.Show("No se realizaron cambios", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("Los datos son obligatorios", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        public void LimpiarCampos()
        {
            txtIdHistorial.Text = string.Empty;
            dtCalendario.Value = DateTime.Now;
            txtDescripcion.Text =String.Empty;
        }
        //(Hasta aquí es el procedimiento para insertar en la base de datos y guardar)




        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }



        //CARGA LA LISTA HISTORIALES
        public void CargarListaHistoriales(string condicion = "")
        {
            DAHistorial accesoDatos = new DAHistorial(Configuracion.getConnectionString);
            List<EntidadHistorial_Medico> listarHistoriales;
            try
            {
                listarHistoriales = accesoDatos.ListarHistoriales(condicion);
                if (listarHistoriales.Count > 0)
                {
                    grdHistorialM.DataSource = listarHistoriales;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }






        private void btnNuevo_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
        }


        private void Aceptar(Object id, EventArgs e)
        {
            try
            {
                int idHistorial = (int)id;
                if (idHistorial != -1)
                {
                    CargarHistorial(idHistorial);
                }
                else
                {
                    LimpiarCampos();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CargarHistorial(int id)
        {
            EntidadHistorial_Medico historial = new EntidadHistorial_Medico();
            DAHistorial accesoDatos = new DAHistorial(Configuracion.getConnectionString);
            try
            {
                historial = accesoDatos.ObtenerHistorial(id);

                if (historial != null)
                {   
                    txtIdHistorial.Text= historial.Id_historial_medico.ToString();
                    cboIDPacientes.Text = historial.Id_paciente.ToString();
                    dtCalendario.Value = historial.Fecha_creacion;
                    /*
                    if (dtCalendario == null)
                    {
                        dtCalendario.Value = DateTime.Now;
                    }
                    else
                    {
                        dtCalendario.Value = historial.Fecha_creacion;
                    }
                    */
                    //dtCalendario.Value = historial.Fecha_creacion;
                    //dtCalendario.Value = historial.Fecha_creacion != DateTime.MinValue ? historial.Fecha_creacion : DateTime.Now; 
                    txtDescripcion.Text = historial.Descripcion;
                }
                else
                {
                    MessageBox.Show("El historial no se encuentra en la base de datos", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    CargarListaHistoriales();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        ////////////////////////////////

        private void btnEliminar_Click(object sender, EventArgs e)
        {


            EntidadHistorial_Medico historial;
            int resultado;
            BLHistorial logica = new BLHistorial(Configuracion.getConnectionString);
            try
            {
                if (!string.IsNullOrEmpty(txtIdHistorial.Text))
                {
                    historial = logica.ObtenerHistorial(int.Parse(txtIdHistorial.Text));
                    if (historial != null)
                    {
                        resultado = logica.EliminarHistorialMedico(historial);
                        MessageBox.Show("Se ha eliminado el registro", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LimpiarCampos();
                        CargarListaHistoriales();
                    }
                    else
                    {
                        MessageBox.Show("El historial no existe", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        LimpiarCampos();
                        CargarListaHistoriales();
                    }
                }
                else
                {
                    MessageBox.Show("Debe seleccionar un historial antes de eliminar", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        } //btn Eliminar




        private void FrmHistorialM_Load(object sender, EventArgs e)
        {
            BLHistorial pacientesID = new BLHistorial(Configuracion.getConnectionString);

            // Obtener la lista de ID de roles desde la capa lógica
            List<int> idPacientes = pacientesID.ObtenerIdPacientes();

            // Recorrer la lista de ID de roles y agregarlos al ComboBox
            foreach (int idP in idPacientes)
            {
                cboIDPacientes.Items.Add(idP);
            }

            try
            {
                CargarListaHistoriales();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void btnBuscar_Click(object sender, EventArgs e)
        {
            formularioBuscar = new FrmBuscarHISTORIALM();
            formularioBuscar.Aceptar += new EventHandler(Aceptar);
            formularioBuscar.ShowDialog();
        }

    }
}
