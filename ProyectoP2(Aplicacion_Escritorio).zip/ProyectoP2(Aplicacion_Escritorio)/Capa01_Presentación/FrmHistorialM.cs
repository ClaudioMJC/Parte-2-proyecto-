﻿using Capa02_LogicaNegocio;
using CapaEntidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Capa01_Presentación
{
    public partial class FrmHistorialM : Form
    {
        EntidadHistorial_Medico historialRegistrado;
        public FrmHistorialM()
        {
            InitializeComponent();
        }
        public EntidadHistorial_Medico generaHistorialMedico()
        {
            EntidadHistorial_Medico historial;
            if (!string.IsNullOrEmpty(txtIdHistorial.Text))
            {
                historial = historialRegistrado;
            }
            else
            {
                historial = new EntidadHistorial_Medico();
            }

            //historial.Id_diagnostico = int.Parse(txtIdDiagnostico.Text);
            historial.Id_paciente = int.Parse(txtIdHistorial.Text);
            historial.Fecha_creacion = DateTime.Parse(dtCalendario.Text);
            historial.Descripcion = txtDescripcion.Text;

            return historial;
        }



        private void btnGuardar_Click(object sender, EventArgs e)
        {
            EntidadHistorial_Medico historialMedico = new EntidadHistorial_Medico();
            BLHistorial logicaHistorialMedico = new BLHistorial(Configuracion.getConnectionString);
            int resultado;
            try
            {
                if (!string.IsNullOrEmpty(dtCalendario.Text) && !string.IsNullOrEmpty(txtDescripcion.Text))
                {
                    historialMedico = generaHistorialMedico();
                    resultado = logicaHistorialMedico.LlamarMetodoInsertar(historialMedico);
                    if (resultado > 0)
                    {
                        LimpiarCampos();
                        MessageBox.Show("Operación exitosa", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        // Otras acciones después de guardar el historial médico
                    }
                    else
                    {
                        MessageBox.Show("No se realizaron cambios", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("Los datos son obligatorios", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        public void LimpiarCampos()
        {
            txtIdHistorial.Text = string.Empty;
            dtCalendario = null;
            txtDescripcion = null;
        }
        //(Hasta aquí es el procedimiento para insertar en la base de datos y guardar)


        public void CargarListaHistoriales(string condicion = "") //agregado  
        {
            BLHistorial logicaBuscar = new BLHistorial(Configuracion.getConnectionString);
            List<EntidadHistorial_Medico> listarHistorial;  //Se establece una Lista de la entidadpaciente que se cargará conteniendo todos los datos
            try                                      //guardos en la tabla, siempre y cuando haya algun registro de paciente guardado en la bd
            {
                listarHistorial = logicaBuscar.LlamarMetodoListarHistoriales();
                if (listarHistorial.Count > 0)
                {
                    grdHistorialM.DataSource = listarHistorial;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /*private void FrmRegistrarPaciente_Load(object sender, EventArgs e)
        {
            try   //cargamos la lista de pacientes al cargar el formulario y se muestra en el datagridview
            {
                CargarListaPacientes();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        */
        /*
        private void btnBuscar_Click(object sender, EventArgs e)
        {
            //FrmBuscarPaciente frm = new FrmBuscarPaciente();
            //frm.ShowDialog();

            formularioBuscar = new FrmBuscarPaciente();
            //se especifica que se quiere usar el evento Aceptar
            formularioBuscar.Aceptar += new EventHandler(Aceptar);
            formularioBuscar.ShowDialog();

        }
        */
        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Aceptar(Object id, EventArgs e) //ACEPTAR
        {
            try
            {
                int idHistorial = (int)id;
                if (idHistorial != -1)
                {
                    //MessageBox.Show(idCliente.ToString());
                    //CargarListaPacientes(idPaciente.ToString());
                    CargarHistoriales(idHistorial);
                }
                else
                {
                    LimpiarCampos();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//fin aceptar


        private void CargarHistoriales(int id)
        {
            EntidadHistorial_Medico historial = new EntidadHistorial_Medico();
            BLHistorial traerHistorial = new BLHistorial(Configuracion.getConnectionString);
            try
            {
                historial = traerHistorial.LlamarMetodoObtenerHistorial(id);

                if (historial != null)
                {

                    txtIdHistorial.Text = historial.Id_historial_medico.ToString();
                    dtCalendario.Text = historial.Fecha_creacion.ToString();
                    txtDescripcion.Text = historial.Descripcion;

                }
                else
                {
                    MessageBox.Show("El historial no se encuentra en la base de datos",
                        "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    CargarListaHistoriales();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin cargar cliente

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            EntidadHistorial_Medico historial;
            int resultado;
            BLHistorial logica = new BLHistorial(Configuracion.getConnectionString);
            try
            {
                if (!string.IsNullOrEmpty(txtIdHistorial.Text))
                {
                    historial = logica.LlamarMetodoObtenerHistorial(int.Parse(txtIdHistorial.Text));
                    if (historial != null)
                    {   /*
                        resultado = logica.EliminarConSP(cliente);
                        MessageBox.Show(logica.Mensaje, "Aviso", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                        */
                        resultado = logica.LlamarMetodoEliminarHistorial(historial);
                        MessageBox.Show("Se ha eliminado el resgistro", "Aviso", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                        LimpiarCampos();
                        CargarListaHistoriales();


                    }
                    else
                    {
                        MessageBox.Show("El historial no existe", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        LimpiarCampos();
                        CargarListaHistoriales();
                    }
                }
                else
                {
                    MessageBox.Show("Debe Seleccionar un cliente antes de eliminar", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        } //btn Eliminar

        private void FrmHistorialM_Load(object sender, EventArgs e)
        {
            try   //cargamos la lista de pacientes al cargar el formulario y se muestra en el datagridview
            {
                CargarListaHistoriales();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
