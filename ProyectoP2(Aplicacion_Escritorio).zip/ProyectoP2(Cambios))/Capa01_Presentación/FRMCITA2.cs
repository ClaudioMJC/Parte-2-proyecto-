﻿using Capa02_LogicaNegocio;
using Capa03_AccesoDatos;
using CapaEntidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Capa01_Presentación
{
    public partial class FRMCITA2 : Form
    {
        EntidadCita citaRegistrada;

        FrmBuscarPaciente formularioBuscar;
        FrmBUSCARCITAS formularioBuscar2;
        public FRMCITA2()
        {
            InitializeComponent();
        }



        //COMIENZA PROCEDIMIENTO PARA VISUALIZAR LOS DATOS DEL PACIENTE EN LA PARTE SUPERIOR DE EL FORM CITA
        /// MÉTODOS: ACEPTAR, BUSCAR(LLAMAR AL FORM) Y CARGAR PACIENTES
        /// 
        private void btnBuscar_Click(object sender, EventArgs e)
        {
            formularioBuscar = new FrmBuscarPaciente();
            //se especifica que se quiere usar el evento Aceptar
            formularioBuscar.Aceptar += new EventHandler(Aceptar);
            formularioBuscar.ShowDialog();
        }



        private void Aceptar(Object id, EventArgs e) //ACEPTAR
        {
            try
            {
                int idPaciente = (int)id;
                if (idPaciente != -1)
                {
                    //MessageBox.Show(idCliente.ToString());
                    //CargarListaPacientes(idPaciente.ToString());
                    CargarPacientes(idPaciente);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//fin aceptar


        public void LimpiarCampos()
        {
            txtIdPaciente.Text = string.Empty;
            txtNombre.Text = string.Empty;
            txtApellido.Text = string.Empty;
            txtFechaN.Text = string.Empty;
            txtDireccion.Text = string.Empty;
            txtTelefono.Text = string.Empty;
            txtNombre.Focus();
        }




        private void CargarPacientes(int id)
        {
            EntidadPaciente paciente = new EntidadPaciente();
            BLPaciente traerPaciente = new BLPaciente(Configuracion.getConnectionString);
            try
            {
                paciente = traerPaciente.ObtenerPaciente(id);

                if (paciente != null)
                {
                    txtIdPaciente.Text = paciente.Id_Paciente.ToString();
                    txtNombre.Text = paciente.Nombre;
                    txtApellido.Text = paciente.Apellido;
                    txtFechaN.Text = paciente.FechaNacimiento.ToString();
                    //DateTime.TryParse(txtFechaN.Text, out DateTime fechaNacimiento);
                    //paciente.FechaNacimiento= fechaNacimiento;
                    //txtFechaN.Text = paciente.FechaNacimiento.ToString();
                    txtDireccion.Text = paciente.Direccion;
                    txtTelefono.Text = paciente.Telefono;
                    //txtID_Paciente.Text = paciente.Id_Paciente.ToString(); //carga automáticamente el id del paciente seleccionado
                }
                else
                {
                    MessageBox.Show("El paciente no se encuentra en la base de datos",
                        "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    //CargarListaPacientes();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin cargar cliente
         //TERMINA PROCESO DE VISUALIZAR PACIENTES EN LA PARTE SUPERIOR DEL FORM CITA
         /////////////////////////////////////////////////////////////




        //LOAD QUE CONTIENE TODOS LOS COMBOBOX Y DEMÁS ELEMENTOS QUE SE CARGARÁN CUANDO SE HABRA EL FORM
        private void FRMCITA2_Load(object sender, EventArgs e)
        {
            BLCita2 blCita2 = new BLCita2(Configuracion.getConnectionString);

            try
            {
                List<string> idsMedicos = blCita2.ObtenerIdMedicos();

                foreach (string idM in idsMedicos)
                {
                    cboId_Medicos.Items.Add(idM);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar las especialidades: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            //fin del primer combobox que carga el id de los médicos


            //ID_PACIENTE COMBOBOX

            try
            {
                List<string> idsPacientes = blCita2.ObtenerIdPacientes();

                foreach (string idPA in idsPacientes)
                {
                    cbo_ID_Pacientes.Items.Add(idPA);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar las especialidades: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            ////ID_MEDICO, Nombre del doctor y su especialidad
            ///
            try
            {
                List<string> especialidades = blCita2.ObtenerMedicosPorEspecialidad();

                foreach (string especialidad in especialidades)
                {
                    cbEspecialidades.Items.Add(especialidad);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar las especialidades: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


            try
            {
                List<string> idPagos = blCita2.ObtenerIdPagos();

                foreach (string idPag in idPagos)
                {
                    cbIDPagos.Items.Add(idPag);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar las especialidades: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            ///////////////////////////FIN DE LO RELACIONADO A LOS COMBOBOX


            try   //cargamos la lista de pacientes al cargar el formulario y se muestra en el datagridview
            {
                CargarListaCitas();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }




        }//FIN LOAD


        //

        public EntidadCita generaCita()
        {
            EntidadCita cita;
            if (!string.IsNullOrEmpty(txtID_Cita.Text))
            {
                cita = citaRegistrada; // Utiliza la cita existente si el campo txtID_Cita no está vacío
            }
            else
            {
                cita = new EntidadCita(); // Crea una nueva cita si el campo txtID_Cita está vacío
            }

            EntidadCita unaCita = new EntidadCita();
            /*
            
            unaCita.Id_cita = Convert.ToInt32(txtID_Cita.Text);
            unaCita.Fecha = dtCalendario.Value.Date;
            unaCita.Hora = TimeSpan.Parse(txtHoraCita.Text);
            unaCita.Descripcion = txtDescripcion.Text;
            unaCita.Id_medico = Convert.ToInt32(cboId_Medicos.SelectedValue);
            unaCita.Id_pago = Convert.ToInt32(cbIDPagos.SelectedValue);
            unaCita.Id_paciente = Convert.ToInt32(cbo_ID_Pacientes.SelectedValue);
            unaCita.Detalle_Medico = cbEspecialidades.SelectedItem.ToString();
            */
            //EntidadCita cita;
            if (!string.IsNullOrEmpty(txtID_Cita.Text))
            {
                cita = citaRegistrada; // Utiliza la cita existente si el campo txtID_Cita no está vacío
            }
            else
            {
                cita = new EntidadCita(); // Crea una nueva cita si el campo txtID_Cita está vacío
            }

            //EntidadCita unaCita = new EntidadCita();



            int idCita;
            if (int.TryParse(txtID_Cita.Text, out idCita))
            {
                unaCita.Id_cita = idCita;
            }
            else
            {
                unaCita.Id_cita = 0;
                //MessageBox.Show("El valor del campo ID Cita no es válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                // Otra acción apropiada
            }


            unaCita.Fecha = dtCalendario.Value.Date;


            TimeSpan horaCita;
            if (TimeSpan.TryParse(txtHoraCita.Text, out horaCita))
            {
                unaCita.Hora = horaCita;
            }
            else
            {
                MessageBox.Show("El valor del campo Hora Cita no es válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                // Otra acción apropiada
            }


            unaCita.Descripcion = txtDescripcion.Text;

            int idMedico;
            if (int.TryParse(cboId_Medicos.Text, out idMedico))
            {
                unaCita.Id_medico = idMedico;
            }
            else
            {
                MessageBox.Show("El valor del campo ID Médico no es válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                // Otra acción apropiada
            }

            /*
            if (int.TryParse(cboId_Medicos.SelectedValue.ToString(), out idMedico))
            {
                unaCita.Id_medico = idMedico;
            }
            else
            {
                MessageBox.Show("El valor del campo ID Médico no es válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                // Otra acción apropiada
            }
            */
            int idPago;
            if (int.TryParse(cbIDPagos.Text, out idPago))
            {
                unaCita.Id_pago = idPago;
            }
            else
            {
                MessageBox.Show("El valor del campo ID Pago no es válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                // Otra acción apropiada
            }

            int idPaciente;
            if (int.TryParse(cbo_ID_Pacientes.Text, out idPaciente))
            {
                unaCita.Id_paciente = idPaciente;
            }
            else
            {
                MessageBox.Show("El valor del campo ID Paciente no es válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                // Otra acción apropiada
            }
            /*
            string detalleMedico = string.Empty;
            foreach (var item in cbEspecialidades.Items)
            {
                detalleMedico += item.ToString() + " ";
            }
            unaCita.Detalle_Medico = detalleMedico.Trim();
            */
            if (cbEspecialidades.SelectedItem != null)
            {
                unaCita.Detalle_Medico = cbEspecialidades.SelectedItem.ToString();
            }
            else
            {
                unaCita.Detalle_Medico = string.Empty;
            }



            return unaCita;
        }

        ///FIN
        ///



        private void btnGuardar_Click(object sender, EventArgs e)
        {
            EntidadCita cita = new EntidadCita();
            BLCita2 logicaCita = new BLCita2(Configuracion.getConnectionString);
            int resultado;

            try
            {
                // Validar que los campos obligatorios no estén vacíos
                if (!string.IsNullOrEmpty(cbo_ID_Pacientes.Text) && !string.IsNullOrEmpty(cboId_Medicos.Text) && !string.IsNullOrEmpty(cbIDPagos.Text) && !string.IsNullOrEmpty(dtCalendario.Text) && !string.IsNullOrEmpty(txtHoraCita.Text) && !string.IsNullOrEmpty(cbEspecialidades.Text) && !string.IsNullOrEmpty(txtDescripcion.Text))
                {
                    cita = generaCita();
                    if (!cita.Existe)
                    {
                        resultado = logicaCita.LlamarMetodoInsertar(cita);
                    }
                    else
                    {
                        resultado = logicaCita.ModificarCita(cita);
                    }
                    if (resultado > 0)
                    {
                        LimpiarCampos();
                        MessageBox.Show("Operación exitosa", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        CargarListaCitas();
                    }
                    else
                    {
                        MessageBox.Show("No se realizaron cambios", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("Todos los campos son obligatorios", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//fin

        ////////////////////////////



        public void LimpiarCampos2()
        {
            txtID_Cita.Text = string.Empty;
            cbo_ID_Pacientes.SelectedIndex = -1;
            cboId_Medicos.SelectedIndex = -1;
            cbIDPagos.SelectedIndex = -1;
            dtCalendario.Value = DateTime.Now;
            txtHoraCita.Text = string.Empty;
            cbEspecialidades.SelectedIndex = -1;
            txtDescripcion.Text = string.Empty;
            txtID_Cita.Focus();
        }

        ////////////////////////////////////////
        ///


        public void CargarListaCitas(string condicion = "")
        {
            BLCita2 logicaCita = new BLCita2(Configuracion.getConnectionString);
            List<EntidadCita> listaCitas;

            try
            {
                // Llamar al método de la capa lógica para obtener la lista de citas
                listaCitas = logicaCita.LlamarListaCitas(condicion);

                // Comprobar si la lista de citas contiene registros
                if (listaCitas.Count > 0)
                {
                    // Asignar la lista como origen de datos del DataGridView
                    grdCitas.DataSource = listaCitas;
                }
            }
            catch (Exception ex)
            {
                // Mostrar un mensaje de error en caso de excepción
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        private void Aceptar2(Object id, EventArgs e) //ACEPTAR
        {
            try
            {
                int idCita = (int)id;
                if (idCita != -1)
                {
                    //MessageBox.Show(idCliente.ToString());
                    //CargarListaPacientes(idPaciente.ToString());
                    CargarCitas(idCita);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//fin aceptar




        private void button1_Click(object sender, EventArgs e)
        {
            formularioBuscar2 = new FrmBUSCARCITAS();
            //se especifica que se quiere usar el evento Aceptar
            formularioBuscar2.Aceptar2 += new EventHandler(Aceptar2);
            formularioBuscar2.ShowDialog();
        }



        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }



        private void CargarCitas(int id)
        {
            EntidadCita cita = new EntidadCita();
            BLCita2 logicaCita = new BLCita2(Configuracion.getConnectionString);
            try
            {
                cita = logicaCita.ObtenerCita(id);

                if (cita != null)
                {
                    txtID_Cita.Text = cita.Id_cita.ToString();
                    cbo_ID_Pacientes.Text = cita.Id_paciente.ToString();
                    cboId_Medicos.Text = cita.Id_medico.ToString();
                    cbIDPagos.Text = cita.Id_pago.ToString();
                    dtCalendario.Value = cita.Fecha;
                    txtHoraCita.Text = cita.Hora.ToString();
                    cbEspecialidades.Text = cita.Detalle_Medico;
                    txtDescripcion.Text = cita.Descripcion;
                }
                else
                {
                    MessageBox.Show("La cita no se encuentra en la base de datos",
                        "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    // Aquí puedes realizar alguna acción adicional, como limpiar los campos
                    LimpiarCampos();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            LimpiarCampos2();
        }


        private void btnEliminar_Click(object sender, EventArgs e)
        {
            EntidadCita cita;
            int resultado;
            BLCita2 logica = new BLCita2(Configuracion.getConnectionString);
            try
            {
                if (!string.IsNullOrEmpty(txtID_Cita.Text))
                {
                    cita = logica.ObtenerCita(int.Parse(txtID_Cita.Text));
                    if (cita != null)
                    {
                        resultado = logica.EliminarCita(cita);
                        MessageBox.Show("Se ha eliminado el registro", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LimpiarCampos();
                        CargarListaCitas();
                    }
                    else
                    {
                        MessageBox.Show("La cita no existe", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        LimpiarCampos();
                        CargarListaCitas();
                    }
                }
                else
                {
                    MessageBox.Show("Debe seleccionar una cita antes de eliminar", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }















    }






}
