﻿namespace Capa01_Presentación
{
    partial class FRMCITA2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FRMCITA2));
            gbPacienteRegistrado = new System.Windows.Forms.GroupBox();
            label6 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            txtNombre = new System.Windows.Forms.TextBox();
            txtFechaN = new System.Windows.Forms.MaskedTextBox();
            txtApellido = new System.Windows.Forms.TextBox();
            label1 = new System.Windows.Forms.Label();
            btnBuscar = new System.Windows.Forms.Button();
            txtDireccion = new System.Windows.Forms.TextBox();
            txtTelefono = new System.Windows.Forms.TextBox();
            txtIdPaciente = new System.Windows.Forms.TextBox();
            gbAsignarCita = new System.Windows.Forms.GroupBox();
            cbIDPagos = new System.Windows.Forms.ComboBox();
            cbo_ID_Pacientes = new System.Windows.Forms.ComboBox();
            cboId_Medicos = new System.Windows.Forms.ComboBox();
            label10 = new System.Windows.Forms.Label();
            label8 = new System.Windows.Forms.Label();
            dtCalendario = new System.Windows.Forms.DateTimePicker();
            label14 = new System.Windows.Forms.Label();
            cbEspecialidades = new System.Windows.Forms.ComboBox();
            txtHoraCita = new System.Windows.Forms.MaskedTextBox();
            label13 = new System.Windows.Forms.Label();
            txtID_Cita = new System.Windows.Forms.TextBox();
            label7 = new System.Windows.Forms.Label();
            label9 = new System.Windows.Forms.Label();
            label11 = new System.Windows.Forms.Label();
            label12 = new System.Windows.Forms.Label();
            txtDescripcion = new System.Windows.Forms.TextBox();
            grdCitas = new System.Windows.Forms.DataGridView();
            button1 = new System.Windows.Forms.Button();
            btnEliminar = new System.Windows.Forms.Button();
            btnNuevo = new System.Windows.Forms.Button();
            btnGuardar = new System.Windows.Forms.Button();
            btnSalir = new System.Windows.Forms.Button();
            Id_cita = new System.Windows.Forms.DataGridViewTextBoxColumn();
            Fecha = new System.Windows.Forms.DataGridViewTextBoxColumn();
            Hora = new System.Windows.Forms.DataGridViewTextBoxColumn();
            Descripcion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            Id_medico = new System.Windows.Forms.DataGridViewTextBoxColumn();
            Id_pago = new System.Windows.Forms.DataGridViewTextBoxColumn();
            id_paciente = new System.Windows.Forms.DataGridViewTextBoxColumn();
            Detalle_Medico = new System.Windows.Forms.DataGridViewTextBoxColumn();
            Estado_Pago = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            gbPacienteRegistrado.SuspendLayout();
            gbAsignarCita.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)grdCitas).BeginInit();
            SuspendLayout();
            // 
            // gbPacienteRegistrado
            // 
            gbPacienteRegistrado.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            gbPacienteRegistrado.Controls.Add(label6);
            gbPacienteRegistrado.Controls.Add(label5);
            gbPacienteRegistrado.Controls.Add(label4);
            gbPacienteRegistrado.Controls.Add(label3);
            gbPacienteRegistrado.Controls.Add(label2);
            gbPacienteRegistrado.Controls.Add(txtNombre);
            gbPacienteRegistrado.Controls.Add(txtFechaN);
            gbPacienteRegistrado.Controls.Add(txtApellido);
            gbPacienteRegistrado.Controls.Add(label1);
            gbPacienteRegistrado.Controls.Add(btnBuscar);
            gbPacienteRegistrado.Controls.Add(txtDireccion);
            gbPacienteRegistrado.Controls.Add(txtTelefono);
            gbPacienteRegistrado.Controls.Add(txtIdPaciente);
            gbPacienteRegistrado.Location = new System.Drawing.Point(11, 12);
            gbPacienteRegistrado.Name = "gbPacienteRegistrado";
            gbPacienteRegistrado.Size = new System.Drawing.Size(960, 205);
            gbPacienteRegistrado.TabIndex = 1;
            gbPacienteRegistrado.TabStop = false;
            gbPacienteRegistrado.Text = "Datos del Paciente";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new System.Drawing.Point(84, 137);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(85, 25);
            label6.TabIndex = 81;
            label6.Text = "Dirección";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new System.Drawing.Point(851, 23);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(79, 25);
            label5.TabIndex = 80;
            label5.Text = "Teléfono";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new System.Drawing.Point(639, 23);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(154, 25);
            label4.TabIndex = 79;
            label4.Text = "Fecha_Nacimiento";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new System.Drawing.Point(503, 23);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(78, 25);
            label3.TabIndex = 78;
            label3.Text = "Apellido";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(348, 23);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(78, 25);
            label2.TabIndex = 77;
            label2.Text = "Nombre";
            // 
            // txtNombre
            // 
            txtNombre.BackColor = System.Drawing.SystemColors.Info;
            txtNombre.Location = new System.Drawing.Point(328, 51);
            txtNombre.Name = "txtNombre";
            txtNombre.ReadOnly = true;
            txtNombre.Size = new System.Drawing.Size(117, 31);
            txtNombre.TabIndex = 75;
            // 
            // txtFechaN
            // 
            txtFechaN.BackColor = System.Drawing.SystemColors.Info;
            txtFechaN.Location = new System.Drawing.Point(641, 51);
            txtFechaN.Mask = "00/00/0000";
            txtFechaN.Name = "txtFechaN";
            txtFechaN.ReadOnly = true;
            txtFechaN.Size = new System.Drawing.Size(152, 31);
            txtFechaN.TabIndex = 76;
            txtFechaN.ValidatingType = typeof(System.DateTime);
            // 
            // txtApellido
            // 
            txtApellido.BackColor = System.Drawing.SystemColors.Info;
            txtApellido.Location = new System.Drawing.Point(486, 51);
            txtApellido.Multiline = true;
            txtApellido.Name = "txtApellido";
            txtApellido.ReadOnly = true;
            txtApellido.Size = new System.Drawing.Size(112, 31);
            txtApellido.TabIndex = 73;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(175, 23);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(101, 25);
            label1.TabIndex = 75;
            label1.Text = "ID_Paciente";
            // 
            // btnBuscar
            // 
            btnBuscar.Image = (System.Drawing.Image)resources.GetObject("btnBuscar.Image");
            btnBuscar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnBuscar.Location = new System.Drawing.Point(33, 51);
            btnBuscar.Name = "btnBuscar";
            btnBuscar.Size = new System.Drawing.Size(102, 62);
            btnBuscar.TabIndex = 74;
            btnBuscar.Text = "&Buscar";
            btnBuscar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            btnBuscar.UseVisualStyleBackColor = true;
            btnBuscar.Click += btnBuscar_Click;
            // 
            // txtDireccion
            // 
            txtDireccion.BackColor = System.Drawing.SystemColors.Info;
            txtDireccion.Location = new System.Drawing.Point(175, 121);
            txtDireccion.Multiline = true;
            txtDireccion.Name = "txtDireccion";
            txtDireccion.ReadOnly = true;
            txtDireccion.Size = new System.Drawing.Size(745, 56);
            txtDireccion.TabIndex = 72;
            // 
            // txtTelefono
            // 
            txtTelefono.BackColor = System.Drawing.SystemColors.Info;
            txtTelefono.Location = new System.Drawing.Point(831, 51);
            txtTelefono.Name = "txtTelefono";
            txtTelefono.ReadOnly = true;
            txtTelefono.Size = new System.Drawing.Size(89, 31);
            txtTelefono.TabIndex = 71;
            // 
            // txtIdPaciente
            // 
            txtIdPaciente.BackColor = System.Drawing.SystemColors.Info;
            txtIdPaciente.Location = new System.Drawing.Point(175, 51);
            txtIdPaciente.Name = "txtIdPaciente";
            txtIdPaciente.ReadOnly = true;
            txtIdPaciente.Size = new System.Drawing.Size(89, 31);
            txtIdPaciente.TabIndex = 70;
            // 
            // gbAsignarCita
            // 
            gbAsignarCita.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            gbAsignarCita.Controls.Add(cbIDPagos);
            gbAsignarCita.Controls.Add(cbo_ID_Pacientes);
            gbAsignarCita.Controls.Add(cboId_Medicos);
            gbAsignarCita.Controls.Add(label10);
            gbAsignarCita.Controls.Add(label8);
            gbAsignarCita.Controls.Add(dtCalendario);
            gbAsignarCita.Controls.Add(label14);
            gbAsignarCita.Controls.Add(cbEspecialidades);
            gbAsignarCita.Controls.Add(txtHoraCita);
            gbAsignarCita.Controls.Add(label13);
            gbAsignarCita.Controls.Add(txtID_Cita);
            gbAsignarCita.Controls.Add(label7);
            gbAsignarCita.Controls.Add(label9);
            gbAsignarCita.Controls.Add(label11);
            gbAsignarCita.Controls.Add(label12);
            gbAsignarCita.Controls.Add(txtDescripcion);
            gbAsignarCita.Location = new System.Drawing.Point(11, 247);
            gbAsignarCita.Name = "gbAsignarCita";
            gbAsignarCita.Size = new System.Drawing.Size(960, 267);
            gbAsignarCita.TabIndex = 2;
            gbAsignarCita.TabStop = false;
            gbAsignarCita.Text = "Datos de la Cita";
            // 
            // cbIDPagos
            // 
            cbIDPagos.DisplayMember = "Id_pago";
            cbIDPagos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            cbIDPagos.FormattingEnabled = true;
            cbIDPagos.Location = new System.Drawing.Point(439, 95);
            cbIDPagos.Name = "cbIDPagos";
            cbIDPagos.Size = new System.Drawing.Size(89, 33);
            cbIDPagos.TabIndex = 94;
            cbIDPagos.ValueMember = "Id_pago";
            // 
            // cbo_ID_Pacientes
            // 
            cbo_ID_Pacientes.DisplayMember = "Id_paciente";
            cbo_ID_Pacientes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            cbo_ID_Pacientes.FormattingEnabled = true;
            cbo_ID_Pacientes.Location = new System.Drawing.Point(221, 94);
            cbo_ID_Pacientes.Name = "cbo_ID_Pacientes";
            cbo_ID_Pacientes.Size = new System.Drawing.Size(89, 33);
            cbo_ID_Pacientes.TabIndex = 93;
            cbo_ID_Pacientes.ValueMember = "Id_paciente";
            // 
            // cboId_Medicos
            // 
            cboId_Medicos.DisplayMember = "Id_medico";
            cboId_Medicos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            cboId_Medicos.FormattingEnabled = true;
            cboId_Medicos.Location = new System.Drawing.Point(439, 36);
            cboId_Medicos.Name = "cboId_Medicos";
            cboId_Medicos.Size = new System.Drawing.Size(89, 33);
            cboId_Medicos.TabIndex = 92;
            cboId_Medicos.ValueMember = "Id_medico";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new System.Drawing.Point(328, 100);
            label10.Name = "label10";
            label10.Size = new System.Drawing.Size(84, 25);
            label10.TabIndex = 91;
            label10.Text = "ID_PAGO";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new System.Drawing.Point(328, 39);
            label8.Name = "label8";
            label8.Size = new System.Drawing.Size(105, 25);
            label8.TabIndex = 90;
            label8.Text = "ID_MEDICO";
            // 
            // dtCalendario
            // 
            dtCalendario.Location = new System.Drawing.Point(700, 39);
            dtCalendario.Name = "dtCalendario";
            dtCalendario.Size = new System.Drawing.Size(234, 31);
            dtCalendario.TabIndex = 87;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new System.Drawing.Point(7, 147);
            label14.Name = "label14";
            label14.Size = new System.Drawing.Size(185, 25);
            label14.TabIndex = 86;
            label14.Text = "Médico de la consulta";
            // 
            // cbEspecialidades
            // 
            cbEspecialidades.FormattingEnabled = true;
            cbEspecialidades.Location = new System.Drawing.Point(221, 144);
            cbEspecialidades.Name = "cbEspecialidades";
            cbEspecialidades.Size = new System.Drawing.Size(722, 33);
            cbEspecialidades.TabIndex = 85;
            // 
            // txtHoraCita
            // 
            txtHoraCita.Location = new System.Drawing.Point(700, 97);
            txtHoraCita.Mask = "00:00";
            txtHoraCita.Name = "txtHoraCita";
            txtHoraCita.Size = new System.Drawing.Size(117, 31);
            txtHoraCita.TabIndex = 84;
            txtHoraCita.ValidatingType = typeof(System.DateTime);
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new System.Drawing.Point(125, 46);
            label13.Name = "label13";
            label13.Size = new System.Drawing.Size(67, 25);
            label13.TabIndex = 83;
            label13.Text = "ID_Cita";
            // 
            // txtID_Cita
            // 
            txtID_Cita.BackColor = System.Drawing.SystemColors.Info;
            txtID_Cita.Location = new System.Drawing.Point(221, 40);
            txtID_Cita.Name = "txtID_Cita";
            txtID_Cita.ReadOnly = true;
            txtID_Cita.Size = new System.Drawing.Size(89, 31);
            txtID_Cita.TabIndex = 82;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new System.Drawing.Point(84, 207);
            label7.Name = "label7";
            label7.Size = new System.Drawing.Size(104, 25);
            label7.TabIndex = 81;
            label7.Text = "Descripción";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new System.Drawing.Point(573, 42);
            label9.Name = "label9";
            label9.Size = new System.Drawing.Size(94, 25);
            label9.TabIndex = 79;
            label9.Text = "Fecha_Cita";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new System.Drawing.Point(579, 97);
            label11.Name = "label11";
            label11.Size = new System.Drawing.Size(88, 25);
            label11.TabIndex = 77;
            label11.Text = "Hora_Cita";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new System.Drawing.Point(87, 97);
            label12.Name = "label12";
            label12.Size = new System.Drawing.Size(101, 25);
            label12.TabIndex = 75;
            label12.Text = "ID_Paciente";
            // 
            // txtDescripcion
            // 
            txtDescripcion.BackColor = System.Drawing.SystemColors.Control;
            txtDescripcion.Location = new System.Drawing.Point(221, 195);
            txtDescripcion.Multiline = true;
            txtDescripcion.Name = "txtDescripcion";
            txtDescripcion.Size = new System.Drawing.Size(722, 66);
            txtDescripcion.TabIndex = 72;
            // 
            // grdCitas
            // 
            grdCitas.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            grdCitas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            grdCitas.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] { Id_cita, Fecha, Hora, Descripcion, Id_medico, Id_pago, id_paciente, Detalle_Medico, Estado_Pago });
            grdCitas.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            grdCitas.Location = new System.Drawing.Point(11, 539);
            grdCitas.Name = "grdCitas";
            grdCitas.RowHeadersWidth = 62;
            grdCitas.RowTemplate.Height = 33;
            grdCitas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            grdCitas.Size = new System.Drawing.Size(960, 148);
            grdCitas.TabIndex = 3;
            // 
            // button1
            // 
            button1.Image = (System.Drawing.Image)resources.GetObject("button1.Image");
            button1.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            button1.Location = new System.Drawing.Point(113, 709);
            button1.Name = "button1";
            button1.Size = new System.Drawing.Size(111, 95);
            button1.TabIndex = 67;
            button1.Text = "&Buscar";
            button1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // btnEliminar
            // 
            btnEliminar.Image = (System.Drawing.Image)resources.GetObject("btnEliminar.Image");
            btnEliminar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            btnEliminar.Location = new System.Drawing.Point(279, 709);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new System.Drawing.Size(111, 95);
            btnEliminar.TabIndex = 66;
            btnEliminar.Text = "&Eliminar";
            btnEliminar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btnEliminar.UseVisualStyleBackColor = true;
            btnEliminar.Click += btnEliminar_Click;
            // 
            // btnNuevo
            // 
            btnNuevo.Image = (System.Drawing.Image)resources.GetObject("btnNuevo.Image");
            btnNuevo.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            btnNuevo.Location = new System.Drawing.Point(611, 709);
            btnNuevo.Name = "btnNuevo";
            btnNuevo.Size = new System.Drawing.Size(111, 95);
            btnNuevo.TabIndex = 65;
            btnNuevo.Text = "&Nuevo";
            btnNuevo.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btnNuevo.UseVisualStyleBackColor = true;
            btnNuevo.Click += btnNuevo_Click;
            // 
            // btnGuardar
            // 
            btnGuardar.Image = (System.Drawing.Image)resources.GetObject("btnGuardar.Image");
            btnGuardar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            btnGuardar.Location = new System.Drawing.Point(445, 709);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new System.Drawing.Size(111, 95);
            btnGuardar.TabIndex = 64;
            btnGuardar.Text = "&Guardar";
            btnGuardar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btnGuardar.UseVisualStyleBackColor = true;
            btnGuardar.Click += btnGuardar_Click;
            // 
            // btnSalir
            // 
            btnSalir.Image = (System.Drawing.Image)resources.GetObject("btnSalir.Image");
            btnSalir.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            btnSalir.Location = new System.Drawing.Point(777, 709);
            btnSalir.Name = "btnSalir";
            btnSalir.Size = new System.Drawing.Size(95, 95);
            btnSalir.TabIndex = 63;
            btnSalir.Text = "&Salir";
            btnSalir.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btnSalir.UseVisualStyleBackColor = true;
            btnSalir.Click += btnSalir_Click;
            // 
            // Id_cita
            // 
            Id_cita.DataPropertyName = "ID_CITA";
            Id_cita.HeaderText = "Id_cita";
            Id_cita.MinimumWidth = 8;
            Id_cita.Name = "Id_cita";
            Id_cita.ReadOnly = true;
            Id_cita.Width = 150;
            // 
            // Fecha
            // 
            Fecha.DataPropertyName = "FECHA";
            Fecha.HeaderText = "Fecha";
            Fecha.MinimumWidth = 8;
            Fecha.Name = "Fecha";
            Fecha.Width = 150;
            // 
            // Hora
            // 
            Hora.DataPropertyName = "HORA";
            Hora.HeaderText = "Hora";
            Hora.MinimumWidth = 8;
            Hora.Name = "Hora";
            Hora.Width = 150;
            // 
            // Descripcion
            // 
            Descripcion.DataPropertyName = "DESCRIPCION";
            Descripcion.HeaderText = "Descripción";
            Descripcion.MinimumWidth = 8;
            Descripcion.Name = "Descripcion";
            Descripcion.Width = 150;
            // 
            // Id_medico
            // 
            Id_medico.DataPropertyName = "ID_MEDICO";
            Id_medico.HeaderText = "Id_Médico";
            Id_medico.MinimumWidth = 8;
            Id_medico.Name = "Id_medico";
            Id_medico.Visible = false;
            Id_medico.Width = 150;
            // 
            // Id_pago
            // 
            Id_pago.DataPropertyName = "ID_PAGO";
            Id_pago.HeaderText = "Id_Pago";
            Id_pago.MinimumWidth = 8;
            Id_pago.Name = "Id_pago";
            Id_pago.Visible = false;
            Id_pago.Width = 150;
            // 
            // id_paciente
            // 
            id_paciente.DataPropertyName = "ID_PACIENTE";
            id_paciente.HeaderText = "Id_Paciente";
            id_paciente.MinimumWidth = 8;
            id_paciente.Name = "id_paciente";
            id_paciente.Width = 150;
            // 
            // Detalle_Medico
            // 
            Detalle_Medico.DataPropertyName = "DETALLE_MEDICO";
            Detalle_Medico.HeaderText = "Detalle_Médico";
            Detalle_Medico.MinimumWidth = 8;
            Detalle_Medico.Name = "Detalle_Medico";
            Detalle_Medico.Width = 150;
            // 
            // Estado_Pago
            // 
            Estado_Pago.DataPropertyName = "Estado_Pago";
            Estado_Pago.HeaderText = "Estado_Pago";
            Estado_Pago.MinimumWidth = 8;
            Estado_Pago.Name = "Estado_Pago";
            Estado_Pago.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            Estado_Pago.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            Estado_Pago.Width = 150;
            // 
            // FRMCITA2
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(983, 827);
            Controls.Add(button1);
            Controls.Add(btnEliminar);
            Controls.Add(btnNuevo);
            Controls.Add(btnGuardar);
            Controls.Add(btnSalir);
            Controls.Add(grdCitas);
            Controls.Add(gbAsignarCita);
            Controls.Add(gbPacienteRegistrado);
            MaximizeBox = false;
            Name = "FRMCITA2";
            StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            Text = "Registro de Citas";
            Load += FRMCITA2_Load;
            gbPacienteRegistrado.ResumeLayout(false);
            gbPacienteRegistrado.PerformLayout();
            gbAsignarCita.ResumeLayout(false);
            gbAsignarCita.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)grdCitas).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.GroupBox gbPacienteRegistrado;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.MaskedTextBox txtFechaN;
        private System.Windows.Forms.TextBox txtApellido;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnBuscar;
        private System.Windows.Forms.TextBox txtDireccion;
        private System.Windows.Forms.TextBox txtTelefono;
        private System.Windows.Forms.TextBox txtIdPaciente;
        private System.Windows.Forms.GroupBox gbAsignarCita;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox cbEspecialidades;
        private System.Windows.Forms.MaskedTextBox txtHoraCita;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtID_Cita;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtDescripcion;
        private System.Windows.Forms.TextBox txtID_Paciente;
        private System.Windows.Forms.DateTimePicker dtCalendario;
        private System.Windows.Forms.DataGridView grdCitas;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtID_PAGO;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.Button btnNuevo;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.ComboBox cboId_Medicos;
        private System.Windows.Forms.ComboBox cbo_ID_Pacientes;
        private System.Windows.Forms.ComboBox cbIDPagos;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id_cita;
        private System.Windows.Forms.DataGridViewTextBoxColumn Fecha;
        private System.Windows.Forms.DataGridViewTextBoxColumn Hora;
        private System.Windows.Forms.DataGridViewTextBoxColumn Descripcion;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id_medico;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id_pago;
        private System.Windows.Forms.DataGridViewTextBoxColumn id_paciente;
        private System.Windows.Forms.DataGridViewTextBoxColumn Detalle_Medico;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Estado_Pago;
    }
}