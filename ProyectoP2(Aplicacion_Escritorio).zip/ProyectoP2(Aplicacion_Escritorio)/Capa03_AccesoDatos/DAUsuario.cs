﻿using CapaEntidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Linq;

namespace Capa03_AccesoDatos
{
    public class DAUsuario
    {
        private string _cadenaConexion;
        private string _mensaje;

        //propiedes

        public string Mensaje
        {
            get => _mensaje;
        }

        public DAUsuario(string cadenaConexion)
        {
            _cadenaConexion = cadenaConexion;
            _mensaje = string.Empty;
        }



        public int Insertar(EntidadUsuario usuario)
        {
            int id = 0;
            //Establecer el objeto de conexión
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            //Establecer el objeto para ejecutar los comandos SQL
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            string sentencia = "INSERT INTO USUARIO (NOMBRE_USUARIO, CLAVE)" +
                " VALUES( @NOMBRE_USUARIO, @CLAVE) SELECT @@IDENTITY";
            comando.Parameters.AddWithValue("@NOMBRE_USUARIO", usuario.NombreUsuario);
            comando.Parameters.AddWithValue("@CLAVE", usuario.Clave);
            comando.CommandText = sentencia;
            try
            {
                conexion.Open();
                id = Convert.ToInt32(comando.ExecuteScalar());
                conexion.Close();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conexion.Dispose();
                comando.Dispose();
            }
            return id;
        }  //Fin de insertar (Hasta aquí es el procedimiento para insertar en la base de datos y guardar)
        //////////////////////////////////////////////////////////////////////////////////////////////////

      
        
        public List<EntidadUsuario> ListarUsuarios(string condicion = "")
        {
            List<EntidadUsuario> listaUsuarios = new List<EntidadUsuario>();

            using (SqlConnection conexion = new SqlConnection(_cadenaConexion))
            {
                string instruccionDB = "SELECT ID_USUARIO, ID_ROL, NOMBRE_USUARIO, CLAVE FROM USUARIO";

                if (!string.IsNullOrEmpty(condicion))
                {
                    instruccionDB += " WHERE " + condicion;
                }

                using (SqlCommand comando = new SqlCommand(instruccionDB, conexion))
                {
                    try
                    {
                        conexion.Open();

                        using (SqlDataReader dataReader = comando.ExecuteReader())
                        {
                            while (dataReader.Read())
                            {
                                EntidadUsuario usuario = new EntidadUsuario()
                                {
                                    Id_usuario = dataReader.GetInt32(0),
                                    Id_rol = dataReader.GetInt32(1),
                                    NombreUsuario = dataReader.GetString(2),
                                    Clave = dataReader.GetString(3)
                                };

                                listaUsuarios.Add(usuario);
                            }
                        }

                        conexion.Close();
                    }
                    catch (Exception)
                    {
                        throw;
                    }
                }
            }

            return listaUsuarios;
            
        }
        
        


        



        public EntidadUsuario ObtenerUsuario(int id)
        {
            EntidadUsuario usuario = null;
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            SqlDataReader dataReader;
            string sentencia = string.Format("SELECT ID_USUARIO, ID_ROL, NOMBRE_USUARIO, CLAVE FROM " +
                "USUARIO WHERE ID_USUARIO = {0}", id);
            comando.Connection = conexion;
            comando.CommandText = sentencia;
            try
            {
                conexion.Open();
                dataReader = comando.ExecuteReader();
                if (dataReader.HasRows)
                {
                    usuario = new EntidadUsuario();
                    dataReader.Read();
                    usuario.Id_usuario = dataReader.GetInt32(0);
                    usuario.Id_rol = dataReader.GetInt32(1);
                    usuario.NombreUsuario = dataReader.GetString(2);
                    usuario.Clave = dataReader.GetString(3);
                    usuario.Existe = true;
                }
                conexion.Close();
            }
            catch (Exception)
            {
                throw;
            }
            return usuario;
        }







        // (Se elimina el paciente)
        ///
        public int EliminarUsuario(EntidadUsuario usuario)
        {
            int afectado = -1;
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            string sentencia = "DELETE FROM USUARIO WHERE ID_USUARIO = @ID_USUARIO";
            comando.CommandText = sentencia;
            comando.Connection = conexion;
            comando.Parameters.AddWithValue("@ID_USUARIO", usuario.Id_usuario);
            try
            {
                conexion.Open();
                afectado = comando.ExecuteNonQuery();
                conexion.Close();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conexion.Dispose();
                comando.Dispose();
            }
            return afectado;
        }
        //fin eliminar usuario





        // (Actualizar Cliente)
        ///
        public int Modificar(EntidadUsuario usuario)
        {
            int filasAfectadas = -1;
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            string sentencia = "UPDATE USUARIO SET NOMBRE_USUARIO=@NOMBRE_USUARIO, CLAVE=@CLAVE WHERE ID_USUARIO=@ID_USUARIO";
            comando.CommandText = sentencia;
            comando.Connection = conexion;
            comando.Parameters.AddWithValue("@ID_USUARIO", usuario.Id_usuario);
            comando.Parameters.AddWithValue("@NOMBRE_USUARIO", usuario.NombreUsuario);
            comando.Parameters.AddWithValue("@CLAVE", usuario.Clave);
            try
            {
                conexion.Open();
                filasAfectadas = comando.ExecuteNonQuery();
                conexion.Close();

            }
            catch (Exception)
            {
                throw;

            }
            finally
            {
                conexion.Dispose();
                comando.Dispose();
            }
            return filasAfectadas;
        }//modificar fin


    }
}