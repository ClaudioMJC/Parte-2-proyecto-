﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CapaEntidades
{
    public class EntidadRol
    {
        private int id_rol;
        private string nombre;

        public int Id_rol { get => id_rol; set => id_rol = value; }
        public string Nombre { get => nombre; set => nombre = value; }

        public EntidadRol() 
        {
            id_rol = 0;
            nombre = string.Empty;
        }

        public EntidadRol(int id_rol, string nombre)
        {
            this.id_rol = id_rol;
            this.nombre= nombre;
            
        }
        
    }
}
