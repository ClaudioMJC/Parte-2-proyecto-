﻿namespace Capa01_Presentación
{
    partial class FrmRegistrarPaciente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmRegistrarPaciente));
            txtNombre = new System.Windows.Forms.TextBox();
            btnBuscar = new System.Windows.Forms.Button();
            btnEliminar = new System.Windows.Forms.Button();
            btnNuevo = new System.Windows.Forms.Button();
            btnGuardar = new System.Windows.Forms.Button();
            btnSalir = new System.Windows.Forms.Button();
            txtApellido = new System.Windows.Forms.TextBox();
            txtTelefono = new System.Windows.Forms.TextBox();
            txtIdPaciente = new System.Windows.Forms.TextBox();
            grdListaPacientes = new System.Windows.Forms.DataGridView();
            ID_PACIENTE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            NOMBRE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            APELLIDO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            FECHA_NACIMIENTO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            TELEFONO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            DIRECCION = new System.Windows.Forms.DataGridViewTextBoxColumn();
            label1 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            txtDireccion = new System.Windows.Forms.TextBox();
            label6 = new System.Windows.Forms.Label();
            txtFechaN = new System.Windows.Forms.MaskedTextBox();
            ((System.ComponentModel.ISupportInitialize)grdListaPacientes).BeginInit();
            SuspendLayout();
            // 
            // txtNombre
            // 
            txtNombre.Location = new System.Drawing.Point(193, 46);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new System.Drawing.Size(119, 31);
            txtNombre.TabIndex = 63;
            // 
            // btnBuscar
            // 
            btnBuscar.Image = (System.Drawing.Image)resources.GetObject("btnBuscar.Image");
            btnBuscar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            btnBuscar.Location = new System.Drawing.Point(62, 397);
            btnBuscar.Name = "btnBuscar";
            btnBuscar.Size = new System.Drawing.Size(111, 95);
            btnBuscar.TabIndex = 62;
            btnBuscar.Text = "&Buscar";
            btnBuscar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btnBuscar.UseVisualStyleBackColor = true;
            btnBuscar.Click += btnBuscar_Click;
            // 
            // btnEliminar
            // 
            btnEliminar.Image = (System.Drawing.Image)resources.GetObject("btnEliminar.Image");
            btnEliminar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            btnEliminar.Location = new System.Drawing.Point(228, 397);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new System.Drawing.Size(111, 95);
            btnEliminar.TabIndex = 61;
            btnEliminar.Text = "&Eliminar";
            btnEliminar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btnEliminar.UseVisualStyleBackColor = true;
            btnEliminar.Click += btnEliminar_Click;
            // 
            // btnNuevo
            // 
            btnNuevo.Image = (System.Drawing.Image)resources.GetObject("btnNuevo.Image");
            btnNuevo.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            btnNuevo.Location = new System.Drawing.Point(560, 397);
            btnNuevo.Name = "btnNuevo";
            btnNuevo.Size = new System.Drawing.Size(111, 95);
            btnNuevo.TabIndex = 60;
            btnNuevo.Text = "&Nuevo";
            btnNuevo.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btnNuevo.UseVisualStyleBackColor = true;
            btnNuevo.Click += btnNuevo_Click;
            // 
            // btnGuardar
            // 
            btnGuardar.Image = (System.Drawing.Image)resources.GetObject("btnGuardar.Image");
            btnGuardar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            btnGuardar.Location = new System.Drawing.Point(394, 397);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new System.Drawing.Size(111, 95);
            btnGuardar.TabIndex = 59;
            btnGuardar.Text = "&Guardar";
            btnGuardar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btnGuardar.UseVisualStyleBackColor = true;
            btnGuardar.Click += btnGuardar_Click;
            // 
            // btnSalir
            // 
            btnSalir.Image = (System.Drawing.Image)resources.GetObject("btnSalir.Image");
            btnSalir.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            btnSalir.Location = new System.Drawing.Point(726, 397);
            btnSalir.Name = "btnSalir";
            btnSalir.Size = new System.Drawing.Size(95, 95);
            btnSalir.TabIndex = 58;
            btnSalir.Text = "&Salir";
            btnSalir.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btnSalir.UseVisualStyleBackColor = true;
            btnSalir.Click += btnSalir_Click;
            // 
            // txtApellido
            // 
            txtApellido.Location = new System.Drawing.Point(349, 46);
            txtApellido.Multiline = true;
            txtApellido.Name = "txtApellido";
            txtApellido.Size = new System.Drawing.Size(122, 31);
            txtApellido.TabIndex = 57;
            // 
            // txtTelefono
            // 
            txtTelefono.Location = new System.Drawing.Point(710, 45);
            txtTelefono.Name = "txtTelefono";
            txtTelefono.Size = new System.Drawing.Size(111, 31);
            txtTelefono.TabIndex = 55;
            // 
            // txtIdPaciente
            // 
            txtIdPaciente.BackColor = System.Drawing.SystemColors.Info;
            txtIdPaciente.Location = new System.Drawing.Point(51, 45);
            txtIdPaciente.Name = "txtIdPaciente";
            txtIdPaciente.ReadOnly = true;
            txtIdPaciente.Size = new System.Drawing.Size(89, 31);
            txtIdPaciente.TabIndex = 54;
            // 
            // grdListaPacientes
            // 
            grdListaPacientes.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            grdListaPacientes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            grdListaPacientes.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] { ID_PACIENTE, NOMBRE, APELLIDO, FECHA_NACIMIENTO, TELEFONO, DIRECCION });
            grdListaPacientes.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            grdListaPacientes.Location = new System.Drawing.Point(51, 197);
            grdListaPacientes.Name = "grdListaPacientes";
            grdListaPacientes.RowHeadersWidth = 62;
            grdListaPacientes.RowTemplate.Height = 33;
            grdListaPacientes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            grdListaPacientes.Size = new System.Drawing.Size(770, 147);
            grdListaPacientes.TabIndex = 53;
            // 
            // ID_PACIENTE
            // 
            ID_PACIENTE.DataPropertyName = "ID_PACIENTE";
            ID_PACIENTE.HeaderText = "ID_PACIENTE";
            ID_PACIENTE.MinimumWidth = 8;
            ID_PACIENTE.Name = "ID_PACIENTE";
            ID_PACIENTE.Width = 150;
            // 
            // NOMBRE
            // 
            NOMBRE.DataPropertyName = "NOMBRE";
            NOMBRE.HeaderText = "NOMBRE";
            NOMBRE.MinimumWidth = 8;
            NOMBRE.Name = "NOMBRE";
            NOMBRE.Width = 150;
            // 
            // APELLIDO
            // 
            APELLIDO.DataPropertyName = "APELLIDO";
            APELLIDO.HeaderText = "APELLIDO";
            APELLIDO.MinimumWidth = 8;
            APELLIDO.Name = "APELLIDO";
            APELLIDO.Width = 150;
            // 
            // FECHA_NACIMIENTO
            // 
            FECHA_NACIMIENTO.DataPropertyName = "FECHA_NACIMIENTO";
            FECHA_NACIMIENTO.HeaderText = "FECHA_NACIMIENTO";
            FECHA_NACIMIENTO.MinimumWidth = 8;
            FECHA_NACIMIENTO.Name = "FECHA_NACIMIENTO";
            FECHA_NACIMIENTO.Visible = false;
            FECHA_NACIMIENTO.Width = 150;
            // 
            // TELEFONO
            // 
            TELEFONO.DataPropertyName = "TELEFONO";
            TELEFONO.HeaderText = "TELÉFONO";
            TELEFONO.MinimumWidth = 8;
            TELEFONO.Name = "TELEFONO";
            TELEFONO.Width = 150;
            // 
            // DIRECCION
            // 
            DIRECCION.DataPropertyName = "DIRECCION";
            DIRECCION.HeaderText = "DIRECCIÓN";
            DIRECCION.MinimumWidth = 8;
            DIRECCION.Name = "DIRECCION";
            DIRECCION.Width = 150;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(51, 6);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(101, 25);
            label1.TabIndex = 64;
            label1.Text = "ID_Paciente";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(217, 6);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(78, 25);
            label2.TabIndex = 65;
            label2.Text = "Nombre";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new System.Drawing.Point(375, 9);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(78, 25);
            label3.TabIndex = 66;
            label3.Text = "Apellido";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new System.Drawing.Point(502, 9);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(177, 25);
            label4.TabIndex = 67;
            label4.Text = "Fecha de Nacimiento";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new System.Drawing.Point(740, 9);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(79, 25);
            label5.TabIndex = 68;
            label5.Text = "Teléfono";
            // 
            // txtDireccion
            // 
            txtDireccion.Location = new System.Drawing.Point(52, 120);
            txtDireccion.Multiline = true;
            txtDireccion.Name = "txtDireccion";
            txtDireccion.Size = new System.Drawing.Size(770, 56);
            txtDireccion.TabIndex = 56;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new System.Drawing.Point(51, 91);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(85, 25);
            label6.TabIndex = 68;
            label6.Text = "Dirección";
            // 
            // txtFechaN
            // 
            txtFechaN.Location = new System.Drawing.Point(518, 46);
            txtFechaN.Mask = "00/00/0000";
            txtFechaN.Name = "txtFechaN";
            txtFechaN.Size = new System.Drawing.Size(150, 31);
            txtFechaN.TabIndex = 69;
            txtFechaN.ValidatingType = typeof(System.DateTime);
            // 
            // FrmRegistrarPaciente
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            ClientSize = new System.Drawing.Size(868, 504);
            Controls.Add(txtFechaN);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtNombre);
            Controls.Add(btnBuscar);
            Controls.Add(btnEliminar);
            Controls.Add(btnNuevo);
            Controls.Add(btnGuardar);
            Controls.Add(btnSalir);
            Controls.Add(txtApellido);
            Controls.Add(txtDireccion);
            Controls.Add(txtTelefono);
            Controls.Add(txtIdPaciente);
            Controls.Add(grdListaPacientes);
            MaximizeBox = false;
            Name = "FrmRegistrarPaciente";
            StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            Text = "Registro de Pacientes";
            Load += FrmRegistrarPaciente_Load;
            ((System.ComponentModel.ISupportInitialize)grdListaPacientes).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Button btnBuscar;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.Button btnNuevo;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.TextBox txtApellido;
        private System.Windows.Forms.TextBox txtTelefono;
        private System.Windows.Forms.TextBox txtIdPaciente;
        private System.Windows.Forms.DataGridView grdListaPacientes;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtDireccion;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.MaskedTextBox txtFechaN;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_PACIENTE;
        private System.Windows.Forms.DataGridViewTextBoxColumn NOMBRE;
        private System.Windows.Forms.DataGridViewTextBoxColumn APELLIDO;
        private System.Windows.Forms.DataGridViewTextBoxColumn FECHA_NACIMIENTO;
        private System.Windows.Forms.DataGridViewTextBoxColumn TELEFONO;
        private System.Windows.Forms.DataGridViewTextBoxColumn DIRECCION;
    }
}