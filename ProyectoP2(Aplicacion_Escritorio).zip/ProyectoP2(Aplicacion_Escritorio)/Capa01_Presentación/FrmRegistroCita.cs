﻿using Capa02_LogicaNegocio;
using CapaEntidades;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows.Forms;



namespace Capa01_Presentación
{

    public partial class FrmRegistroCita : Form
    {
        EntidadCita citaRegistrada;

        FrmBuscarPaciente formularioBuscar;
        public FrmRegistroCita()
        {
            InitializeComponent();
        }

        private void FrmRegistroCita_Load(object sender, EventArgs e)
        {   /*
            BLCita blCita = new BLCita(Configuracion.getConnectionString);

            try
            {
                List<string> especialidades = blCita.ObtenerEspecialidades();

                foreach (string especialidad in especialidades)
                {
                    cbEspecialidades.Items.Add(especialidad);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar las especialidades: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            */

            BLCita blCita = new BLCita(Configuracion.getConnectionString);

            try
            {
                List<string> especialidades = blCita.ObtenerMedicosPorEspecialidad();

                foreach (string especialidad in especialidades)
                {
                    cbEspecialidades.Items.Add(especialidad);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar las especialidades: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            //Estado del pago de la cita
            cbEstado.Items.Add("Pendiente");
            cbEstado.Items.Add("Cancelado");


            //fin del proceso para mostrar los datos del médico en el comboBox

            try   //cargamos la lista de las citas al cargar el formulario y se muestra en el datagridview
            {
                CargarListaCitas();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        //COMIENZA PROCEDIMIENTO PARA VISUALIZAR LOS DATOS DEL PACIENTE EN LA PARTE SUPERIOR DE EL FORM CITA
        /// MÉTODOS: ACEPTAR, BUSCAR(LLAMAR AL FORM) Y CARGAR PACIENTES
        /// 
        private void btnBuscar_Click(object sender, EventArgs e)
        {
            formularioBuscar = new FrmBuscarPaciente();
            //se especifica que se quiere usar el evento Aceptar
            formularioBuscar.Aceptar += new EventHandler(Aceptar);
            formularioBuscar.ShowDialog();
        }

        private void Aceptar(Object id, EventArgs e) //ACEPTAR
        {
            try
            {
                int idPaciente = (int)id;
                if (idPaciente != -1)
                {
                    //MessageBox.Show(idCliente.ToString());
                    //CargarListaPacientes(idPaciente.ToString());
                    CargarPacientes(idPaciente);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//fin aceptar

        public void LimpiarCampos()
        {
            txtIdPaciente.Text = string.Empty;
            txtNombre.Text = string.Empty;
            txtApellido.Text = string.Empty;
            txtFechaN.Text = string.Empty;
            txtDireccion.Text = string.Empty;
            txtTelefono.Text = string.Empty;
            txtNombre.Focus();
        }



        private void CargarPacientes(int id)
        {
            EntidadPaciente paciente = new EntidadPaciente();
            BLPaciente traerPaciente = new BLPaciente(Configuracion.getConnectionString);
            try
            {
                paciente = traerPaciente.ObtenerPaciente(id);

                if (paciente != null)
                {
                    txtIdPaciente.Text = paciente.Id_Paciente.ToString();
                    txtNombre.Text = paciente.Nombre;
                    txtApellido.Text = paciente.Apellido;
                    txtFechaN.Text = paciente.FechaNacimiento.ToString();
                    //DateTime.TryParse(txtFechaN.Text, out DateTime fechaNacimiento);
                    //paciente.FechaNacimiento= fechaNacimiento;
                    //txtFechaN.Text = paciente.FechaNacimiento.ToString();
                    txtDireccion.Text = paciente.Direccion;
                    txtTelefono.Text = paciente.Telefono;
                    //txtID_Paciente.Text = paciente.Id_Paciente.ToString(); //carga automáticamente el id del paciente seleccionado
                }
                else
                {
                    MessageBox.Show("El paciente no se encuentra en la base de datos",
                        "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    //CargarListaPacientes();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin cargar cliente
        //TERMINA PROCESO DE VISUALIZAR PACIENTES EN LA PARTE SUPERIOR DEL FORM CITA

        private void btnGuardar_Click(object sender, EventArgs e)
        {    /* 
            EntidadCita cita = new EntidadCita();
            BLCita logicaPaciente = new BLCita(Configuracion.getConnectionString);
            int resultado;
            try
            {
                if (string.IsNullOrEmpty(txtFechaCita.Text) | string.IsNullOrEmpty(txtHoraCita.Text) | string.IsNullOrEmpty(cbEspecialidades.Text) | string.IsNullOrEmpty(txtDescripcion.Text))
                {
                    MessageBox.Show("Faltan datos", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    cita = generaCita();
                    resultado = logicaPaciente.LlamarMetodoInsertar(cita);
                    LimpiarCampos();
                    MessageBox.Show("operacion fue exitosa", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            */

            /*
            BLCita logicaCita = new BLCita(Configuracion.getConnectionString);
            int resultado;

            try
            {
                if (string.IsNullOrEmpty(txtFechaCita.Text) || string.IsNullOrEmpty(txtHoraCita.Text) || string.IsNullOrEmpty(cbEspecialidades.Text) || string.IsNullOrEmpty(txtDescripcion.Text))
                {
                    MessageBox.Show("Los datos son obligatorios", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {

                    EntidadCita cita = generaCita();
                    resultado = logicaCita.LlamarMetodoInsertar(cita);
                    if (resultado > 0)
                    {
                        LimpiarCampos2();
                        MessageBox.Show("Operación exitosa", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        CargarListaCitas();
                    }
                    else
                    {
                        MessageBox.Show("No se pudo guardar la cita", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            */

            BLCita logicaCita = new BLCita(Configuracion.getConnectionString);
            int resultado;

            try
            {
                if (string.IsNullOrEmpty(txtFechaCita.Text) || string.IsNullOrEmpty(txtHoraCita.Text) || string.IsNullOrEmpty(cbEspecialidades.Text) || string.IsNullOrEmpty(txtDescripcion.Text))
                {
                    MessageBox.Show("Los datos son obligatorios", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    DateTime fechaCita;
                    if (DateTime.TryParse(txtFechaCita.Text, out fechaCita)) // Verifica si se proporcionó una fecha válida
                    {
                        EntidadCita cita = generaCita();
                        resultado = logicaCita.LlamarMetodoInsertar(cita);
                        if (resultado > 0)
                        {
                            LimpiarCampos2();
                            MessageBox.Show("Operación exitosa", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            CargarListaCitas();
                        }
                        else
                        {
                            MessageBox.Show("No se pudo guardar la cita", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    else
                    {
                        MessageBox.Show("La fecha de cita no es válida", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }



        //
        public EntidadCita generaCita()
        {
            EntidadCita cita;
            if (!string.IsNullOrEmpty(txtID_Cita.Text)) //si no es null o no está vacío se utiliza el objeto cita existente.
            {
                cita = citaRegistrada;
            }
            else
            {
                cita = new EntidadCita(); // si txtIdCliente está vacío, se crea un nuevo objeto Clientes y se asigna a la variable Uncliente
            }
            EntidadCita citaP = new EntidadCita();






            citaP.Fecha = DateTime.TryParse(txtFechaCita.Text, out var fechaAceptable) ? fechaAceptable : DateTime.MinValue;
            //citaP.Fecha = Convert.ToDateTime(txtFechaCita);
            //citaP.Hora = Convert.ToDateTime(txtHoraCita).TimeOfDay;
            citaP.Hora = TimeSpan.TryParse(txtHoraCita.Text, out var horaAceptable) ? horaAceptable : TimeSpan.Zero;
            citaP.Descripcion = txtDescripcion.Text;
            //DateTime.TryParse(dataReader.GetString(3), out DateTime fechaNacimiento);
            //paciente.FechaNacimiento = fechaNacimiento;
            citaP.Detalle_Medico = cbEspecialidades.Text;
            citaP.Estado_Pago = (cbEstado.Text == "Pendiente") ? false : true;




            return cita;
        }


        //cargar la lista de citas en el dataGridview
        public void CargarListaCitas(string condicion = "") //agregado  
        {
            BLCita logicaBuscar = new BLCita(Configuracion.getConnectionString);
            List<EntidadCita> listarCitas;  //Se establece una Lista de la entidadpaciente que se cargará conteniendo todos los datos
            try                                      //guardos en la tabla, siempre y cuando haya algun registro de paciente guardado en la bd
            {
                listarCitas = logicaBuscar.llamarListaCitas(condicion);
                if (listarCitas.Count > 0)
                {
                    grdCitas.DataSource = listarCitas;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void LimpiarCampos2()
        {


            txtID_Cita.Text = string.Empty;
            txtIdPaciente.Text = string.Empty;
            txtFechaCita.Text = string.Empty;
            txtHoraCita.Text = string.Empty;
            cbEspecialidades.Text = string.Empty;
            cbEstado.Text = string.Empty;
            txtDescripcion.Text = string.Empty;


        }
        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            LimpiarCampos2();
        }

        private void txtFechaCita_TextChanged(object sender, EventArgs e)
        {
            // Obtener el valor de la fecha ingresada en el MaskedTextBox
            string fechaTexto = txtFechaCita.Text;

            // Validar si la fecha está completa
            if (txtFechaCita.MaskCompleted)
            {
                // Intentar convertir la fecha en formato dd/MM/yyyy
                if (DateTime.TryParseExact(fechaTexto, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime fecha))
                {
                    // La fecha es válida, realizar acciones adicionales si es necesario
                    
                    Console.WriteLine("Fecha válida: " + fecha.ToString("dd/MM/yyyy"));
                }
                else
                {
                    
                    Console.WriteLine("Fecha inválida");
                }
            }
            else
            {
                
                Console.WriteLine("Fecha incompleta");
            }
        }
    }
}
