﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Capa01_Presentación
{
    public partial class FrmBuscarHorario : Form
    {
        public FrmBuscarHorario()
        {
            InitializeComponent();
        }
    }
}
