﻿namespace Capa01_Presentación
{
    partial class FrmBuscarHISTORIALM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmBuscarHISTORIALM));
            grdHistorialM = new System.Windows.Forms.DataGridView();
            ID_HISTORIAL_MEDICO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ID_DIAGNOSTICO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ID_PACIENTE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            CLAVE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            DESCRIPCION = new System.Windows.Forms.DataGridViewTextBoxColumn();
            txtIdHistorial = new System.Windows.Forms.TextBox();
            btnBuscar = new System.Windows.Forms.Button();
            btnAceptar = new System.Windows.Forms.Button();
            btnCancelar = new System.Windows.Forms.Button();
            label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)grdHistorialM).BeginInit();
            SuspendLayout();
            // 
            // grdHistorialM
            // 
            grdHistorialM.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            grdHistorialM.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            grdHistorialM.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] { ID_HISTORIAL_MEDICO, ID_DIAGNOSTICO, ID_PACIENTE, CLAVE, DESCRIPCION });
            grdHistorialM.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            grdHistorialM.Location = new System.Drawing.Point(26, 167);
            grdHistorialM.Name = "grdHistorialM";
            grdHistorialM.ReadOnly = true;
            grdHistorialM.RowHeadersWidth = 62;
            grdHistorialM.RowTemplate.Height = 33;
            grdHistorialM.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            grdHistorialM.Size = new System.Drawing.Size(749, 116);
            grdHistorialM.TabIndex = 82;
            grdHistorialM.DoubleClick += grdHistorialM_DoubleClick;
            // 
            // ID_HISTORIAL_MEDICO
            // 
            ID_HISTORIAL_MEDICO.DataPropertyName = "ID_HISTORIAL_MEDICO";
            ID_HISTORIAL_MEDICO.HeaderText = "ID_HISTORIAL_MEDICO";
            ID_HISTORIAL_MEDICO.MinimumWidth = 8;
            ID_HISTORIAL_MEDICO.Name = "ID_HISTORIAL_MEDICO";
            ID_HISTORIAL_MEDICO.ReadOnly = true;
            ID_HISTORIAL_MEDICO.Width = 150;
            // 
            // ID_DIAGNOSTICO
            // 
            ID_DIAGNOSTICO.DataPropertyName = "ID_DIAGNOSTICO";
            ID_DIAGNOSTICO.HeaderText = "ID_DIAGNOSTICO";
            ID_DIAGNOSTICO.MinimumWidth = 8;
            ID_DIAGNOSTICO.Name = "ID_DIAGNOSTICO";
            ID_DIAGNOSTICO.ReadOnly = true;
            ID_DIAGNOSTICO.Visible = false;
            ID_DIAGNOSTICO.Width = 150;
            // 
            // ID_PACIENTE
            // 
            ID_PACIENTE.DataPropertyName = "ID_PACIENTE";
            ID_PACIENTE.HeaderText = "ID_PACIENTE";
            ID_PACIENTE.MinimumWidth = 8;
            ID_PACIENTE.Name = "ID_PACIENTE";
            ID_PACIENTE.ReadOnly = true;
            ID_PACIENTE.Width = 150;
            // 
            // CLAVE
            // 
            CLAVE.DataPropertyName = "FECHA_CREACION";
            CLAVE.HeaderText = "FECHA_CREACION";
            CLAVE.MinimumWidth = 8;
            CLAVE.Name = "CLAVE";
            CLAVE.ReadOnly = true;
            CLAVE.Width = 150;
            // 
            // DESCRIPCION
            // 
            DESCRIPCION.DataPropertyName = "DESCRIPCION";
            DESCRIPCION.HeaderText = "DESCRIPCIÓN";
            DESCRIPCION.MinimumWidth = 8;
            DESCRIPCION.Name = "DESCRIPCION";
            DESCRIPCION.ReadOnly = true;
            DESCRIPCION.Width = 150;
            // 
            // txtIdHistorial
            // 
            txtIdHistorial.Location = new System.Drawing.Point(331, 75);
            txtIdHistorial.Name = "txtIdHistorial";
            txtIdHistorial.Size = new System.Drawing.Size(307, 31);
            txtIdHistorial.TabIndex = 86;
            // 
            // btnBuscar
            // 
            btnBuscar.Image = (System.Drawing.Image)resources.GetObject("btnBuscar.Image");
            btnBuscar.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            btnBuscar.Location = new System.Drawing.Point(677, 64);
            btnBuscar.Name = "btnBuscar";
            btnBuscar.Size = new System.Drawing.Size(98, 52);
            btnBuscar.TabIndex = 85;
            btnBuscar.Text = "&Buscar";
            btnBuscar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnBuscar.UseVisualStyleBackColor = true;
            btnBuscar.Click += btnBuscar_Click;
            // 
            // btnAceptar
            // 
            btnAceptar.Image = (System.Drawing.Image)resources.GetObject("btnAceptar.Image");
            btnAceptar.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            btnAceptar.Location = new System.Drawing.Point(482, 356);
            btnAceptar.Name = "btnAceptar";
            btnAceptar.Size = new System.Drawing.Size(110, 61);
            btnAceptar.TabIndex = 84;
            btnAceptar.Text = "&Aceptar";
            btnAceptar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnAceptar.UseVisualStyleBackColor = true;
            btnAceptar.Click += btnAceptar_Click;
            // 
            // btnCancelar
            // 
            btnCancelar.Image = (System.Drawing.Image)resources.GetObject("btnCancelar.Image");
            btnCancelar.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            btnCancelar.Location = new System.Drawing.Point(657, 356);
            btnCancelar.Name = "btnCancelar";
            btnCancelar.Size = new System.Drawing.Size(118, 61);
            btnCancelar.TabIndex = 83;
            btnCancelar.Text = "&Cancelar";
            btnCancelar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnCancelar.UseVisualStyleBackColor = true;
            btnCancelar.Click += btnCancelar_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(211, 75);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(102, 25);
            label1.TabIndex = 87;
            label1.Text = "ID_Historial";
            // 
            // FrmBuscarHISTORIALM
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(800, 450);
            Controls.Add(label1);
            Controls.Add(txtIdHistorial);
            Controls.Add(btnBuscar);
            Controls.Add(btnAceptar);
            Controls.Add(btnCancelar);
            Controls.Add(grdHistorialM);
            Name = "FrmBuscarHISTORIALM";
            Text = "HISTORIAL";
            Load += FrmBuscarHISTORIALM_Load;
            ((System.ComponentModel.ISupportInitialize)grdHistorialM).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.DataGridView grdHistorialM;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_HISTORIAL_MEDICO;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_DIAGNOSTICO;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_PACIENTE;
        private System.Windows.Forms.DataGridViewTextBoxColumn CLAVE;
        private System.Windows.Forms.DataGridViewTextBoxColumn DESCRIPCION;
        private System.Windows.Forms.TextBox txtIdHistorial;
        private System.Windows.Forms.Button btnBuscar;
        private System.Windows.Forms.Button btnAceptar;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Label label1;
    }
}