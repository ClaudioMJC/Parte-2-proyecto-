﻿using System;
using System.Collections.Generic;
using System.Text;
using CapaEntidades;
using Capa03_AccesoDatos;

namespace Capa02_LogicaNegocio
{
    public class BLCita
    {

        private string _cadenaConexion;
        private string _mensaje;

        //propiedes

        public string Mensaje
        {
            get => _mensaje;
        }
        //constructor de la clase
        public BLCita(string cadenaConexion)
        {
            _cadenaConexion = cadenaConexion;
            _mensaje = string.Empty;
        }




        /*
        public List<string> ObtenerEspecialidades()
        {
            DACita ObtenerE = new DACita(_cadenaConexion);

            return ObtenerE.ObtenerEspecialidades();
        }

        */

        public List<string> ObtenerMedicosPorEspecialidad()
        {
            DACita ObtenerE = new DACita(_cadenaConexion);

            return ObtenerE.ObtenerEspecialidades();
        } //fin ObtenerMedicosPorEspecialidad //método enfocado en mostrar la info en el comboBox




        //metodo que se encarga de  llamar al metodo insertar de la capa de AccesoDatos
        public int LlamarMetodoInsertar(EntidadCita cita)
        {
            int id_cita = 0;
            DACita accesoDatos = new DACita(_cadenaConexion);
            try
            {
                id_cita = accesoDatos.Insertar(cita);
            }
            catch (Exception)
            {
                throw;
            }
            return id_cita;
        }// fin de la clase insertar (Hasta aquí es el procedimiento para insertar en la base de datos y guardar)

        //mostrar lista de Pacientes 2
        public List<EntidadCita> llamarListaCitas(string condicion = "")
        {
            List<EntidadCita> listaCitas;
            DACita accesoDatos = new DACita(_cadenaConexion);
            try
            {
                listaCitas = accesoDatos.ListarCitas(condicion);
            }
            catch (Exception)
            {
                throw;
            }

            return listaCitas;
        }


        public EntidadCita ObtenerCita(int id)
        {
            EntidadCita cita;
            DACita accesoDatos = new DACita(_cadenaConexion);
            try
            {
                cita = accesoDatos.ObtenerCita(id);
            }
            catch (Exception)
            {
                throw;
            }
            return cita;
        }//Obtenerfin 


        // (LLAMAR AL MÉTODO ELIMINAR REGISTRO)
        public int EliminarPaciente(EntidadCita cita)
        {
            int resultado;
            DACita accesoDatos = new DACita(_cadenaConexion);
            try
            {
                resultado = accesoDatos.EliminarCita(cita);

            }
            catch (Exception)
            {
                throw;
            }
            return resultado;

        }//Eliminar fin


        //(LLAMAR MÉTODO ACTUALIZAR REGISTRO)

        public int Modificar(EntidadCita cita)
        {
            int filasAfectadas = 0;
            DACita accesoDatos = new DACita(_cadenaConexion);

            try
            {
                filasAfectadas = accesoDatos.Modificar(cita);
            }
            catch (Exception)
            {
                throw;
            }
            return filasAfectadas;

        }


    }//fin clase BLPACIENTE





}//fin BLCita // 

