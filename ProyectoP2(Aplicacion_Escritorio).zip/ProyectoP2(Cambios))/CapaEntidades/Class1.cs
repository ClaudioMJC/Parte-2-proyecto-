﻿using System;

namespace CapaEntidades
{
    public class Class1
    {

    }
}
