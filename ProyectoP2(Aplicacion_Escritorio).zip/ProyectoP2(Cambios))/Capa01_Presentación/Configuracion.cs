﻿namespace Capa01_Presentación
{
    public class Configuracion
    {
        public static string getConnectionString
        {
            get
            {
                return Properties.Settings.Default.ConnectionString;
            }
        }

    }
}
