﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CapaEntidades
{
    public class EntidadPaciente
    {
        private int id_Paciente;
        private string nombre;
        private string apellido;
        private DateTime fechaNacimiento;
        private string direccion;
        private string telefono;
        private bool existe;

        public int Id_Paciente { get => id_Paciente; set => id_Paciente = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public string Apellido { get => apellido; set => apellido = value; }
        public DateTime FechaNacimiento { get => fechaNacimiento; set => fechaNacimiento = value; }
        public string Direccion { get => direccion; set => direccion = value; }
        public string Telefono { get => telefono; set => telefono = value; }
        public bool Existe { get => existe; set => existe = value; }

        public EntidadPaciente(int id_Paciente, string nombre, string apellido, DateTime fechaNacimiento, string direccion, string telefono, bool existe)
        {
            this.id_Paciente = id_Paciente;
            this.nombre = nombre;
            this.apellido = apellido;
            this.fechaNacimiento = fechaNacimiento;
            this.direccion = direccion;
            this.telefono = telefono;
            this.existe = false;
        }

        public EntidadPaciente()
        {
            id_Paciente = 0;
            nombre = string.Empty;
            apellido = string.Empty;
            fechaNacimiento = DateTime.MinValue;
            direccion = string.Empty;
            telefono = string.Empty;
            existe = false;
        }
        /*
        public EntidadPaciente(int id_paciente, string nombre, string apellido)
        {
            this.id_Paciente = id_paciente;
            this.nombre = nombre;
            this.apellido = apellido;

        }
        */
    }
}
