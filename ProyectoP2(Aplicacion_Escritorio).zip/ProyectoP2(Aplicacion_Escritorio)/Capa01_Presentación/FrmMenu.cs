﻿using System;
using System.Windows.Forms;

namespace Capa01_Presentación
{
    public partial class FrmMenu : Form
    {
        public FrmMenu()
        {
            InitializeComponent();
        }

        private void registrarPacienteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmRegistrarPaciente form2 = new FrmRegistrarPaciente();
            form2.ShowDialog();
        }

        private void agendarCitaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            FrmRegistroCita formCita = new FrmRegistroCita();
            formCita.ShowDialog();
        }

        private void gestiónDeUsuariosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmUsuarios formUsuario = new FrmUsuarios();
            formUsuario.ShowDialog();
        }

        private void horarioDeTrabajadoresToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmHorarios formHorario = new FrmHorarios();
            formHorario.ShowDialog();
        }

        private void historialMedicoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmHistorialM formHistorial= new FrmHistorialM();
            formHistorial.ShowDialog();
        }
    }
}
