﻿using System;
using System.Collections.Generic;
using System.Text;
using CapaEntidades;
using System.Data.SqlClient;
using System.Linq;
using System.Data;

namespace Capa03_AccesoDatos
{
    public class DaPaciente
    {
        //atributos N°1//
        private string _cadenaConexion;
        private string _mensaje;

        //propiedes

        public string Mensaje
        {
            get => _mensaje;
        }

        public DaPaciente(string cadenaConexion)
        {
            _cadenaConexion = cadenaConexion;
            _mensaje = string.Empty;
        }

        public int Insertar(EntidadPaciente paciente)
        {
            int id = 0;
            //Establecer el objeto de conexión
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            //Establecer el objeto para ejecutar los comandos SQL
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            string sentencia = "INSERT INTO PACIENTE (NOMBRE,APELLIDO,FECHA_NACIMIENTO, DIRECCION, TELEFONO)" +
                " VALUES( @NOMBRE,@APELLIDO,@FECHA_NACIMIENTO, @DIRECCION, @TELEFONO) SELECT @@IDENTITY";
            comando.Parameters.AddWithValue("@NOMBRE", paciente.Nombre);
            comando.Parameters.AddWithValue("@APELLIDO", paciente.Apellido);
            comando.Parameters.AddWithValue("@FECHA_NACIMIENTO", paciente.FechaNacimiento);
            comando.Parameters.AddWithValue("DIRECCION", paciente.Direccion);
            comando.Parameters.AddWithValue("@TELEFONO", paciente.Telefono);
            comando.CommandText = sentencia;
            try
            {
                conexion.Open();
                id = Convert.ToInt32(comando.ExecuteScalar());
                conexion.Close();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conexion.Dispose();
                comando.Dispose();
            }
            return id;
        }  //Fin de insertar (Hasta aquí es el procedimiento para insertar en la base de datos y guardar)

        //comienza procedimiento para mostrar la lista de pacientes
        public List<EntidadPaciente> ListarPacientes(string condicion = "")
        {
            DataSet elDataSet = new DataSet();
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlDataAdapter adapter;
            List<EntidadPaciente> listaPacientes;

            string instruccionDB = "SELECT ID_PACIENTE, NOMBRE, APELLIDO, FECHA_NACIMIENTO, DIRECCION, TELEFONO FROM PACIENTE";

            if (!string.IsNullOrEmpty(condicion))
            {
                instruccionDB = string.Format("{0} WHERE {1}", instruccionDB, condicion);
            }
            try
            {
                adapter = new SqlDataAdapter(instruccionDB, conexion);
                adapter.Fill(elDataSet, "PACIENTE");
                listaPacientes = (from DataRow unaFila in elDataSet.Tables["PACIENTE"].Rows
                                 select new EntidadPaciente()
                                 {
                                     
                                     Id_Paciente = (int)unaFila[0],
                                     Nombre = unaFila[1].ToString(),
                                     Apellido = unaFila[2].ToString(),
                                     FechaNacimiento = DateTime.TryParse(unaFila[3].ToString(), out var fechaAceptable) ? fechaAceptable : DateTime.MinValue,
                                     //Si el TryParse es exitoso se le asignará el valor de fechaAceptable a FechaNacimiento de lo contrario
                                     //se le asigna un valor por defecto de DateTime.MinValue
                                     Direccion = unaFila[4].ToString(),
                                     Telefono = unaFila[5].ToString(),
                                 }).ToList();
            }
            catch (Exception)
            {
                throw;
            }
            return listaPacientes;

        }//fin listar pacientes


        public EntidadPaciente ObtenerPaciente(int id)
        {
            EntidadPaciente paciente = null;
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            SqlDataReader dataReader;
            string sentencia = string.Format("SELECT ID_PACIENTE, NOMBRE, APELLIDO, FECHA_NACIMIENTO, DIRECCION, TELEFONO FROM " +
                "PACIENTE WHERE ID_PACIENTE = {0}", id);
            comando.Connection = conexion;
            comando.CommandText = sentencia;
            try
            {
                conexion.Open();
                dataReader = comando.ExecuteReader();
                if (dataReader.HasRows)
                {
                    paciente = new EntidadPaciente();
                    dataReader.Read();
                    paciente.Id_Paciente = dataReader.GetInt32(0);
                    paciente.Nombre = dataReader.GetString(1);
                    paciente.Apellido = dataReader.GetString(2);
                    paciente.FechaNacimiento = dataReader.GetDateTime(3);
                    //DateTime.TryParse(dataReader.GetString(3), out DateTime fechaNacimiento);
                    //paciente.FechaNacimiento = fechaNacimiento;
                    paciente.Direccion = dataReader.GetString(4);
                    paciente.Telefono = dataReader.GetString(5);
                    paciente.Existe = true;

                }
                conexion.Close();
            }
            catch (Exception)
            {
                throw;
            }
            return paciente;
        }  //fin obtener cliente 

        // (Se elimina el paciente)
        ///
        public int EliminarPaciente(EntidadPaciente paciente)
        {
            int afectado = -1;
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            string sentencia = "DELETE FROM PACIENTE";
            sentencia = string.Format("{0} WHERE ID_PACIENTE = {1}", sentencia, paciente.Id_Paciente);
            comando.CommandText = sentencia;
            comando.Connection = conexion;
            try
            {
                conexion.Open();
                afectado = comando.ExecuteNonQuery();
                conexion.Close();

            }
            catch (Exception)
            {
                throw;

            }
            finally
            {
                conexion.Dispose();
                conexion.Dispose();
            }
            return afectado;
        }//fIN DE ELIMINAR


        // (Actualizar Cliente)
        ///
        public int Modificar(EntidadPaciente paciente)
        {
            int filasAfectadas = -1;
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            string sentencia = "UPDATE PACIENTE SET NOMBRE=@NOMBRE, APELLIDO=@APELLIDO, FECHA_NACIMIENTO=@FECHA_NACIMIENTO, DIRECCION=@DIRECCION, TELEFONO=@TELEFONO WHERE ID_PACIENTE=@ID_PACIENTE";
            comando.CommandText = sentencia;
            comando.Connection = conexion;
            comando.Parameters.AddWithValue("@ID_PACIENTE", paciente.Id_Paciente);
            comando.Parameters.AddWithValue("@NOMBRE", paciente.Nombre);
            comando.Parameters.AddWithValue("@APELLIDO", paciente.Apellido);
            comando.Parameters.AddWithValue("@FECHA_NACIMIENTO", paciente.FechaNacimiento);
            comando.Parameters.AddWithValue("@DIRECCION", paciente.Direccion);
            comando.Parameters.AddWithValue("@TELEFONO", paciente.Telefono);
            try
            {
                conexion.Open();
                filasAfectadas = comando.ExecuteNonQuery();
                conexion.Close();

            }
            catch (Exception)
            {
                throw;

            }
            finally
            {
                conexion.Dispose();
                comando.Dispose();
            }
            return filasAfectadas;


        }//FIN DE ACTUALIZAR


    }//fin clase DaPaciente
}
