﻿using Capa02_LogicaNegocio;
using CapaEntidades;
using System;
using System.Collections.Generic;
using System.Windows.Forms;


namespace Capa01_Presentación
{
    public partial class FrmRegistrarPaciente : Form
    {

        FrmBuscarPaciente formularioBuscar;
        EntidadPaciente pacienteRegistrado;
        public FrmRegistrarPaciente()
        {
            InitializeComponent();
        }

        //crea un objeto con los datos ingresados en las casillas de texto
        public EntidadPaciente generaPaciente()
        {
            EntidadPaciente paciente;
            if (!string.IsNullOrEmpty(txtIdPaciente.Text)) //si no es null o no está vacío se utiliza el objeto paciente existente.
            {
                paciente = pacienteRegistrado;
            }
            else
            {
                paciente = new EntidadPaciente(); // si txtIdCliente está vacío, se crea un nuevo objeto Clientes y se asigna a la variable Uncliente
            }
            EntidadPaciente unPaciente = new EntidadPaciente();
            unPaciente.Nombre = txtNombre.Text;
            unPaciente.Apellido = txtApellido.Text;
            //unPaciente.FechaNacimiento=DateTime.Parse(txtApellido.Text);
            unPaciente.FechaNacimiento = DateTime.TryParse(txtFechaN.Text, out var fechaValida) ? fechaValida : default(DateTime);
            //intenta revisar la cadena y devuelve un valor booleano que indica si el análisis fue exitoso.
            //con el operador de null conditional (?) se verifica si fue exitoso, si lo es se asigna el valor de "fecha valida a FechaNacimiento
            //si no es válido asignamos un valor por default a FechaNacimiento que es el de Datetime
            unPaciente.Direccion = txtDireccion.Text;
            unPaciente.Telefono = txtTelefono.Text;


            return unPaciente;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            

            EntidadPaciente paciente = generaPaciente();
            BLPaciente logicaCliente = new BLPaciente(Configuracion.getConnectionString);
            int resultado;

            try
            {
                if (string.IsNullOrEmpty(txtNombre.Text) || string.IsNullOrEmpty(txtApellido.Text) || string.IsNullOrEmpty(txtFechaN.Text) || string.IsNullOrEmpty(txtDireccion.Text) || string.IsNullOrEmpty(txtTelefono.Text))
                {
                    MessageBox.Show("Los datos son obligatorios", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    
                }
                else
                {
                    paciente = generaPaciente();
                    if (paciente.Existe)
                    {
                        resultado = logicaCliente.Modificar(paciente);
                        if (resultado > 0)
                        {
                            LimpiarCampos();
                            MessageBox.Show("Operación exitosa", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            CargarListaPacientes();
                        }
                        else
                        {
                            MessageBox.Show("No se realizaron cambios", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    else
                    {
                        resultado = logicaCliente.LlamarMetodoInsertar(paciente);
                        if (resultado > 0)
                        {
                            LimpiarCampos();
                            MessageBox.Show("Operación exitosa", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            CargarListaPacientes();
                        }
                        else
                        {
                            MessageBox.Show("No se pudo guardar el cliente", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }//fin Guardar

        public void LimpiarCampos()
        {
            txtIdPaciente.Text = string.Empty;
            txtNombre.Text = string.Empty;
            txtApellido.Text = string.Empty;
            txtFechaN.Text = string.Empty;
            txtDireccion.Text = string.Empty;
            txtTelefono.Text = string.Empty;
            txtNombre.Focus();
        }
        //(Hasta aquí es el procedimiento para insertar en la base de datos y guardar)


        public void CargarListaPacientes(string condicion = "") //agregado  
        {
            BLPaciente logicaBuscar = new BLPaciente(Configuracion.getConnectionString);
            List<EntidadPaciente> listarPacientes;  //Se establece una Lista de la entidadpaciente que se cargará conteniendo todos los datos
            try                                      //guardos en la tabla, siempre y cuando haya algun registro de paciente guardado en la bd
            {
                listarPacientes = logicaBuscar.llamarListaPacientes(condicion);
                if (listarPacientes.Count > 0)
                {
                    grdListaPacientes.DataSource = listarPacientes;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FrmRegistrarPaciente_Load(object sender, EventArgs e)
        {
            try   //cargamos la lista de pacientes al cargar el formulario y se muestra en el datagridview
            {
                CargarListaPacientes();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            //FrmBuscarPaciente frm = new FrmBuscarPaciente();
            //frm.ShowDialog();

            formularioBuscar = new FrmBuscarPaciente();
            //se especifica que se quiere usar el evento Aceptar
            formularioBuscar.Aceptar += new EventHandler(Aceptar);
            formularioBuscar.ShowDialog();

        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Aceptar(Object id, EventArgs e) //ACEPTAR
        {
            try
            {
                int idPaciente = (int)id;
                if (idPaciente != -1)
                {
                    //MessageBox.Show(idCliente.ToString());
                    //CargarListaPacientes(idPaciente.ToString());
                    CargarPacientes(idPaciente);
                }
                else
                {
                    LimpiarCampos();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//fin aceptar


        private void CargarPacientes(int id)
        {
            EntidadPaciente paciente = new EntidadPaciente();
            BLPaciente traerPaciente = new BLPaciente(Configuracion.getConnectionString);
            try
            {
                paciente = traerPaciente.ObtenerPaciente(id);

                if (paciente != null)
                {
                    txtIdPaciente.Text = paciente.Id_Paciente.ToString();
                    txtNombre.Text = paciente.Nombre;
                    txtApellido.Text = paciente.Apellido;
                    txtFechaN.Text = paciente.FechaNacimiento.ToString();
                    //DateTime.TryParse(txtFechaN.Text, out DateTime fechaNacimiento);
                    //paciente.FechaNacimiento= fechaNacimiento;
                    //txtFechaN.Text = paciente.FechaNacimiento.ToString();
                    txtDireccion.Text = paciente.Direccion;
                    txtTelefono.Text = paciente.Telefono;

                }
                else
                {
                    MessageBox.Show("El paciente no se encuentra en la base de datos",
                        "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    CargarListaPacientes();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin cargar cliente

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            EntidadPaciente paciente;
            int resultado;
            BLPaciente logica = new BLPaciente(Configuracion.getConnectionString);
            try
            {
                if (!string.IsNullOrEmpty(txtIdPaciente.Text))
                {
                    paciente = logica.ObtenerPaciente(int.Parse(txtIdPaciente.Text));
                    if (paciente != null)
                    {   /*
                        resultado = logica.EliminarConSP(cliente);
                        MessageBox.Show(logica.Mensaje, "Aviso", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                        */
                        resultado = logica.EliminarPaciente(paciente);
                        MessageBox.Show("Se ha eliminado el resgistro", "Aviso", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                        LimpiarCampos();
                        CargarListaPacientes();


                    }
                    else
                    {
                        MessageBox.Show("El cliente no existe", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        LimpiarCampos();
                        CargarListaPacientes();
                    }
                }
                else
                {
                    MessageBox.Show("Debe Seleccionar un cliente antes de eliminar", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        } //btn Eliminar

    }//fin FrmRegistrarPaciente
}
