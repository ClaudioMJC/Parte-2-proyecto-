﻿using Capa02_LogicaNegocio;
using Capa03_AccesoDatos;
using CapaEntidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using static Capa03_AccesoDatos.DAHorario;
using static CapaEntidades.EntidadHorario;
using static CapaEntidades.EntidadUsuario;

namespace Capa01_Presentación
{
    public partial class FrmHorarios : Form
    {
        public FrmHorarios()
        {
            InitializeComponent();
        }

        FrmBuscarHorario formularioBuscar;
        EntidadHorario horarioRegistrado;



        // Crea un objeto con los datos ingresados en las casillas de texto
        public EntidadHorario GeneraHorario()
        {
            EntidadHorario horario;
            if (!string.IsNullOrEmpty(txtIdHorario.Text))
            {
                horario = horarioRegistrado;
            }
            else
            {
                horario = new EntidadHorario();
            }

            //EntidadHorario unHorario = new EntidadHorario();

            //txtIdHorario.Text = horario.Id_horario.ToString();
            horario.DiasTrabajados = txtDiasTrabajados.Text;

            TimeSpan horaInicio;
            if (TimeSpan.TryParse(txtHoraIN.Text, out horaInicio))
            {
                horario.HoraInicio = horaInicio;
            }
            else
            {
                horaInicio = TimeSpan.Zero;
            }
            TimeSpan horaFin;

            if (TimeSpan.TryParse(txtHoraFIN.Text, out horaFin))
            {
                horario.HoraFin = horaFin;
            }
            else
            {
                horaFin = TimeSpan.Zero;
            }


            int idHorario;
            if (int.TryParse(cboIdUsuarios.Text, out idHorario))
            {
                horario.Id_usuario = idHorario;
            }
            else
            {
                MessageBox.Show("El valor del campo ID Pago no es válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                // Otra acción apropiada
            }





            return horario;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            EntidadHorario horario = GeneraHorario();
            BLHorario logicaHorario = new BLHorario(Configuracion.getConnectionString);
            int resultado;

            try
            {
                if (string.IsNullOrEmpty(txtDiasTrabajados.Text) || string.IsNullOrEmpty(txtHoraIN.Text) || string.IsNullOrEmpty(txtHoraFIN.Text) || string.IsNullOrEmpty(cboIdUsuarios.Text))
                {
                    MessageBox.Show("Los datos son obligatorios", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    horario = GeneraHorario();
                    if (horario.Id_horario != 0)
                    {
                        resultado = logicaHorario.Modificar(horario);
                        if (resultado > 0)
                        {
                            LimpiarCampos();
                            MessageBox.Show("Operación exitosa", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            CargarListaHorarios();
                        }
                        else
                        {
                            MessageBox.Show("No se realizaron cambios", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    else
                    {
                        resultado = logicaHorario.LlamarMetodoInsertar(horario);
                        if (resultado > 0)
                        {
                            LimpiarCampos();
                            MessageBox.Show("Operación exitosa", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            CargarListaHorarios();
                        }
                        else
                        {
                            MessageBox.Show("No se pudo guardar el horario", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void LimpiarCampos()
        {
            txtIdHorario.Text = string.Empty;
            //txtIdUsuario.Text = string.Empty;
            txtDiasTrabajados.Text = string.Empty;
            txtHoraIN.Text = string.Empty;
            txtHoraFIN.Text = string.Empty;
            cboIdUsuarios.Items.Clear();
            txtDiasTrabajados.Focus();
        }

        public void CargarListaHorarios(string condicion = "")
        {
            BLHorario logicaBuscar = new BLHorario(Configuracion.getConnectionString);
            List<EntidadHorario> listarHorarios;
            try
            {
                listarHorarios = logicaBuscar.LlamarListaHorarios(condicion);
                if (listarHorarios.Count > 0)
                {
                    grdHorarios.DataSource = listarHorarios;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        /*
        private void btnBuscar_Click(object sender, EventArgs e)
        {
            formularioBuscar = new FrmBuscarHorario();
            formularioBuscar.Aceptar += new EventHandler(Aceptar);
            formularioBuscar.ShowDialog();
        }
          */
        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Aceptar(Object id, EventArgs e)
        {
            try
            {
                int idHorario = (int)id;
                if (idHorario != -1)
                {
                    CargarHorario(idHorario);
                }
                else
                {
                    LimpiarCampos();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CargarHorario(int id)
        {
            EntidadHorario horario = new EntidadHorario();
            BLHorario traerHorario = new BLHorario(Configuracion.getConnectionString);
            try
            {
                horario = traerHorario.ObtenerHorario(id);

                if (horario != null)
                {
                    txtIdHorario.Text = horario.Id_horario.ToString();
                    cboIdUsuarios.Text = horario.Id_usuario.ToString();
                    txtDiasTrabajados.Text = horario.DiasTrabajados;
                    txtHoraIN.Text = horario.HoraInicio.ToString();
                    txtHoraFIN.Text = horario.HoraFin.ToString();
                }
                else
                {
                    MessageBox.Show("El horario no se encuentra en la base de datos", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    CargarListaHorarios();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            formularioBuscar = new FrmBuscarHorario();
            formularioBuscar.Aceptar += new EventHandler(Aceptar);
            formularioBuscar.ShowDialog();
        }




        private void btnNuevo_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            EntidadHorario horario;
            int resultado;
            BLHorario logica = new BLHorario(Configuracion.getConnectionString);
            try
            {
                if (!string.IsNullOrEmpty(txtIdHorario.Text))
                {
                    horario = logica.ObtenerHorario(int.Parse(txtIdHorario.Text));
                    if (horario != null)
                    {
                        resultado = logica.EliminarHorario(horario);
                        MessageBox.Show("Se ha eliminado el registro", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LimpiarCampos();
                        CargarListaHorarios();
                    }
                    else
                    {
                        MessageBox.Show("El horario no existe", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        LimpiarCampos();
                        CargarListaHorarios();
                    }
                }
                else
                {
                    MessageBox.Show("Debe seleccionar un horario antes de eliminar", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FrmHorarios_Load(object sender, EventArgs e)
        {
            try
            {
                CargarListaHorarios();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            BLHorario idNombre = new BLHorario(Configuracion.getConnectionString);
            BLHorario idT = new BLHorario(Configuracion.getConnectionString);

            try
            {
                List<UsuarioIdNO> nombreMasid = idNombre.ObtenerIdUsuarioyNombre();

                foreach (UsuarioIdNO idN in nombreMasid)
                {
                    cboTrabajadores.Items.Add(idN);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar las especialidades: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


            try
            {
                List<int> idlist = idT.ObtenerIdUsuarios();

                foreach (int idTr in idlist)
                {
                    cboIdUsuarios.Items.Add(idTr);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar las especialidades: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }
    }
}
