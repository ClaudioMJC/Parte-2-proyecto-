﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CapaEntidades
{
    public class EntidadRecepcionista
    {
        private int id_recepcionista;
        private int id_rol;
        private string nombre;
        private string apellido;

        public int Id_recepcionista { get => id_recepcionista; set => id_recepcionista = value; }
        public int Id_rol { get => id_rol; set => id_rol = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public string Apellido { get => apellido; set => apellido = value; }

        public EntidadRecepcionista(int id_recepcionista, int id_rol, string nombre, string apellido)
        {
            this.id_recepcionista = id_recepcionista;
            this.id_rol = id_rol;
            this.nombre = nombre;
            this.apellido = apellido;
        }
        public EntidadRecepcionista()
        {
            id_recepcionista = 0;
            id_rol = 0;
            nombre = string.Empty;
            apellido = string.Empty;

        }
    }
}
