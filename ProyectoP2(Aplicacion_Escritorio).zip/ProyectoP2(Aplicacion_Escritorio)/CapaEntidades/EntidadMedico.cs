﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CapaEntidades
{
    public class EntidadMedico
    {
        private int id_medico;
        private string nombre;
        private string apellido;
        private int id_especialidad;
        private int id_rol;

        public int Id_medico { get => id_medico; set => id_medico = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public string Apellido { get => apellido; set => apellido = value; }
        public int Id_especialidad { get => id_especialidad; set => id_especialidad = value; }
        public int Id_rol { get => id_rol; set => id_rol = value; }

        public EntidadMedico(int id_medico, string nombre, string apellido, int id_especialidad, int id_rol)
        {
            this.id_medico = id_medico;
            this.nombre = nombre;
            this.apellido = apellido;
            this.id_especialidad = id_especialidad;
            this.id_rol = id_rol;
        }
        public EntidadMedico() 
        {
            id_medico = -1;
            nombre = string.Empty;
            apellido = string.Empty; 
            id_especialidad =-1;
            id_rol = -1; // indica el -1 que no se ha seleccionado ninguna especialidad o rol
                         // en el momento de la creación del objeto EntidadMedico
        }
    }
}
