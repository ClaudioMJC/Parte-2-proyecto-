﻿using Capa03_AccesoDatos;
using CapaEntidades;
using System;
using System.Collections.Generic;
using System.Text;

namespace Capa02_LogicaNegocio
{
    public class BLHistorial
    {
        private string _cadenaConexion;
        private string _mensaje;

        public string Mensaje
        {
            get => _mensaje;
        }

        public BLHistorial(string cadenaConexion)
        {
            _cadenaConexion = cadenaConexion;
            _mensaje = string.Empty;
        }
        
        /*
        public int LlamarMetodoInsertar(EntidadHistorial_Medico historial)
        {
            int id_historial = 0;
            DAHistorial accesoDatos = new DAHistorial(_cadenaConexion);
            try
            {
                id_historial = accesoDatos.Insertar(historial);
            }
            catch (Exception)
            {
                throw;
            }
            return id_historial;
        }

        public List<EntidadHistorial_Medico> LlamarMetodoListarHistoriales(string condicion = "")
        {
            List<EntidadHistorial_Medico> listaHistoriales;
            DAHistorial accesoDatos = new DAHistorial(_cadenaConexion);
            try
            {
                listaHistoriales = accesoDatos.ListarHistoriales(condicion);
            }
            catch (Exception)
            {
                throw;
            }

            return listaHistoriales;
        }

        public EntidadHistorial_Medico LlamarMetodoObtenerHistorial(int id)
        {
            EntidadHistorial_Medico historial;
            DAHistorial accesoDatos = new DAHistorial(_cadenaConexion);
            try
            {
                historial = accesoDatos.ObtenerHistorial(id);
            }
            catch (Exception)
            {
                throw;
            }
            return historial;
        }

        public int LlamarMetodoEliminarHistorial(EntidadHistorial_Medico historial)
        {
            int resultado;
            DAHistorial accesoDatos = new DAHistorial(_cadenaConexion);
            try
            {
                resultado = accesoDatos.EliminarHistorial(historial);
            }
            catch (Exception)
            {
                throw;
            }
            return resultado;
        }

        public int LlamarMetodoModificarHistorial(EntidadHistorial_Medico historial)
        {
            int filasAfectadas = 0;
            DAHistorial accesoDatos = new DAHistorial(_cadenaConexion);
            try
            {
                filasAfectadas = accesoDatos.Modificar(historial);
            }
            catch (Exception)
            {
                throw;
            }
            return filasAfectadas;
        }
        */

    }
    
}  
