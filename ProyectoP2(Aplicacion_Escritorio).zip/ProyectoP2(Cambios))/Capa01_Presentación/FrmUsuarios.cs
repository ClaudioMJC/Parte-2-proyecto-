﻿using Capa02_LogicaNegocio;
using CapaEntidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace Capa01_Presentación
{
    public partial class FrmUsuarios : Form
    {
        FrmBuscarUSUARIO formularioBuscar;
        EntidadUsuario usuarioRegistrado;
        public FrmUsuarios()
        {
            InitializeComponent();
        }



        //crea un objeto con los datos ingresados en las casillas de texto
        public EntidadUsuario generaUsuario()
        {
            EntidadUsuario usuario;
            if (!string.IsNullOrEmpty(txtIdUsuario.Text)) //si no es null o no está vacío se utiliza el objeto usuario existente.
            {
                usuario = usuarioRegistrado;
            }
            else
            {
                usuario = new EntidadUsuario(); // si txtIdCliente está vacío, se crea un nuevo objeto usuario y se asigna a la variable Uncliente
            }

            usuario.NombreUsuario = txtNombreU.Text;
            usuario.Clave = txtContrasena.Text;
            int idRol;
            if (int.TryParse(cboRoles.Text, out idRol))
            {
                usuario.Id_rol = idRol;
            }
            else
            {
                MessageBox.Show("El valor del campo ID Pago no es válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                // Otra acción apropiada
            }


            //usuario.Id_rol = (int)cboRoles.SelectedValue;



            return usuario;
        }//fin genera



        private void btnGuardar_Click(object sender, EventArgs e)
        {
            /*
            EntidadUsuario usuario = new EntidadUsuario();
            BLUsuario logicaUsuario = new BLUsuario(Configuracion.getConnectionString);
            int resultado;
            try
            {
                if (string.IsNullOrEmpty(txtNombreU.Text) | string.IsNullOrEmpty(txtContrasena.Text))
                {
                    MessageBox.Show("Faltan datos", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    usuario = generaUsuario();
                    resultado = logicaUsuario.LlamarMetodoInsertar(usuario);
                    LimpiarCampos();
                    MessageBox.Show("operacion fue exitosa", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            */



            EntidadUsuario usuario = new EntidadUsuario();
            BLUsuario logicaUsuario = new BLUsuario(Configuracion.getConnectionString);
            int resultado;
            try
            {
                if (!string.IsNullOrEmpty(txtNombreU.Text) && !string.IsNullOrEmpty(txtContrasena.Text))
                {
                    usuario = generaUsuario();
                    if (!usuario.Existe)
                    {
                        resultado = logicaUsuario.LlamarMetodoInsertar(usuario);
                    }
                    else
                    {
                        resultado = logicaUsuario.Modificar(usuario);
                    }
                    if (resultado > 0)
                    {
                        LimpiarCampos();
                        MessageBox.Show("operacion fue exitosa", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        CargarListaUsuarios();

                    }
                    else
                    {
                        MessageBox.Show("No se realizaron cambios", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }

                }
                else
                {
                    MessageBox.Show("Los datos son obligatorios", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }



        }//guardar (MODIFICADO PARA ACTUALIZAR Y GUARDAR)



        public void LimpiarCampos()
        {
            txtIdUsuario.Text = string.Empty;
            txtNombreU.Text = string.Empty;
            txtContrasena.Text = string.Empty;
            cboRoles.Text = string.Empty;

        }
        //(Hasta aquí es el procedimiento para insertar en la base de datos y guardar)

        //////////////////////////////////////////////////////////////////////////////////



        public void CargarListaUsuarios(string condicion = "")
        {
            BLUsuario logicaBuscar = new BLUsuario(Configuracion.getConnectionString);
            List<EntidadUsuario> listarUsuarios;
            try
            {
                listarUsuarios = logicaBuscar.LlamarListaUsuarios(condicion);
                if (listarUsuarios.Count > 0)
                {
                    grdUsuarios.DataSource = listarUsuarios;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        private void btnBuscar_Click(object sender, EventArgs e)
        {
            formularioBuscar = new FrmBuscarUSUARIO();
            formularioBuscar.Aceptar += new EventHandler(Aceptar);
            formularioBuscar.ShowDialog();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Aceptar(Object id, EventArgs e)
        {
            try
            {
                int idUsuario = (int)id;
                if (idUsuario != -1)
                {
                    CargarUsuario(idUsuario);
                }
                else
                {
                    LimpiarCampos();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CargarUsuario(int id)
        {
            EntidadUsuario usuario = new EntidadUsuario();
            BLUsuario traerUsuario = new BLUsuario(Configuracion.getConnectionString);
            try
            {
                usuario = traerUsuario.ObtenerUsuario(id);

                if (usuario != null)
                {
                    txtIdUsuario.Text = usuario.Id_usuario.ToString();
                    txtNombreU.Text = usuario.NombreUsuario;
                    txtContrasena.Text = usuario.Clave;
                    cboRoles.Text = usuario.Id_rol.ToString();
                }
                else
                {
                    MessageBox.Show("El usuario no se encuentra en la base de datos", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    CargarListaUsuarios();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            EntidadUsuario usuario;
            int resultado;
            BLUsuario logica = new BLUsuario(Configuracion.getConnectionString);
            try
            {
                if (!string.IsNullOrEmpty(txtIdUsuario.Text))
                {
                    usuario = logica.ObtenerUsuario(int.Parse(txtIdUsuario.Text));
                    if (usuario != null)
                    {
                        resultado = logica.EliminarUsuario(usuario);
                        MessageBox.Show("Se ha eliminado el registro", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LimpiarCampos();
                        CargarListaUsuarios();
                    }
                    else
                    {
                        MessageBox.Show("El usuario no existe", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        LimpiarCampos();
                        CargarListaUsuarios();
                    }
                }
                else
                {
                    MessageBox.Show("Debe seleccionar un usuario antes de eliminar", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FrmUsuarios_Load(object sender, EventArgs e)
        {
            // Agregar opciones al ComboBox
            cboNombreyIdRol.Items.Add("Busque el id de su Rol");
            cboNombreyIdRol.Items.Add("ID_ROL 1 Administrador");
            cboNombreyIdRol.Items.Add("ID_ROL 2 MEDICO ");
            cboNombreyIdRol.Items.Add("ID_ROL 3 ENFERMERO");
            cboNombreyIdRol.Items.Add("ID_ROL 4 ENFERMERO");

            // Establecer una opción seleccionada por defecto
            cboNombreyIdRol.SelectedIndex = 0;

            try   //cargamos la lista de pacientes al cargar el formulario y se muestra en el datagridview
            {
                CargarListaUsuarios();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


            BLUsuario roles = new BLUsuario(Configuracion.getConnectionString);

            // Obtener la lista de ID de roles desde la capa lógica
            List<int> idRoles = roles.ObtenerIdRoles();

            // Recorrer la lista de ID de roles y agregarlos al ComboBox
            foreach (int idRol in idRoles)
            {
                cboRoles.Items.Add(idRol);
            }





        }




    }
}
