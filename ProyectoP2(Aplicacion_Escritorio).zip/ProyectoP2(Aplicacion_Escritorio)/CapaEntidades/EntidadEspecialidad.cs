﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CapaEntidades
{
    public class EntidadEspecialidad
    {
        private int id_especialidad;
        private string nombre;

        public int Id_rol { get => id_especialidad; set => id_especialidad = value; }
        public string Nombre { get => nombre; set => nombre = value; }

        public EntidadEspecialidad()
        {
            id_especialidad = 0;
            nombre = string.Empty;
        }

        public EntidadEspecialidad(int id_rol, string nombre)
        {
            this.id_especialidad = id_rol;
            this.nombre = nombre;

        }
    }
}
