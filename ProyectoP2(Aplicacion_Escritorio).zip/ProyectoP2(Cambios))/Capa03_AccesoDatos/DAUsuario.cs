﻿using CapaEntidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Linq;

namespace Capa03_AccesoDatos
{
    public class DAUsuario
    {
        private string _cadenaConexion;
        private string _mensaje;

        //propiedes

        public string Mensaje
        {
            get => _mensaje;
        }

        public DAUsuario(string cadenaConexion)
        {
            _cadenaConexion = cadenaConexion;
            _mensaje = string.Empty;
        }




        public List<int> ObtenerIdRoles()
        {
            List<int> idRoles = new List<int>();

            using (SqlConnection conexion = new SqlConnection(_cadenaConexion))
            {
                string instruccionDB = "SELECT ID_ROL FROM ROL";

                using (SqlDataAdapter adapter = new SqlDataAdapter())
                {
                    adapter.SelectCommand = new SqlCommand(instruccionDB, conexion);

                    try
                    {
                        conexion.Open();
                        DataSet elDataSet = new DataSet();
                        adapter.Fill(elDataSet, "ROL");

                        foreach (DataRow fila in elDataSet.Tables["ROL"].Rows)
                        {
                            int idRol = Convert.ToInt32(fila["ID_ROL"]);
                            idRoles.Add(idRol);
                        }
                    }
                    catch (Exception)
                    {
                        throw;
                    }
                }
            }

            return idRoles;
        }//FIN OBTENER EL ROL EN LA CONSULTA












        public int Insertar(EntidadUsuario usuario)
        {
            int id = 0;
            //Establecer el objeto de conexión
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            //Establecer el objeto para ejecutar los comandos SQL
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            string sentencia = "INSERT INTO USUARIO (ID_ROL, NOMBRE_USUARIO, CLAVE)" +
                " VALUES(@ID_ROL, @NOMBRE_USUARIO, @CLAVE) SELECT @@IDENTITY";
            comando.Parameters.AddWithValue("@ID_ROL", usuario.Id_rol);
            comando.Parameters.AddWithValue("@NOMBRE_USUARIO", usuario.NombreUsuario);
            comando.Parameters.AddWithValue("@CLAVE", usuario.Clave);
            comando.CommandText = sentencia;
            try
            {
                conexion.Open();
                id = Convert.ToInt32(comando.ExecuteScalar());
                conexion.Close();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conexion.Dispose();
                comando.Dispose();
            }
            return id;
        }  //Fin de insertar (Hasta aquí es el procedimiento para insertar en la base de datos y guardar)
        //////////////////////////////////////////////////////////////////////////////////////////////////

      



        
        public List<EntidadUsuario> ListarUsuarios(string condicion = "")
        {
            DataSet elDataSet = new DataSet();
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlDataAdapter adapter;
            List<EntidadUsuario> listaUsuarios;

            string instruccionDB = "SELECT ID_USUARIO, ID_ROL, NOMBRE_USUARIO, CLAVE FROM USUARIO";

            if (!string.IsNullOrEmpty(condicion))
            {
                instruccionDB = string.Format("{0} WHERE {1}", instruccionDB, condicion);
            }
            try
            {
                adapter = new SqlDataAdapter(instruccionDB, conexion);
                adapter.Fill(elDataSet, "USUARIO");
                listaUsuarios = (from DataRow unaFila in elDataSet.Tables["USUARIO"].Rows
                                 select new EntidadUsuario()
                                 {
                                     Id_usuario = unaFila["ID_USUARIO"] != DBNull.Value ? (int)unaFila["ID_USUARIO"] : 0,
                                     Id_rol = unaFila["ID_ROL"] != DBNull.Value ? (int)unaFila["ID_ROL"] : 0,
                                     NombreUsuario = unaFila["NOMBRE_USUARIO"].ToString(),
                                     Clave = unaFila["CLAVE"].ToString(),
                                     Existe = true
                                 }).ToList();
            }
            catch (Exception)
            {
                throw;
            }
            return listaUsuarios;

        }








        public EntidadUsuario ObtenerUsuario(int id)
        {
            EntidadUsuario usuario = null;
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            SqlDataReader dataReader;
            string sentencia = string.Format("SELECT ID_USUARIO, ID_ROL, NOMBRE_USUARIO, CLAVE FROM USUARIO WHERE ID_USUARIO = {0}", id);
            comando.Connection = conexion;
            comando.CommandText = sentencia;
            try
            {
                conexion.Open();
                dataReader = comando.ExecuteReader();
                if (dataReader.HasRows)
                {
                    usuario = new EntidadUsuario();
                    dataReader.Read();
                    usuario.Id_usuario = dataReader.GetInt32(0);
                    usuario.Id_rol = dataReader.IsDBNull(1) ? 0 : dataReader.GetInt32(1);
                    usuario.NombreUsuario = dataReader.IsDBNull(2) ? string.Empty : dataReader.GetString(2);
                    usuario.Clave = dataReader.IsDBNull(3) ? string.Empty : dataReader.GetString(3);
                }
                conexion.Close();
            }
            catch (Exception)
            {
                throw;
            }
            return usuario;
        }







        // (Se elimina el paciente)
        ///
        // Eliminar Usuario
        public int EliminarUsuario(EntidadUsuario usuario)
        {
            int afectado = -1;
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            string sentencia = "DELETE FROM USUARIO WHERE ID_USUARIO = @ID_USUARIO";
            comando.CommandText = sentencia;
            comando.Connection = conexion;
            comando.Parameters.AddWithValue("@ID_USUARIO", usuario.Id_usuario);
            try
            {
                conexion.Open();
                afectado = comando.ExecuteNonQuery();
                conexion.Close();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conexion.Dispose();
                comando.Dispose();
            }
            return afectado;
        }

        // Modificar Usuario




        public int Modificar(EntidadUsuario usuario)
        {
            int filasAfectadas = -1;
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            string sentencia = "UPDATE USUARIO SET ID_ROL=@ID_ROL, NOMBRE_USUARIO=@NOMBRE_USUARIO, CLAVE=@CLAVE WHERE ID_USUARIO=@ID_USUARIO";
            comando.CommandText = sentencia;
            comando.Connection = conexion;
            comando.Parameters.AddWithValue("@ID_USUARIO", usuario.Id_usuario);
            comando.Parameters.AddWithValue("@ID_ROL", usuario.Id_rol);
            comando.Parameters.AddWithValue("@NOMBRE_USUARIO", usuario.NombreUsuario);
            comando.Parameters.AddWithValue("@CLAVE", usuario.Clave);
            try
            {
                conexion.Open();
                filasAfectadas = comando.ExecuteNonQuery();
                conexion.Close();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conexion.Dispose();
                comando.Dispose();
            }
            return filasAfectadas;
        }


    }
}