﻿namespace Capa01_Presentación
{
    partial class FrmHistorialM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmHistorialM));
            txtDescripcion = new System.Windows.Forms.TextBox();
            btnBuscar = new System.Windows.Forms.Button();
            btnEliminar = new System.Windows.Forms.Button();
            btnNuevo = new System.Windows.Forms.Button();
            btnGuardar = new System.Windows.Forms.Button();
            btnSalir = new System.Windows.Forms.Button();
            txtIdHistorial = new System.Windows.Forms.TextBox();
            grdHistorialM = new System.Windows.Forms.DataGridView();
            ID_HISTORIAL_MEDICO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ID_DIAGNOSTICO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ID_PACIENTE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            CLAVE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            DESCRIPCION = new System.Windows.Forms.DataGridViewTextBoxColumn();
            label1 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            dtCalendario = new System.Windows.Forms.DateTimePicker();
            label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)grdHistorialM).BeginInit();
            SuspendLayout();
            // 
            // txtDescripcion
            // 
            txtDescripcion.Location = new System.Drawing.Point(142, 129);
            txtDescripcion.Multiline = true;
            txtDescripcion.Name = "txtDescripcion";
            txtDescripcion.Size = new System.Drawing.Size(635, 53);
            txtDescripcion.TabIndex = 89;
            // 
            // btnBuscar
            // 
            btnBuscar.Image = (System.Drawing.Image)resources.GetObject("btnBuscar.Image");
            btnBuscar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            btnBuscar.Location = new System.Drawing.Point(18, 343);
            btnBuscar.Name = "btnBuscar";
            btnBuscar.Size = new System.Drawing.Size(111, 95);
            btnBuscar.TabIndex = 88;
            btnBuscar.Text = "&Buscar";
            btnBuscar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btnBuscar.UseVisualStyleBackColor = true;
            // 
            // btnEliminar
            // 
            btnEliminar.Image = (System.Drawing.Image)resources.GetObject("btnEliminar.Image");
            btnEliminar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            btnEliminar.Location = new System.Drawing.Point(184, 343);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new System.Drawing.Size(111, 95);
            btnEliminar.TabIndex = 87;
            btnEliminar.Text = "&Eliminar";
            btnEliminar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btnEliminar.UseVisualStyleBackColor = true;
            btnEliminar.Click += btnEliminar_Click;
            // 
            // btnNuevo
            // 
            btnNuevo.Image = (System.Drawing.Image)resources.GetObject("btnNuevo.Image");
            btnNuevo.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            btnNuevo.Location = new System.Drawing.Point(512, 343);
            btnNuevo.Name = "btnNuevo";
            btnNuevo.Size = new System.Drawing.Size(111, 95);
            btnNuevo.TabIndex = 86;
            btnNuevo.Text = "&Nuevo";
            btnNuevo.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btnNuevo.UseVisualStyleBackColor = true;
            btnNuevo.Click += btnNuevo_Click;
            // 
            // btnGuardar
            // 
            btnGuardar.Image = (System.Drawing.Image)resources.GetObject("btnGuardar.Image");
            btnGuardar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            btnGuardar.Location = new System.Drawing.Point(347, 343);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new System.Drawing.Size(111, 95);
            btnGuardar.TabIndex = 85;
            btnGuardar.Text = "&Guardar";
            btnGuardar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btnGuardar.UseVisualStyleBackColor = true;
            btnGuardar.Click += btnGuardar_Click;
            // 
            // btnSalir
            // 
            btnSalir.Image = (System.Drawing.Image)resources.GetObject("btnSalir.Image");
            btnSalir.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            btnSalir.Location = new System.Drawing.Point(672, 343);
            btnSalir.Name = "btnSalir";
            btnSalir.Size = new System.Drawing.Size(95, 95);
            btnSalir.TabIndex = 84;
            btnSalir.Text = "&Salir";
            btnSalir.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btnSalir.UseVisualStyleBackColor = true;
            btnSalir.Click += btnSalir_Click;
            // 
            // txtIdHistorial
            // 
            txtIdHistorial.BackColor = System.Drawing.SystemColors.Info;
            txtIdHistorial.Location = new System.Drawing.Point(28, 73);
            txtIdHistorial.Name = "txtIdHistorial";
            txtIdHistorial.ReadOnly = true;
            txtIdHistorial.Size = new System.Drawing.Size(75, 31);
            txtIdHistorial.TabIndex = 82;
            // 
            // grdHistorialM
            // 
            grdHistorialM.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            grdHistorialM.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            grdHistorialM.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] { ID_HISTORIAL_MEDICO, ID_DIAGNOSTICO, ID_PACIENTE, CLAVE, DESCRIPCION });
            grdHistorialM.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            grdHistorialM.Location = new System.Drawing.Point(18, 200);
            grdHistorialM.Name = "grdHistorialM";
            grdHistorialM.ReadOnly = true;
            grdHistorialM.RowHeadersWidth = 62;
            grdHistorialM.RowTemplate.Height = 33;
            grdHistorialM.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            grdHistorialM.Size = new System.Drawing.Size(759, 116);
            grdHistorialM.TabIndex = 81;
            // 
            // ID_HISTORIAL_MEDICO
            // 
            ID_HISTORIAL_MEDICO.DataPropertyName = "ID_HISTORIAL_MEDICO";
            ID_HISTORIAL_MEDICO.HeaderText = "ID_HISTORIAL_MEDICO";
            ID_HISTORIAL_MEDICO.MinimumWidth = 8;
            ID_HISTORIAL_MEDICO.Name = "ID_HISTORIAL_MEDICO";
            ID_HISTORIAL_MEDICO.ReadOnly = true;
            ID_HISTORIAL_MEDICO.Width = 150;
            // 
            // ID_DIAGNOSTICO
            // 
            ID_DIAGNOSTICO.DataPropertyName = "ID_DIAGNOSTICO";
            ID_DIAGNOSTICO.HeaderText = "ID_DIAGNOSTICO";
            ID_DIAGNOSTICO.MinimumWidth = 8;
            ID_DIAGNOSTICO.Name = "ID_DIAGNOSTICO";
            ID_DIAGNOSTICO.ReadOnly = true;
            ID_DIAGNOSTICO.Visible = false;
            ID_DIAGNOSTICO.Width = 150;
            // 
            // ID_PACIENTE
            // 
            ID_PACIENTE.DataPropertyName = "ID_PACIENTE";
            ID_PACIENTE.HeaderText = "ID_PACIENTE";
            ID_PACIENTE.MinimumWidth = 8;
            ID_PACIENTE.Name = "ID_PACIENTE";
            ID_PACIENTE.ReadOnly = true;
            ID_PACIENTE.Width = 150;
            // 
            // CLAVE
            // 
            CLAVE.DataPropertyName = "FECHA_CREACION";
            CLAVE.HeaderText = "FECHA_CREACION";
            CLAVE.MinimumWidth = 8;
            CLAVE.Name = "CLAVE";
            CLAVE.ReadOnly = true;
            CLAVE.Width = 150;
            // 
            // DESCRIPCION
            // 
            DESCRIPCION.DataPropertyName = "DESCRIPCION";
            DESCRIPCION.HeaderText = "DESCRIPCIÓN";
            DESCRIPCION.MinimumWidth = 8;
            DESCRIPCION.Name = "DESCRIPCION";
            DESCRIPCION.ReadOnly = true;
            DESCRIPCION.Width = 150;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(27, 28);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(102, 25);
            label1.TabIndex = 90;
            label1.Text = "ID_Historial";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(375, 18);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(0, 25);
            label2.TabIndex = 92;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new System.Drawing.Point(18, 129);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(104, 25);
            label4.TabIndex = 94;
            label4.Text = "Descripción";
            // 
            // dtCalendario
            // 
            dtCalendario.Location = new System.Drawing.Point(142, 71);
            dtCalendario.Name = "dtCalendario";
            dtCalendario.Size = new System.Drawing.Size(340, 31);
            dtCalendario.TabIndex = 95;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new System.Drawing.Point(270, 28);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(132, 25);
            label3.TabIndex = 96;
            label3.Text = "Fecha_Creación";
            // 
            // FrmHistorialM
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(800, 450);
            Controls.Add(label3);
            Controls.Add(dtCalendario);
            Controls.Add(label4);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtDescripcion);
            Controls.Add(btnBuscar);
            Controls.Add(btnEliminar);
            Controls.Add(btnNuevo);
            Controls.Add(btnGuardar);
            Controls.Add(btnSalir);
            Controls.Add(txtIdHistorial);
            Controls.Add(grdHistorialM);
            Name = "FrmHistorialM";
            Text = "FrmHistorialM";
            Load += FrmHistorialM_Load;
            ((System.ComponentModel.ISupportInitialize)grdHistorialM).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.TextBox txtDescripcion;
        private System.Windows.Forms.Button btnBuscar;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.Button btnNuevo;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.TextBox txtIdHistorial;
        private System.Windows.Forms.DataGridView grdHistorialM;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_HISTORIAL_MEDICO;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_DIAGNOSTICO;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_PACIENTE;
        private System.Windows.Forms.DataGridViewTextBoxColumn CLAVE;
        private System.Windows.Forms.DataGridViewTextBoxColumn DESCRIPCION;
        private System.Windows.Forms.DateTimePicker dtCalendario;
        private System.Windows.Forms.Label label3;
    }
}