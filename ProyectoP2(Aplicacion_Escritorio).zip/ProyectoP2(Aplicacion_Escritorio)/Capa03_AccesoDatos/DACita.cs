﻿using CapaEntidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Linq;
using System.Globalization;


namespace Capa03_AccesoDatos
{
    public class DACita
    {
        private string nombreMedico;
        private string nombreEspecialidad;

        private string _cadenaConexion;
        private string _mensaje;

        //propiedes

        public string Mensaje
        {
            get => _mensaje;
        }
        //constructor de la clase
        public DACita(string cadenaConexion)
        {
            _cadenaConexion = cadenaConexion;
            _mensaje = string.Empty;
        }

        public List<string> ObtenerEspecialidades()
        {
            /*
            List<string> especialidades = new List<string>();

            DataSet elDataSet = new DataSet();
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlDataAdapter adapter;

            string instruccionDB = "SELECT NOMBRE FROM ESPECIALIDAD";

            try
            {
                conexion.Open(); // Abre la conexión antes de ejecutar la consulta

                adapter = new SqlDataAdapter(instruccionDB, conexion);
                adapter.Fill(elDataSet, "ESPECIALIDAD");

                foreach (DataRow fila in elDataSet.Tables["ESPECIALIDAD"].Rows)
                {
                    string especialidad = fila["NOMBRE"].ToString();
                    especialidades.Add(especialidad);
                }

                conexion.Close(); // Cierra la conexión después de utilizarla
            }
            catch (Exception)
            {
                throw;
            }

            return especialidades;
            */


            
            List<string> especialidades = new List<string>();
            // se utiliza bloques using para garantizar que la conexión y el adaptador se cierren correctamente, incluso en caso de excepciones
            using (SqlConnection conexion = new SqlConnection(_cadenaConexion))
            {
                string instruccionDB = @"SELECT M.ID_MEDICO, M.NOMBRE, M.APELLIDO, E.NOMBRE AS ESPECIALIDAD
                                FROM MEDICO M
                                INNER JOIN ESPECIALIDAD E ON M.ID_ESPECIALIDAD = E.ID_ESPECIALIDAD"; //consulta o instrucción select tal y como aparece en la BD

                using (SqlDataAdapter adapter = new SqlDataAdapter())
                {    //Se Establece la consulta SQL en el comando de selección del adaptador
                    adapter.SelectCommand = new SqlCommand(instruccionDB, conexion);

                    try
                    {
                        conexion.Open(); // Abre la conexión antes de ejecutar la consulta
                        DataSet elDataSet = new DataSet();
                        adapter.Fill(elDataSet, "MEDICO_ESPECIALIDAD");
                        // Se Itera sobre cada fila del DataSet para obtener los datos de los médicos
                        foreach (DataRow fila in elDataSet.Tables["MEDICO_ESPECIALIDAD"].Rows)
                        {    // Obtenemos los valores de nombre, apellido y especialidad de cada fila
                            string idMedico = fila["ID_MEDICO"].ToString();
                            string nombreMedico = fila["NOMBRE"].ToString();
                            string apellidoMedico = fila["APELLIDO"].ToString();
                            string especialidadMedico = fila["ESPECIALIDAD"].ToString();
                            // Concatenamos nombre, apellido y especialidad en una sola cadena
                            string datosMedico = $"ID: {idMedico}, Nombre: {nombreMedico} {apellidoMedico}, Especialidad: {especialidadMedico}";
                            especialidades.Add(datosMedico);// Agregamos la cadena al listado, esta contiene los datos del medico,id y especialidad
                        }
                    }
                    catch (Exception)
                    {
                        throw;
                    }
                }
            }

            return especialidades;


        }//Fin de obtenerEspecialidad //método enfocado en mostrar la info en el comboBox

        
        public int Insertar(EntidadCita cita)
        {   /*
            int id = 0;
            //Establecer el objeto de conexión
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            //Establecer el objeto para ejecutar los comandos SQL
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            string sentencia = "INSERT INTO CITA (FECHA, HORA, DESCRIPCION, DETALLE_MEDICO)" +
            " VALUES (@FECHA, @HORA, @DESCRIPCION,  @DETALLE_MEDICO) SELECT @@IDENTITY";
            comando.Parameters.AddWithValue("@FECHA", cita.Fecha);
            comando.Parameters.AddWithValue("@HORA", cita.Hora);
            comando.Parameters.AddWithValue("@DESCRIPCION", cita.Descripcion);
            comando.Parameters.AddWithValue("@ID_PACIENTE", cita.Id_paciente);
            comando.Parameters.AddWithValue("@DETALLE_MEDICO", cita.Detalle_Medico);
            comando.CommandText = sentencia;
            try
            {
                conexion.Open();
                id = Convert.ToInt32(comando.ExecuteScalar());
                conexion.Close();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conexion.Dispose();
                comando.Dispose();
            }
            return id;
            */
            int id = 0;
            using (SqlConnection conexion = new SqlConnection(_cadenaConexion))
            {
                SqlCommand comando = new SqlCommand();
                comando.Connection = conexion;
                List<EntidadCita> citasExistentes = ListarCitas($"DETALLE_MEDICO = '{cita.Detalle_Medico}' AND FECHA = '{cita.Fecha}'");
                bool medicoOcupado = citasExistentes.Any(c => c.Hora == cita.Hora);//verifica si hay alguna cita existente en la lista citasExistentes cuya propiedad Hora
                                                                                   //sea igual a la hora de la cita que se está intentando insertar (cita.Hora)
                if (medicoOcupado)
                {
                    // El médico ya tiene una cita a la misma hora
                    // Realiza la acción correspondiente, como mostrar un mensaje de error
                    throw new Exception("El médico ya tiene una cita programada en esa hora. Por favor, seleccione otro horario.");
                    
                }
                string sentencia = "INSERT INTO CITA (FECHA, HORA, DESCRIPCION, DETALLE_MEDICO) " +
                                   "VALUES (@FECHA, @HORA, @DESCRIPCION, @DETALLE_MEDICO); " +
                                   "SELECT SCOPE_IDENTITY();";
                comando.Parameters.AddWithValue("@FECHA", cita.Fecha);
                comando.Parameters.AddWithValue("@HORA", cita.Hora);
                comando.Parameters.AddWithValue("@DESCRIPCION", cita.Descripcion);
                comando.Parameters.AddWithValue("@DETALLE_MEDICO", cita.Detalle_Medico);
                comando.CommandText = sentencia;
                try
                {
                    conexion.Open();
                    id = Convert.ToInt32(comando.ExecuteScalar());
                    conexion.Close();
                }
                catch (Exception)
                {
                    throw;
                }
            }
            return id;




        }  //Fin de insertar (Hasta aquí es el procedimiento para insertar en la base de datos y guardar)
        
        public List<EntidadCita> ListarCitas(string condicion = "")
        {
            DataSet elDataSet = new DataSet();
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlDataAdapter adapter;
            List<EntidadCita> listaCitas;

            string instruccionDB = "SELECT ID_CITA, FECHA, HORA, DESCRIPCION, ID_MEDICO, ID_PAGO,  ID_PACIENTE, DETALLE_MEDICO FROM CITA";

            if (!string.IsNullOrEmpty(condicion))
            {
                instruccionDB = instruccionDB = $"{instruccionDB} WHERE {condicion}";

                //string.Format("{0} WHERE {1}", instruccionDB, condicion);
            }
            try
            {
                adapter = new SqlDataAdapter(instruccionDB, conexion);
                adapter.Fill(elDataSet, "CITA");
                listaCitas = (from DataRow unaFila in elDataSet.Tables["CITA"].Rows
                              select new EntidadCita()
                              {
                                  /*
                                  Id_cita = (int)unaFila[0],
                                  Fecha = DateTime.TryParse(unaFila[3].ToString(), out var fechaAceptable) ? fechaAceptable : DateTime.MinValue,
                                  Hora = TimeSpan.TryParse(unaFila[2].ToString(), out var horaAceptable) ? horaAceptable : TimeSpan.Zero,
                                  //Si el TryParse es exitoso se le asignará el valor de fechaAceptable a Fecha de lo contrario
                                  //se le asigna un valor por defecto de DateTime.MinValue = 0
                                  Descripcion = unaFila[4].ToString(),
                                  Detalle_Medico = unaFila[5].ToString(),
                                  Id_paciente= (int)unaFila[6],
                                  */
                                  
                                  Id_cita = (int)unaFila[0],
                                  //Fecha = DateTime.TryParse(unaFila[1].ToString(), out var fechaAceptable) ? fechaAceptable : DateTime.MinValue,
                                  Fecha = DateTime.TryParse(unaFila[1].ToString(), out var fechaAceptable) ? fechaAceptable : DateTime.MinValue,
                                  //Fecha = Convert.ToDateTime(unaFila[1]),
                                  //Hora = Convert.ToDateTime(unaFila[2]).TimeOfDay,
                                  Hora = TimeSpan.TryParse(unaFila[2].ToString(), out var horaAceptable) ? horaAceptable : TimeSpan.Zero,
                                  Descripcion = unaFila[3].ToString(),

                                  //Id_medico = (int)unaFila[4],
                                  //Id_pago = (int)unaFila[5],
                                  //Id_paciente = (int)unaFila[6],
                                  //Id_paciente = (int)unaFila[4], //[6],
                                  Detalle_Medico = unaFila[7].ToString() //[7].ToString(),

                              }).ToList();
            }
            catch (Exception)
            {
                throw;
            }
            return listaCitas;

        }

        public EntidadCita ObtenerCita(int id)
        {
            EntidadCita cita = null;
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            SqlDataReader dataReader;
            string sentencia = string.Format("SELECT ID_CITA, FECHA, HORA, DESCRIPCION, DETALLE_MEDICO, ID_PACIENTE FROM " +
                "CITA WHERE ID_CITA = {0}", id);
            comando.Connection = conexion;
            comando.CommandText = sentencia;
            try
            {
                conexion.Open();
                dataReader = comando.ExecuteReader();
                if (dataReader.HasRows)
                {
                    cita = new EntidadCita();
                    dataReader.Read();
                    cita.Id_cita = dataReader.GetInt32(0);
                    cita.Fecha = dataReader.GetDateTime(1);
                    cita.Hora = dataReader.GetDateTime(2).TimeOfDay;  
                    cita.Descripcion = dataReader.GetString(3);
                    //DateTime.TryParse(dataReader.GetString(3), out DateTime fechaNacimiento);
                    
                    //cita.Id_paciente = dataReader.GetInt32(4);
                    cita.Detalle_Medico = dataReader.GetString(5);
                    cita.Estado_Pago = false;

                }
                conexion.Close();
            }
            catch (Exception)
            {
                throw;
            }
            return cita;
        }  //fin obtener cliente 

        public int EliminarCita(EntidadCita cita)
        {
            int afectado = -1;
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            string sentencia = "DELETE FROM CITA";
            sentencia = string.Format("{0} WHERE ID_CITA = {1}", sentencia, cita.Id_cita);
            comando.CommandText = sentencia;
            comando.Connection = conexion;
            try
            {
                conexion.Open();
                afectado = comando.ExecuteNonQuery();
                conexion.Close();

            }
            catch (Exception)
            {
                throw;

            }
            finally
            {
                conexion.Dispose();
                conexion.Dispose();
            }
            return afectado;
        }//fIN DE ELIMINAR


        // (Actualizar Cliente)
        ///
        public int Modificar(EntidadCita cita)
        {
            int filasAfectadas = -1;
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            string sentencia = "UPDATE CITA SET  FECHA= @FECHA, HORA=@HORA, DESCRIPCION=@DESCRIPCION, DETALLE_MEDICO=@DETALLE_MEDICO WHERE ID_CITA=@ID_CITA";
            comando.CommandText = sentencia;
            comando.Connection = conexion;
            comando.Parameters.AddWithValue("@FECHA", cita.Fecha);
            comando.Parameters.AddWithValue("@HORA", cita.Hora);
            comando.Parameters.AddWithValue("@DESCRIPCION", cita.Descripcion);
            comando.Parameters.AddWithValue("@DETALLE_MEDICO", cita.Detalle_Medico);
            
            try
            {
                conexion.Open();
                filasAfectadas = comando.ExecuteNonQuery();
                conexion.Close();

            }
            catch (Exception)
            {
                throw;

            }
            finally
            {
                conexion.Dispose();
                comando.Dispose();
            }
            return filasAfectadas;


        }//FIN DE ACTUALIZAR




    }
}
