﻿using CapaEntidades;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Text;
using System.Linq;

namespace Capa03_AccesoDatos
{
    public class DAHorario
    {

        private string _cadenaConexion;
        private string _mensaje;

        public string Mensaje
        {
            get => _mensaje;
        }

        public DAHorario(string cadenaConexion)
        {
            _cadenaConexion = cadenaConexion;
            _mensaje = string.Empty;
        }

        public int Insertar(EntidadHorario horario)
        {
            int id = 0;
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            string sentencia = "INSERT INTO Horario (DIASTRABAJADOS, HORAINICIO, HORAFIN) " +
                "VALUES (@DIASTRABAJADOS, @HORAINICIO, @HORAFIN); SELECT SCOPE_IDENTITY();";
            //comando.Parameters.AddWithValue("@ID_Usuario", horario.Id_usuario);
            comando.Parameters.AddWithValue("@DIASTRABAJADOS", horario.DiasTrabajados);
            comando.Parameters.AddWithValue("@HORAINICIO", horario.HoraInicio);
            comando.Parameters.AddWithValue("@HORAFIN", horario.HoraFin);
            comando.CommandText = sentencia;
            try
            {
                conexion.Open();
                id = Convert.ToInt32(comando.ExecuteScalar());
                conexion.Close();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conexion.Dispose();
                comando.Dispose();
            }
            return id;
        }

        public List<EntidadHorario> ListarHorarios(string condicion = "")
        {
            DataSet elDataSet = new DataSet();
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlDataAdapter adapter;
            List<EntidadHorario> listaHorarios;

            string instruccionDB = "SELECT ID_Horario, ID_Usuario, DIASTRABAJADOS, HORAINICIO, HORAFIN FROM Horario";

            if (!string.IsNullOrEmpty(condicion))
            {
                instruccionDB = string.Format("{0} WHERE {1}", instruccionDB, condicion);
            }
            try
            {
                adapter = new SqlDataAdapter(instruccionDB, conexion);
                adapter.Fill(elDataSet, "HORARIO");
                listaHorarios = (from DataRow unaFila in elDataSet.Tables["HORARIO"].Rows
                                 select new EntidadHorario()
                                 {
                                     Id_horario = (int)unaFila[0],
                                     Id_usuario = (int)unaFila[1],
                                     DiasTrabajados = unaFila[2].ToString(),
                                     HoraInicio = TimeSpan.Parse(unaFila[3].ToString()),
                                     HoraFin = TimeSpan.Parse(unaFila[4].ToString())
                                 }).ToList();
            }
            catch (Exception)
            {
                throw;
            }
            return listaHorarios;
        }

        public EntidadHorario ObtenerHorario(int id)
        {
            EntidadHorario horario = null;
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            SqlDataReader dataReader;
            string sentencia = string.Format("SELECT ID_Horario, ID_Usuario, DIASTRABAJADOS, HORAINICIO, HORAFIN FROM Horario " +
                "WHERE ID_Horario = {0}", id);
            comando.Connection = conexion;
            comando.CommandText = sentencia;
            try
            {
                conexion.Open();
                dataReader = comando.ExecuteReader();
                if (dataReader.HasRows)
                {
                    horario = new EntidadHorario();
                    dataReader.Read();
                    horario.Id_horario = dataReader.GetInt32(0);
                    horario.Id_usuario = dataReader.GetInt32(1);
                    horario.DiasTrabajados = dataReader.GetString(2);
                    horario.HoraInicio = TimeSpan.Parse(dataReader[3].ToString());
                    horario.HoraFin = TimeSpan.Parse(dataReader[4].ToString());
                }
                conexion.Close();
            }
            catch (Exception)
            {
                throw;
            }
            return horario;
        }

        public int EliminarHorario(EntidadHorario horario)
        {
            int afectado = -1;
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            string sentencia = "DELETE FROM Horario";
            sentencia = string.Format("{0} WHERE ID_Horario = {1}", sentencia, horario.Id_horario);
            comando.CommandText = sentencia;
            comando.Connection = conexion;
            try
            {
                conexion.Open();
                afectado = comando.ExecuteNonQuery();
                conexion.Close();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conexion.Dispose();
                comando.Dispose();
            }
            return afectado;
        }

        public int Modificar(EntidadHorario horario)
        {
            int filasAfectadas = -1;
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            string sentencia = "UPDATE Horario SET ID_Usuario=@ID_Usuario, DIASTRABAJADOS=@DIASTRABAJADOS, " +
                "HORAINICIO=@HORAINICIO, HORAFIN=@HORAFIN WHERE ID_Horario=@ID_Horario";
            comando.CommandText = sentencia;
            comando.Connection = conexion;
            comando.Parameters.AddWithValue("@ID_Horario", horario.Id_horario);
            comando.Parameters.AddWithValue("@ID_Usuario", horario.Id_usuario);
            comando.Parameters.AddWithValue("@DIASTRABAJADOS", horario.DiasTrabajados);
            comando.Parameters.AddWithValue("@HORAINICIO", horario.HoraInicio);
            comando.Parameters.AddWithValue("@HORAFIN", horario.HoraFin);
            try
            {
                conexion.Open();
                filasAfectadas = comando.ExecuteNonQuery();
                conexion.Close();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conexion.Dispose();
                comando.Dispose();
            }
            return filasAfectadas;
        }




    }
}
