﻿using Capa02_LogicaNegocio;
using CapaEntidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Capa01_Presentación
{
    public partial class FrmHorarios : Form
    {
        public FrmHorarios()
        {
            InitializeComponent();
        }

        FrmBuscarHorario formularioBuscar;
        EntidadHorario horarioRegistrado;



        // Crea un objeto con los datos ingresados en las casillas de texto
        public EntidadHorario GeneraHorario()
        {
            EntidadHorario horario;
            if (!string.IsNullOrEmpty(txtIdHorario.Text))
            {
                horario = horarioRegistrado;
            }
            else
            {
                horario = new EntidadHorario();
            }

            //EntidadHorario unHorario = new EntidadHorario();
            
            //txtIdHorario.Text = horario.Id_horario.ToString();
            horario.DiasTrabajados= txtDiasTrabajados.Text;
            
            TimeSpan horaInicio;
            if (TimeSpan.TryParse(txtHoraInicio.Text, out horaInicio))
            {
                horario.HoraInicio = horaInicio;
            }
            else
            {
                horaInicio = TimeSpan.Zero;
            }
            TimeSpan horaFin;

            if (TimeSpan.TryParse(txtHoraFin.Text, out horaFin))
            {
                horario.HoraFin = horaFin;
            }
            else
            {
                horaFin= TimeSpan.Zero;
            }

            
            

            return horario;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            EntidadHorario horario = GeneraHorario();
            BLHorario logicaHorario = new BLHorario(Configuracion.getConnectionString);
            int resultado;

            try
            {
                if (string.IsNullOrEmpty(txtDiasTrabajados.Text) || string.IsNullOrEmpty(txtHoraInicio.Text) || string.IsNullOrEmpty(txtHoraFin.Text))
                {
                    MessageBox.Show("Los datos son obligatorios", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    horario = GeneraHorario();
                    if (horario.Id_horario != 0)
                    {
                        resultado = logicaHorario.Modificar(horario);
                        if (resultado > 0)
                        {
                            LimpiarCampos();
                            MessageBox.Show("Operación exitosa", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            CargarListaHorarios();
                        }
                        else
                        {
                            MessageBox.Show("No se realizaron cambios", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    else
                    {
                        resultado = logicaHorario.LlamarMetodoInsertar(horario);
                        if (resultado > 0)
                        {
                            LimpiarCampos();
                            MessageBox.Show("Operación exitosa", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            CargarListaHorarios();
                        }
                        else
                        {
                            MessageBox.Show("No se pudo guardar el horario", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void LimpiarCampos()
        {
            txtIdHorario.Text = string.Empty;
            txtIdUsuario.Text = string.Empty;
            txtDiasTrabajados.Text = string.Empty;
            txtHoraInicio.Text = string.Empty;
            txtHoraFin.Text = string.Empty;
            txtDiasTrabajados.Focus();
        }

        public void CargarListaHorarios(string condicion = "")
        {
            BLHorario logicaBuscar = new BLHorario(Configuracion.getConnectionString);
            List<EntidadHorario> listarHorarios;
            try
            {
                listarHorarios = logicaBuscar.LlamarListaHorarios(condicion);
                if (listarHorarios.Count > 0)
                {
                    grdHorarios.DataSource = listarHorarios;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        /*
        private void btnBuscar_Click(object sender, EventArgs e)
        {
            formularioBuscar = new FrmBuscarHorario();
            formularioBuscar.Aceptar += new EventHandler(Aceptar);
            formularioBuscar.ShowDialog();
        }
          */
        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Aceptar(Object id, EventArgs e)
        {
            try
            {
                int idHorario = (int)id;
                if (idHorario != -1)
                {
                    CargarHorario(idHorario);
                }
                else
                {
                    LimpiarCampos();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CargarHorario(int id)
        {
            EntidadHorario horario = new EntidadHorario();
            BLHorario traerHorario = new BLHorario(Configuracion.getConnectionString);
            try
            {
                horario = traerHorario.ObtenerHorario(id);

                if (horario != null)
                {
                    txtIdHorario.Text = horario.Id_horario.ToString();
                    txtIdUsuario.Text = horario.Id_usuario.ToString();
                    txtDiasTrabajados.Text = horario.DiasTrabajados;
                    txtHoraInicio.Text = horario.HoraInicio.ToString();
                    txtHoraFin.Text = horario.HoraFin.ToString();
                }
                else
                {
                    MessageBox.Show("El horario no se encuentra en la base de datos", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    CargarListaHorarios();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            EntidadHorario horario;
            int resultado;
            BLHorario logica = new BLHorario(Configuracion.getConnectionString);
            try
            {
                if (!string.IsNullOrEmpty(txtIdHorario.Text))
                {
                    horario = logica.ObtenerHorario(int.Parse(txtIdHorario.Text));
                    if (horario != null)
                    {
                        resultado = logica.EliminarHorario(horario);
                        MessageBox.Show("Se ha eliminado el registro", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LimpiarCampos();
                        CargarListaHorarios();
                    }
                    else
                    {
                        MessageBox.Show("El horario no existe", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        LimpiarCampos();
                        CargarListaHorarios();
                    }
                }
                else
                {
                    MessageBox.Show("Debe seleccionar un horario antes de eliminar", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FrmHorarios_Load(object sender, EventArgs e)
        {
            try
            {
                CargarListaHorarios();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
