﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CapaEntidades
{
    public class EntidadDiagnostico
    {
        private int id_diagnostico;
        private int id_tratamiento;
        private string descripcion;

        public int Id_diagnostico { get => id_diagnostico; set => id_diagnostico = value; }
        public int Id_tratamiento { get => id_tratamiento; set => id_tratamiento = value; }
        public string Descripcion { get => descripcion; set => descripcion = value; }

        public EntidadDiagnostico (int id_diagnostico, int id_tratamiento, string descripcion)
        {
            this.id_diagnostico = id_diagnostico;
            this.id_tratamiento = id_tratamiento;
            this.descripcion = descripcion;
        }
        public EntidadDiagnostico() { }
    }
}
