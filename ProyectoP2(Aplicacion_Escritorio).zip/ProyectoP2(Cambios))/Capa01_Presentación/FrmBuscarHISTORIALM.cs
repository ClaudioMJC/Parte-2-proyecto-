﻿using Capa02_LogicaNegocio;
using Capa03_AccesoDatos;
using CapaEntidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Capa01_Presentación
{
    public partial class FrmBuscarHISTORIALM : Form
    {
        public event EventHandler Aceptar;
        int global_id_historial;
        public FrmBuscarHISTORIALM()
        {
            InitializeComponent();
        }



        public void CargarListaHistoriales(string condicion = "")
        {
            BLHistorial accesoDatosHistorial = new BLHistorial(Configuracion.getConnectionString);
            List<EntidadHistorial_Medico> listarHistoriales;
            try
            {
                listarHistoriales = accesoDatosHistorial.LlamarListaHistoriales(condicion);
                if (listarHistoriales.Count > 0)
                {
                    grdHistorialM.DataSource = listarHistoriales;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            string condicion = string.Empty;
            try
            {
                if (!string.IsNullOrEmpty(txtIdHistorial.Text))
                {
                    condicion = string.Format("ID_HISTORIAL_MEDICO = {0}", txtIdHistorial.Text.Trim());
                }
                else
                {
                    MessageBox.Show("Debe ingresar un ID de historial para realizar la búsqueda", "Atención",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtIdHistorial.Focus();
                }
                CargarListaHistoriales(condicion);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void seleccionar()
        {
            if (grdHistorialM.SelectedRows.Count > 0) // Verificar si hay filas seleccionadas
            {
                string nombreColumna = "ID_HISTORIAL_MEDICO";
                int indiceColumna = grdHistorialM.Columns[nombreColumna].Index;
                DataGridViewCell cell = grdHistorialM.SelectedRows[0].Cells[indiceColumna];
                if (cell != null && cell.Value != null)
                {
                    int idHistorial = (int)cell.Value;
                    Aceptar(idHistorial, null);
                    Close();
                }
            }
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            seleccionar();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Aceptar(-1, null);
            Close();
        }

        private void grdHistorialM_DoubleClick(object sender, EventArgs e)
        {
            int idHistorial = 0;
            try
            {
                idHistorial = (int)grdHistorialM.SelectedRows[0].Cells["ID_HISTORIAL_MEDICO"].Value;
                CargarListaHistoriales(idHistorial.ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        private void FrmBuscarHISTORIALM_Load(object sender, EventArgs e)
        {
            try
            {
                CargarListaHistoriales();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
