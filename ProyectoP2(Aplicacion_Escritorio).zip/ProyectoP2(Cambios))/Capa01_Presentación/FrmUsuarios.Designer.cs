﻿namespace Capa01_Presentación
{
    partial class FrmUsuarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmUsuarios));
            txtNombreU = new System.Windows.Forms.TextBox();
            btnBuscar = new System.Windows.Forms.Button();
            btnEliminar = new System.Windows.Forms.Button();
            btnNuevo = new System.Windows.Forms.Button();
            btnGuardar = new System.Windows.Forms.Button();
            btnSalir = new System.Windows.Forms.Button();
            txtContrasena = new System.Windows.Forms.TextBox();
            txtIdUsuario = new System.Windows.Forms.TextBox();
            grdUsuarios = new System.Windows.Forms.DataGridView();
            ID_USUARIO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ID_ROL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            NOMBRE_USUARIO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            CLAVE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            label1 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            cboNombreyIdRol = new System.Windows.Forms.ComboBox();
            label4 = new System.Windows.Forms.Label();
            cboRoles = new System.Windows.Forms.ComboBox();
            label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)grdUsuarios).BeginInit();
            SuspendLayout();
            // 
            // txtNombreU
            // 
            txtNombreU.Location = new System.Drawing.Point(391, 81);
            txtNombreU.Name = "txtNombreU";
            txtNombreU.Size = new System.Drawing.Size(122, 31);
            txtNombreU.TabIndex = 80;
            // 
            // btnBuscar
            // 
            btnBuscar.Image = (System.Drawing.Image)resources.GetObject("btnBuscar.Image");
            btnBuscar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            btnBuscar.Location = new System.Drawing.Point(26, 354);
            btnBuscar.Name = "btnBuscar";
            btnBuscar.Size = new System.Drawing.Size(111, 95);
            btnBuscar.TabIndex = 79;
            btnBuscar.Text = "&Buscar";
            btnBuscar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btnBuscar.UseVisualStyleBackColor = true;
            btnBuscar.Click += btnBuscar_Click;
            // 
            // btnEliminar
            // 
            btnEliminar.Image = (System.Drawing.Image)resources.GetObject("btnEliminar.Image");
            btnEliminar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            btnEliminar.Location = new System.Drawing.Point(192, 354);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new System.Drawing.Size(111, 95);
            btnEliminar.TabIndex = 78;
            btnEliminar.Text = "&Eliminar";
            btnEliminar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btnEliminar.UseVisualStyleBackColor = true;
            btnEliminar.Click += btnEliminar_Click;
            // 
            // btnNuevo
            // 
            btnNuevo.Image = (System.Drawing.Image)resources.GetObject("btnNuevo.Image");
            btnNuevo.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            btnNuevo.Location = new System.Drawing.Point(524, 354);
            btnNuevo.Name = "btnNuevo";
            btnNuevo.Size = new System.Drawing.Size(111, 95);
            btnNuevo.TabIndex = 77;
            btnNuevo.Text = "&Nuevo";
            btnNuevo.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btnNuevo.UseVisualStyleBackColor = true;
            btnNuevo.Click += btnNuevo_Click;
            // 
            // btnGuardar
            // 
            btnGuardar.Image = (System.Drawing.Image)resources.GetObject("btnGuardar.Image");
            btnGuardar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            btnGuardar.Location = new System.Drawing.Point(358, 354);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new System.Drawing.Size(111, 95);
            btnGuardar.TabIndex = 76;
            btnGuardar.Text = "&Guardar";
            btnGuardar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btnGuardar.UseVisualStyleBackColor = true;
            btnGuardar.Click += btnGuardar_Click;
            // 
            // btnSalir
            // 
            btnSalir.Image = (System.Drawing.Image)resources.GetObject("btnSalir.Image");
            btnSalir.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            btnSalir.Location = new System.Drawing.Point(690, 354);
            btnSalir.Name = "btnSalir";
            btnSalir.Size = new System.Drawing.Size(95, 95);
            btnSalir.TabIndex = 75;
            btnSalir.Text = "&Salir";
            btnSalir.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btnSalir.UseVisualStyleBackColor = true;
            btnSalir.Click += btnSalir_Click;
            // 
            // txtContrasena
            // 
            txtContrasena.Location = new System.Drawing.Point(661, 81);
            txtContrasena.Multiline = true;
            txtContrasena.Name = "txtContrasena";
            txtContrasena.Size = new System.Drawing.Size(122, 31);
            txtContrasena.TabIndex = 74;
            // 
            // txtIdUsuario
            // 
            txtIdUsuario.BackColor = System.Drawing.SystemColors.Info;
            txtIdUsuario.Location = new System.Drawing.Point(135, 81);
            txtIdUsuario.Name = "txtIdUsuario";
            txtIdUsuario.ReadOnly = true;
            txtIdUsuario.Size = new System.Drawing.Size(75, 31);
            txtIdUsuario.TabIndex = 71;
            // 
            // grdUsuarios
            // 
            grdUsuarios.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            grdUsuarios.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            grdUsuarios.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] { ID_USUARIO, ID_ROL, NOMBRE_USUARIO, CLAVE });
            grdUsuarios.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            grdUsuarios.Location = new System.Drawing.Point(26, 182);
            grdUsuarios.Name = "grdUsuarios";
            grdUsuarios.ReadOnly = true;
            grdUsuarios.RowHeadersWidth = 62;
            grdUsuarios.RowTemplate.Height = 33;
            grdUsuarios.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            grdUsuarios.Size = new System.Drawing.Size(759, 147);
            grdUsuarios.TabIndex = 70;
            // 
            // ID_USUARIO
            // 
            ID_USUARIO.DataPropertyName = "ID_USUARIO";
            ID_USUARIO.HeaderText = "ID_USUARIO";
            ID_USUARIO.MinimumWidth = 8;
            ID_USUARIO.Name = "ID_USUARIO";
            ID_USUARIO.ReadOnly = true;
            ID_USUARIO.Width = 150;
            // 
            // ID_ROL
            // 
            ID_ROL.DataPropertyName = "ID_ROL";
            ID_ROL.HeaderText = "ID_ROL";
            ID_ROL.MinimumWidth = 8;
            ID_ROL.Name = "ID_ROL";
            ID_ROL.ReadOnly = true;
            ID_ROL.Visible = false;
            ID_ROL.Width = 150;
            // 
            // NOMBRE_USUARIO
            // 
            NOMBRE_USUARIO.DataPropertyName = "NOMBRE_USUARIO";
            NOMBRE_USUARIO.HeaderText = "NOMBRE_USUARIO";
            NOMBRE_USUARIO.MinimumWidth = 8;
            NOMBRE_USUARIO.Name = "NOMBRE_USUARIO";
            NOMBRE_USUARIO.ReadOnly = true;
            NOMBRE_USUARIO.Width = 150;
            // 
            // CLAVE
            // 
            CLAVE.DataPropertyName = "CLAVE";
            CLAVE.HeaderText = "CONTRASEÑA";
            CLAVE.MinimumWidth = 8;
            CLAVE.Name = "CLAVE";
            CLAVE.ReadOnly = true;
            CLAVE.Width = 150;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(26, 84);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(97, 25);
            label1.TabIndex = 83;
            label1.Text = "ID_Usuario";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(548, 84);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(101, 25);
            label2.TabIndex = 84;
            label2.Text = "Contraseña";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new System.Drawing.Point(236, 84);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(143, 25);
            label3.TabIndex = 85;
            label3.Text = "Nombre Usuario";
            // 
            // cboNombreyIdRol
            // 
            cboNombreyIdRol.FormattingEnabled = true;
            cboNombreyIdRol.Location = new System.Drawing.Point(391, 126);
            cboNombreyIdRol.Name = "cboNombreyIdRol";
            cboNombreyIdRol.Size = new System.Drawing.Size(122, 33);
            cboNombreyIdRol.TabIndex = 86;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new System.Drawing.Point(227, 126);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(152, 25);
            label4.TabIndex = 87;
            label4.Text = "Roles Disponibles";
            // 
            // cboRoles
            // 
            cboRoles.FormattingEnabled = true;
            cboRoles.Location = new System.Drawing.Point(135, 122);
            cboRoles.Name = "cboRoles";
            cboRoles.Size = new System.Drawing.Size(75, 33);
            cboRoles.TabIndex = 88;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new System.Drawing.Point(41, 122);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(62, 25);
            label5.TabIndex = 89;
            label5.Text = "ID_Rol";
            // 
            // FrmUsuarios
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(825, 483);
            Controls.Add(label5);
            Controls.Add(cboRoles);
            Controls.Add(label4);
            Controls.Add(cboNombreyIdRol);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtNombreU);
            Controls.Add(btnBuscar);
            Controls.Add(btnEliminar);
            Controls.Add(btnNuevo);
            Controls.Add(btnGuardar);
            Controls.Add(btnSalir);
            Controls.Add(txtContrasena);
            Controls.Add(txtIdUsuario);
            Controls.Add(grdUsuarios);
            Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            Name = "FrmUsuarios";
            StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            Text = "FrmUsuarios";
            Load += FrmUsuarios_Load;
            ((System.ComponentModel.ISupportInitialize)grdUsuarios).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private System.Windows.Forms.TextBox txtNombreU;
        private System.Windows.Forms.Button btnBuscar;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.Button btnNuevo;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.TextBox txtContrasena;
        private System.Windows.Forms.TextBox txtDireccion;
        private System.Windows.Forms.TextBox txtIdUsuario;
        private System.Windows.Forms.DataGridView grdUsuarios;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_USUARIO;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_ROL;
        private System.Windows.Forms.DataGridViewTextBoxColumn NOMBRE_USUARIO;
        private System.Windows.Forms.DataGridViewTextBoxColumn CLAVE;
        private System.Windows.Forms.ComboBox cboNombreyIdRol;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cboRoles;
        private System.Windows.Forms.Label label5;
    }
}