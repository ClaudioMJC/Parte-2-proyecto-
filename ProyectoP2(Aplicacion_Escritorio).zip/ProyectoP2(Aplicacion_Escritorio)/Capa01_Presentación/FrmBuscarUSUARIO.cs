﻿using Capa02_LogicaNegocio;
using CapaEntidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Capa01_Presentación
{
    public partial class FrmBuscarUSUARIO : Form
    {
        public event EventHandler Aceptar;
        int global_id_usuario;
        public FrmBuscarUSUARIO()
        {
            InitializeComponent();
        }

        public void CargarListaUsuarios(string condicion = "")
        {
            BLUsuario logicaUsuario = new BLUsuario(Configuracion.getConnectionString);
            List<EntidadUsuario> listarUsuarios;
            try
            {
                listarUsuarios = logicaUsuario.LlamarListaUsuarios(condicion);
                if (listarUsuarios.Count > 0)
                {
                    grdUsuarios.DataSource = listarUsuarios;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//fin cargar








        private void btnBuscar_Click(object sender, EventArgs e)
        {
            string condicion = string.Empty;
            try
            {
                if (!string.IsNullOrEmpty(txtNombre.Text))
                {
                    condicion = string.Format("NombreUsuario LIKE '%{0}%'", txtNombre.Text.Trim());
                }
                else
                {
                    MessageBox.Show("Debe escribir por lo menos una letra del nombre a buscar", "Atención",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtNombre.Focus();
                }
                CargarListaUsuarios(condicion);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//fin btnbuscar



        private void seleccionar()
        {
            string nombreColumna = "ID_USUARIO";
            int indiceColumna = grdUsuarios.Columns[nombreColumna].Index;
            DataGridViewCell cell = grdUsuarios.SelectedRows[0].Cells[indiceColumna];
            if (cell != null && cell.Value != null)
            {
                global_id_usuario = (int)cell.Value;
                Aceptar(global_id_usuario, null);
                Close();
            }
        }// fin seleccionar


        private void btnAceptar_Click(object sender, EventArgs e)
        {
            seleccionar();
        }



        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Aceptar(-1, null);
            Close();
        }



        private void grdUsuarios_DoubleClick(object sender, EventArgs e)
        {
            int id = 0;
            try
            {
                id = (int)grdUsuarios.SelectedRows[0].Cells[0].Value;
                CargarListaUsuarios(id.ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FrmBuscarUSUARIO_Load(object sender, EventArgs e)
        {
           
        }
    }
}
