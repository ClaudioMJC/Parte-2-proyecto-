﻿using CapaEntidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Linq;

namespace Capa03_AccesoDatos
{
    public class DACita2
    {
        private string nombreMedico;
        private string nombreEspecialidad;

        private string _cadenaConexion;
        private string _mensaje;

        //propiedes

        public string Mensaje
        {
            get => _mensaje;
        }
        //constructor de la clase
        public DACita2(string cadenaConexion)
        {
            _cadenaConexion = cadenaConexion;
            _mensaje = string.Empty;
        }




        /////////////METODOS PARA MOSTRAR DATOS EN EL CADA UNO DE LOS COMBOX

        public List<string> ObtenerIdMedicos()
        {
            List<string> idMedicos = new List<string>();

            using (SqlConnection conexion = new SqlConnection(_cadenaConexion))
            {
                string instruccionDB = "SELECT ID_MEDICO FROM MEDICO";

                using (SqlDataAdapter adapter = new SqlDataAdapter())
                {
                    adapter.SelectCommand = new SqlCommand(instruccionDB, conexion);

                    try
                    {
                        conexion.Open();
                        DataSet elDataSet = new DataSet();
                        adapter.Fill(elDataSet, "MEDICO");

                        foreach (DataRow fila in elDataSet.Tables["MEDICO"].Rows)
                        {
                            string idMedico = fila["ID_MEDICO"].ToString();
                            idMedicos.Add(idMedico);
                        }
                    }
                    catch (Exception)
                    {
                        throw;
                    }
                }
            }

            return idMedicos;
        }



        /// ID_PACIENTE EN EL COMBOBOX


        public List<string> ObtenerIdPacientes()
        {
            List<string> idPacientes = new List<string>();

            using (SqlConnection conexion = new SqlConnection(_cadenaConexion))
            {
                string instruccionDB = "SELECT ID_PACIENTE FROM PACIENTE";

                using (SqlDataAdapter adapter = new SqlDataAdapter())
                {
                    adapter.SelectCommand = new SqlCommand(instruccionDB, conexion);

                    try
                    {
                        conexion.Open();
                        DataSet elDataSet = new DataSet();
                        adapter.Fill(elDataSet, "PACIENTE");

                        foreach (DataRow fila in elDataSet.Tables["PACIENTE"].Rows)
                        {
                            string idPaciente = fila["ID_PACIENTE"].ToString();
                            idPacientes.Add(idPaciente);
                        }
                    }
                    catch (Exception)
                    {
                        throw;
                    }
                }
            }

            return idPacientes;
        }



        //combobox para saber que medico, especialidad y id tiene para poder seleccionar su id en el campo de solo su id

        public List<string> ObtenerEspecialidades()
        {
            /*
            List<string> especialidades = new List<string>();

            DataSet elDataSet = new DataSet();
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlDataAdapter adapter;

            string instruccionDB = "SELECT NOMBRE FROM ESPECIALIDAD";

            try
            {
                conexion.Open(); // Abre la conexión antes de ejecutar la consulta

                adapter = new SqlDataAdapter(instruccionDB, conexion);
                adapter.Fill(elDataSet, "ESPECIALIDAD");

                foreach (DataRow fila in elDataSet.Tables["ESPECIALIDAD"].Rows)
                {
                    string especialidad = fila["NOMBRE"].ToString();
                    especialidades.Add(especialidad);
                }

                conexion.Close(); // Cierra la conexión después de utilizarla
            }
            catch (Exception)
            {
                throw;
            }

            return especialidades;
            */



            List<string> especialidades = new List<string>();
            // se utiliza bloques using para garantizar que la conexión y el adaptador se cierren correctamente, incluso en caso de excepciones
            using (SqlConnection conexion = new SqlConnection(_cadenaConexion))
            {
                string instruccionDB = @"SELECT M.ID_MEDICO, M.NOMBRE, M.APELLIDO, E.NOMBRE AS ESPECIALIDAD
                                FROM MEDICO M
                                INNER JOIN ESPECIALIDAD E ON M.ID_ESPECIALIDAD = E.ID_ESPECIALIDAD"; //consulta o instrucción select tal y como aparece en la BD

                using (SqlDataAdapter adapter = new SqlDataAdapter())
                {    //Se Establece la consulta SQL en el comando de selección del adaptador
                    adapter.SelectCommand = new SqlCommand(instruccionDB, conexion);

                    try
                    {
                        conexion.Open(); // Abre la conexión antes de ejecutar la consulta
                        DataSet elDataSet = new DataSet();
                        adapter.Fill(elDataSet, "MEDICO_ESPECIALIDAD");
                        // Se Itera sobre cada fila del DataSet para obtener los datos de los médicos
                        foreach (DataRow fila in elDataSet.Tables["MEDICO_ESPECIALIDAD"].Rows)
                        {    // Obtenemos los valores de nombre, apellido y especialidad de cada fila
                            string idMedico = fila["ID_MEDICO"].ToString();
                            string nombreMedico = fila["NOMBRE"].ToString();
                            string apellidoMedico = fila["APELLIDO"].ToString();
                            string especialidadMedico = fila["ESPECIALIDAD"].ToString();
                            // Concatenamos nombre, apellido y especialidad en una sola cadena
                            string datosMedico = $"ID: {idMedico}, Nombre: {nombreMedico} {apellidoMedico}, Especialidad: {especialidadMedico}";
                            especialidades.Add(datosMedico);// Agregamos la cadena al listado, esta contiene los datos del medico,id y especialidad
                        }
                    }
                    catch (Exception)
                    {
                        throw;
                    }
                }
            }

            return especialidades;


        }//Fin de obtenerEspecialidad //método enfocado en mostrar la info en el comboBox


        //OBTENER ID PAGO DE LA TABLA PAGO
        public List<string> ObtenerIdPagos()
        {
            List<string> idPagos = new List<string>();

            using (SqlConnection conexion = new SqlConnection(_cadenaConexion))
            {
                string instruccionDB = "SELECT ID_PAGO FROM PAGO";

                using (SqlDataAdapter adapter = new SqlDataAdapter())
                {
                    adapter.SelectCommand = new SqlCommand(instruccionDB, conexion);

                    try
                    {
                        conexion.Open();
                        DataSet elDataSet = new DataSet();
                        adapter.Fill(elDataSet, "PAGO");

                        foreach (DataRow fila in elDataSet.Tables["PAGO"].Rows)
                        {
                            string idPago = fila["ID_PAGO"].ToString();
                            idPagos.Add(idPago);
                        }
                    }
                    catch (Exception)
                    {
                        throw;
                    }
                }
            }

            return idPagos;
        }//FIN DE MÉTODO PARA UBICAR EL ID_PAGO DE LA TABLA PAGO



        ////////////////////////METODO PARA INSERTAR/////
        public int Insertar(EntidadCita cita)
        {
            int id = 0;
            // Establecer el objeto de conexión
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            // Establecer el objeto para ejecutar los comandos SQL
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            string sentencia = "INSERT INTO CITA (FECHA, HORA, DESCRIPCION, ID_MEDICO, ID_PAGO, ID_PACIENTE, DETALLE_MEDICO)" +
                " VALUES (@FECHA, @HORA, @DESCRIPCION, @ID_MEDICO, @ID_PAGO, @ID_PACIENTE, @DETALLE_MEDICO); SELECT SCOPE_IDENTITY()";
            comando.Parameters.AddWithValue("@FECHA", cita.Fecha);
            comando.Parameters.AddWithValue("@HORA", cita.Hora);
            comando.Parameters.AddWithValue("@DESCRIPCION", cita.Descripcion);
            comando.Parameters.AddWithValue("@ID_MEDICO", cita.Id_medico);
            comando.Parameters.AddWithValue("@ID_PAGO", cita.Id_pago);
            comando.Parameters.AddWithValue("@ID_PACIENTE", cita.Id_paciente);
            comando.Parameters.AddWithValue("@DETALLE_MEDICO", cita.Detalle_Medico);
            comando.CommandText = sentencia;
            try
            {
                conexion.Open();
                id = Convert.ToInt32(comando.ExecuteScalar());
                conexion.Close();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conexion.Dispose();
                comando.Dispose();
            }
            return id;
        }////////////////////////////////////////////////////////////////////////////


        //ListarCitas

        public List<EntidadCita> ListarCitas(string condicion = "")
        {
            DataSet elDataSet = new DataSet();
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlDataAdapter adapter;
            List<EntidadCita> listaCitas;

            string instruccionDB = "SELECT ID_CITA, FECHA, HORA, DESCRIPCION, ID_MEDICO, ID_PAGO, ID_PACIENTE, DETALLE_MEDICO FROM CITA";

            if (!string.IsNullOrEmpty(condicion))
            {
                instruccionDB = string.Format("{0} WHERE {1}", instruccionDB, condicion);
            }
            try
            {
                adapter = new SqlDataAdapter(instruccionDB, conexion);
                adapter.Fill(elDataSet, "CITA");
                listaCitas = (from DataRow unaFila in elDataSet.Tables["CITA"].Rows
                              select new EntidadCita()
                              {    /* 
                                  Id_cita = (int)unaFila["ID_CITA"],
                                  Fecha = (DateTime)unaFila["FECHA"],
                                  Hora = (TimeSpan)unaFila["HORA"],
                                  Descripcion = unaFila["DESCRIPCION"].ToString(),
                                  Id_medico = (int)unaFila["ID_MEDICO"],
                                  Id_pago = (int)unaFila["ID_PAGO"],
                                  Id_paciente = (int)unaFila["ID_PACIENTE"],
                                  Detalle_Medico = unaFila["DETALLE_MEDICO"].ToString()
                                  */
                                  Id_cita = unaFila["ID_CITA"] != DBNull.Value ? (int)unaFila["ID_CITA"] : 0,
                                  Fecha = (DateTime)unaFila["FECHA"],
                                  Hora = (TimeSpan)unaFila["HORA"],
                                  Descripcion = unaFila["DESCRIPCION"].ToString(),
                                  Id_medico = unaFila["ID_MEDICO"] != DBNull.Value ? (int)unaFila["ID_MEDICO"] : 0,
                                  Id_pago = unaFila["ID_PAGO"] != DBNull.Value ? (int)unaFila["ID_PAGO"] : 0,
                                  Id_paciente = unaFila["ID_PACIENTE"] != DBNull.Value ? (int)unaFila["ID_PACIENTE"] : 0,
                                  Detalle_Medico = unaFila["DETALLE_MEDICO"].ToString()


                              }).ToList();
            }
            catch (Exception)
            {
                throw;
            }
            return listaCitas;
        }//Fin



        ///OBTENER CITAS

        public EntidadCita ObtenerCita(int id)
        {
            EntidadCita cita = null;
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            SqlDataReader dataReader;
            string sentencia = string.Format("SELECT ID_CITA, FECHA, HORA, DESCRIPCION, ID_MEDICO, ID_PAGO, ID_PACIENTE, DETALLE_MEDICO FROM " +
                "CITA WHERE ID_CITA = {0}", id);
            comando.Connection = conexion;
            comando.CommandText = sentencia;
            try
            {
                conexion.Open();
                dataReader = comando.ExecuteReader();
                if (dataReader.HasRows)
                {     /*
                    cita = new EntidadCita();
                    dataReader.Read();
                    cita.Id_cita = dataReader.GetInt32(0);
                    cita.Fecha = dataReader.GetDateTime(1);
                    cita.Hora = dataReader.GetTimeSpan(2);
                    cita.Descripcion = dataReader.IsDBNull(3) ? string.Empty : dataReader.GetString(3);
                    cita.Id_medico = dataReader.GetInt32(4);
                    cita.Id_pago = dataReader.GetInt32(5);
                    cita.Id_paciente = dataReader.GetInt32(6);
                    cita.Detalle_Medico = dataReader.IsDBNull(7) ? string.Empty : dataReader.GetString(7);
                    */
                    cita = new EntidadCita();
                    dataReader.Read();
                    cita.Id_cita = dataReader.GetInt32(0);
                    cita.Fecha = dataReader.IsDBNull(1) ? DateTime.MinValue : dataReader.GetDateTime(1);
                    cita.Hora = dataReader.IsDBNull(2) ? TimeSpan.Zero : dataReader.GetTimeSpan(2);
                    cita.Descripcion = dataReader.IsDBNull(3) ? string.Empty : dataReader.GetString(3);
                    cita.Id_medico = dataReader.IsDBNull(4) ? 0 : dataReader.GetInt32(4);
                    cita.Id_pago = dataReader.IsDBNull(5) ? 0 : dataReader.GetInt32(5);
                    cita.Id_paciente = dataReader.IsDBNull(6) ? 0 : dataReader.GetInt32(6);
                    cita.Detalle_Medico = dataReader.IsDBNull(7) ? string.Empty : dataReader.GetString(7);

                }
                conexion.Close();
            }
            catch (Exception)
            {
                throw;
            }
            return cita;
        }//FIN


        //ELIMINAR

        public int EliminarCita(EntidadCita cita)
        {
            int afectado = -1;
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            string sentencia = "DELETE FROM CITA";
            sentencia = string.Format("{0} WHERE ID_CITA = {1}", sentencia, cita.Id_cita);
            comando.CommandText = sentencia;
            comando.Connection = conexion;
            try
            {
                conexion.Open();
                afectado = comando.ExecuteNonQuery();
                conexion.Close();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conexion.Dispose();
                comando.Dispose();
            }
            return afectado;
        }



        //Modificar
        public int Modificar(EntidadCita cita)
        {
            int filasAfectadas = -1;
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            SqlCommand comando = new SqlCommand();
            string sentencia = "UPDATE CITA SET FECHA=@FECHA, HORA=@HORA, DESCRIPCION=@DESCRIPCION, ID_MEDICO=@ID_MEDICO, ID_PAGO=@ID_PAGO, ID_PACIENTE=@ID_PACIENTE, DETALLE_MEDICO=@DETALLE_MEDICO WHERE ID_CITA=@ID_CITA";
            comando.CommandText = sentencia;
            comando.Connection = conexion;
            comando.Parameters.AddWithValue("@ID_CITA", cita.Id_cita);
            comando.Parameters.AddWithValue("@FECHA", cita.Fecha);
            comando.Parameters.AddWithValue("@HORA", cita.Hora);
            comando.Parameters.AddWithValue("@DESCRIPCION", cita.Descripcion);
            comando.Parameters.AddWithValue("@ID_MEDICO", cita.Id_medico);
            comando.Parameters.AddWithValue("@ID_PAGO", cita.Id_pago);
            comando.Parameters.AddWithValue("@ID_PACIENTE", cita.Id_paciente);
            comando.Parameters.AddWithValue("@DETALLE_MEDICO", cita.Detalle_Medico);
            try
            {
                conexion.Open();
                filasAfectadas = comando.ExecuteNonQuery();
                conexion.Close();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conexion.Dispose();
                comando.Dispose();
            }
            return filasAfectadas;
        }//fin




    }
}
