﻿namespace Capa01_Presentación
{
    partial class FrmBUSCARCITAS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmBUSCARCITAS));
            label2 = new System.Windows.Forms.Label();
            txtID_Cita = new System.Windows.Forms.TextBox();
            btnBuscar = new System.Windows.Forms.Button();
            btnAceptar = new System.Windows.Forms.Button();
            btnCancelar = new System.Windows.Forms.Button();
            grdCitas = new System.Windows.Forms.DataGridView();
            Id_cita = new System.Windows.Forms.DataGridViewTextBoxColumn();
            Fecha = new System.Windows.Forms.DataGridViewTextBoxColumn();
            Hora = new System.Windows.Forms.DataGridViewTextBoxColumn();
            Descripcion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            Id_medico = new System.Windows.Forms.DataGridViewTextBoxColumn();
            Id_pago = new System.Windows.Forms.DataGridViewTextBoxColumn();
            id_paciente = new System.Windows.Forms.DataGridViewTextBoxColumn();
            Detalle_Medico = new System.Windows.Forms.DataGridViewTextBoxColumn();
            Estado_Pago = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            ((System.ComponentModel.ISupportInitialize)grdCitas).BeginInit();
            SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(246, 60);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(73, 25);
            label2.TabIndex = 81;
            label2.Text = "ID_CITA";
            // 
            // txtID_Cita
            // 
            txtID_Cita.Location = new System.Drawing.Point(325, 54);
            txtID_Cita.Name = "txtID_Cita";
            txtID_Cita.Size = new System.Drawing.Size(307, 31);
            txtID_Cita.TabIndex = 80;
            // 
            // btnBuscar
            // 
            btnBuscar.Image = (System.Drawing.Image)resources.GetObject("btnBuscar.Image");
            btnBuscar.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            btnBuscar.Location = new System.Drawing.Point(671, 43);
            btnBuscar.Name = "btnBuscar";
            btnBuscar.Size = new System.Drawing.Size(98, 52);
            btnBuscar.TabIndex = 79;
            btnBuscar.Text = "&Buscar";
            btnBuscar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnBuscar.UseVisualStyleBackColor = true;
            btnBuscar.Click += btnBuscar_Click;
            // 
            // btnAceptar
            // 
            btnAceptar.Image = (System.Drawing.Image)resources.GetObject("btnAceptar.Image");
            btnAceptar.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            btnAceptar.Location = new System.Drawing.Point(476, 335);
            btnAceptar.Name = "btnAceptar";
            btnAceptar.Size = new System.Drawing.Size(110, 61);
            btnAceptar.TabIndex = 78;
            btnAceptar.Text = "&Aceptar";
            btnAceptar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnAceptar.UseVisualStyleBackColor = true;
            btnAceptar.Click += btnAceptar_Click;
            // 
            // btnCancelar
            // 
            btnCancelar.Image = (System.Drawing.Image)resources.GetObject("btnCancelar.Image");
            btnCancelar.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            btnCancelar.Location = new System.Drawing.Point(651, 335);
            btnCancelar.Name = "btnCancelar";
            btnCancelar.Size = new System.Drawing.Size(118, 61);
            btnCancelar.TabIndex = 77;
            btnCancelar.Text = "&Cancelar";
            btnCancelar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnCancelar.UseVisualStyleBackColor = true;
            btnCancelar.Click += btnCancelar_Click;
            // 
            // grdCitas
            // 
            grdCitas.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            grdCitas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            grdCitas.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] { Id_cita, Fecha, Hora, Descripcion, Id_medico, Id_pago, id_paciente, Detalle_Medico, Estado_Pago });
            grdCitas.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            grdCitas.Location = new System.Drawing.Point(31, 142);
            grdCitas.Name = "grdCitas";
            grdCitas.RowHeadersWidth = 62;
            grdCitas.RowTemplate.Height = 33;
            grdCitas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            grdCitas.Size = new System.Drawing.Size(738, 148);
            grdCitas.TabIndex = 82;
            grdCitas.Click += grdCitas_DoubleClick;
            // 
            // Id_cita
            // 
            Id_cita.DataPropertyName = "ID_CITA";
            Id_cita.HeaderText = "Id_cita";
            Id_cita.MinimumWidth = 8;
            Id_cita.Name = "Id_cita";
            Id_cita.Width = 150;
            // 
            // Fecha
            // 
            Fecha.DataPropertyName = "FECHA";
            Fecha.HeaderText = "Fecha";
            Fecha.MinimumWidth = 8;
            Fecha.Name = "Fecha";
            Fecha.Width = 150;
            // 
            // Hora
            // 
            Hora.DataPropertyName = "HORA";
            Hora.HeaderText = "Hora";
            Hora.MinimumWidth = 8;
            Hora.Name = "Hora";
            Hora.Width = 150;
            // 
            // Descripcion
            // 
            Descripcion.DataPropertyName = "DESCRIPCION";
            Descripcion.HeaderText = "Descripción";
            Descripcion.MinimumWidth = 8;
            Descripcion.Name = "Descripcion";
            Descripcion.Width = 150;
            // 
            // Id_medico
            // 
            Id_medico.DataPropertyName = "ID_MEDICO";
            Id_medico.HeaderText = "Id_Médico";
            Id_medico.MinimumWidth = 8;
            Id_medico.Name = "Id_medico";
            Id_medico.Visible = false;
            Id_medico.Width = 150;
            // 
            // Id_pago
            // 
            Id_pago.DataPropertyName = "ID_PAGO";
            Id_pago.HeaderText = "Id_Pago";
            Id_pago.MinimumWidth = 8;
            Id_pago.Name = "Id_pago";
            Id_pago.Visible = false;
            Id_pago.Width = 150;
            // 
            // id_paciente
            // 
            id_paciente.DataPropertyName = "ID_PACIENTE";
            id_paciente.HeaderText = "Id_Paciente";
            id_paciente.MinimumWidth = 8;
            id_paciente.Name = "id_paciente";
            id_paciente.Width = 150;
            // 
            // Detalle_Medico
            // 
            Detalle_Medico.DataPropertyName = "DETALLE_MEDICO";
            Detalle_Medico.HeaderText = "Detalle_Médico";
            Detalle_Medico.MinimumWidth = 8;
            Detalle_Medico.Name = "Detalle_Medico";
            Detalle_Medico.Width = 150;
            // 
            // Estado_Pago
            // 
            Estado_Pago.DataPropertyName = "Estado_Pago";
            Estado_Pago.HeaderText = "Estado_Pago";
            Estado_Pago.MinimumWidth = 8;
            Estado_Pago.Name = "Estado_Pago";
            Estado_Pago.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            Estado_Pago.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            Estado_Pago.Width = 150;
            // 
            // FrmBUSCARCITAS
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(800, 450);
            Controls.Add(grdCitas);
            Controls.Add(label2);
            Controls.Add(txtID_Cita);
            Controls.Add(btnBuscar);
            Controls.Add(btnAceptar);
            Controls.Add(btnCancelar);
            MaximizeBox = false;
            Name = "FrmBUSCARCITAS";
            StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            Text = "Buscar Cita";
            Load += FrmBUSCARCITAS_Load;
            ((System.ComponentModel.ISupportInitialize)grdCitas).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtID_Cita;
        private System.Windows.Forms.Button btnBuscar;
        private System.Windows.Forms.Button btnAceptar;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.DataGridView grdCitas;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id_cita;
        private System.Windows.Forms.DataGridViewTextBoxColumn Fecha;
        private System.Windows.Forms.DataGridViewTextBoxColumn Hora;
        private System.Windows.Forms.DataGridViewTextBoxColumn Descripcion;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id_medico;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id_pago;
        private System.Windows.Forms.DataGridViewTextBoxColumn id_paciente;
        private System.Windows.Forms.DataGridViewTextBoxColumn Detalle_Medico;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Estado_Pago;
    }
}