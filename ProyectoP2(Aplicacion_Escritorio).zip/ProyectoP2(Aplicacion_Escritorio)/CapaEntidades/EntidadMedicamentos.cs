﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CapaEntidades
{
    public class EntidadMedicamentos
    {
        private int id_medicamentos;
        private string nombre;
        

        public int Id_medicamentos { get => id_medicamentos; set => id_medicamentos = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        

        public EntidadMedicamentos()
        {
            id_medicamentos = 0;
            nombre = string.Empty;
            
        }

        public EntidadMedicamentos(int id_medicamentos, string nombre, string dosis)
        {
            this.id_medicamentos= id_medicamentos;
            this.nombre = nombre;
            
        } 
    }

}
