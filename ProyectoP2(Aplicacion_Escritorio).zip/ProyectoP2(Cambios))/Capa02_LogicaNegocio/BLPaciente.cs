﻿using System;
using System.Collections.Generic;
using System.Text;
using CapaEntidades;
using Capa03_AccesoDatos;

namespace Capa02_LogicaNegocio
{     //Atributos de la clase
    public class BLPaciente
    {           
        private string _cadenaConexion;
        private string _mensaje;

        //propiedes
        
        public string Mensaje
        {
            get => _mensaje;
        }
        //constructor de la clase
        public BLPaciente(string cadenaConexion)
        {
            _cadenaConexion = cadenaConexion;
            _mensaje = string.Empty;
        }


        //metodo que se encarga de  llamar al metodo insertar de la capa de AccesoDatos
        public int LlamarMetodoInsertar(EntidadPaciente paciente)
        {
            int id_paciente = 0;
            DaPaciente accesoDatos = new DaPaciente(_cadenaConexion);
            try
            {
                id_paciente = accesoDatos.Insertar(paciente);
            }
            catch (Exception)
            {
                throw;
            }
            return id_paciente;
        }// fin de la clase insertar (Hasta aquí es el procedimiento para insertar en la base de datos y guardar)
        

        //mostrar lista de Pacientes 2
        public List<EntidadPaciente> llamarListaPacientes(string condicion = "")
        {
            List<EntidadPaciente> listaPacientes;
            DaPaciente accesoDatos = new DaPaciente(_cadenaConexion);
            try
            {
                listaPacientes = accesoDatos.ListarPacientes(condicion);
            }
            catch (Exception)
            {
                throw;
            }

            return listaPacientes;
        }


        public EntidadPaciente ObtenerPaciente(int id)
        {
            EntidadPaciente cliente;
            DaPaciente accesoDatos = new DaPaciente(_cadenaConexion);
            try
            {
                cliente = accesoDatos.ObtenerPaciente(id);
            }
            catch (Exception)
            {
                throw;
            }
            return cliente;
        }//Obtenerfin 


        // (LLAMAR AL MÉTODO ELIMINAR REGISTRO)
        public int EliminarPaciente(EntidadPaciente paciente)
        {
            int resultado;
            DaPaciente accesoDatos = new DaPaciente(_cadenaConexion);
            try
            {
                resultado = accesoDatos.EliminarPaciente(paciente);

            }
            catch (Exception)
            {
                throw;
            }
            return resultado;

        }//Eliminar fin


        //(LLAMAR MÉTODO ACTUALIZAR REGISTRO)

        public int Modificar(EntidadPaciente paciente)
        {
            int filasAfectadas = 0;
            DaPaciente accesoDatos = new DaPaciente(_cadenaConexion);

            try
            {
                filasAfectadas = accesoDatos.Modificar(paciente);
            }
            catch (Exception)
            {
                throw;
            }
            return filasAfectadas;

        }


    }//fin clase BLPACIENTE


}//FIN Capa02_LogicaNegocio
